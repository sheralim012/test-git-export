#!/usr/bin/python
#
# File:   qpython4.py
# Date:   05-Feb-12 / 07-jun-14
# Author: I. Chuang <ichuang@mit.edu>
#
# Simple quantum circuits in python
#
# This module provides classes for basic quantum states (qubits), gates, and operations,
# from which quantum circuits can be constructed.  It provides a matrix representation
# for unitary quantum circuits, as well as a drawing of the circuit.
#
# Uses scipy's quantum stuff!
#
# This version produces SVG drawings, and does not use matplotlib.
#
# Unit tests included - run them with py.test

# from __future__ import division

import os
import re
import sys
import time
import string
import datetime
#import urllib.request, urllib.parse, urllib.error
try:
    import urllib.parse
except Exception as err:
    print("[qpython4] Warning: could not import urllib.parse, err=%s" % str(err))
import math, operator
import numbers
import random
import unicodedata

import mpmath
import sympy
import traceback
import io
import base64
import numpy

from lxml import etree
import scipy.linalg
import sympy.physics.quantum as spq
import sympy.physics.quantum.gate 
import sympy.physics.quantum.gate as gate

from sympy import Matrix, sqrt, cos, sin
from sympy import Mul
from sympy.physics.quantum.gate import Gate, UGate, CGate
from sympy.physics.quantum.qapply import qapply
from sympy.physics.quantum.qubit import Qubit
from sympy.physics.quantum.represent import represent
from sympy.physics.quantum.dagger import Dagger
from sympy.physics.quantum.matrixcache import matrix_cache
from sympy.physics.quantum.matrixutils import (matrix_tensor_product, matrix_eye)

from collections import defaultdict
from functools import reduce

try:
    from sympy_check import SympyFormulaChecker
except Exception as err:
    # print("[qpython4] Warning: could not import SympyFormulaChecker, err=%s" % str(err))
    pass

URL_ROOT = 'tutorexport/8.371/QCircuits'
IMDIR = '/home/WWW/' + URL_ROOT

#-----------------------------------------------------------------------------
# gates defined

GATES = ['H', 'X', 'Y', 'Z', 'T', 'S', 'CNOT', 'SWAP', 'XGate', 'YGate', 'ZGate', 'CGate', 'TGate']
GATES_DICT = {g: getattr(gate, g) for g in GATES}

#-----------------------------------------------------------------------------
# networkx for graph isomorphism checking

nx = None
if 0:
    try:
        import networkx as nx
    except Exception as err:
        nx = None

#-----------------------------------------------------------------------------
# matplotlib for graph state plots

# from sympy.external import import_module
# np = import_module('numpy', min_python_version=(2, 6))
# matplotlib = import_module('matplotlib', __import__kwargs={'fromlist':['pyplot']})

#-----------------------------------------------------------------------------
# math unicode to ascii

def MathUnicodeToAscii(ustr):
    '''
    mathjax \tt format generates funny unicode; convert to ascii
    so that folks can cut and paste from solutions.
    '''
    try:
        asc = str(ustr)
        return asc
    except Exception as err:
        pass

    ns = []
    for ch in ustr:
        if ord(ch)<128:
            ns.append(ord(ch))
        elif ord(ch)>0x1D7F5:
            ns.append(ord(ch)-0x1D7F6+ord('0'))	# numbers
        elif ord(ch)>(0x1d68E-5):
            ns.append(ord(ch)-0x1D68E+ord('e'))	# lowercase
        elif ord(ch)>(0x1d678-9):
            ns.append(ord(ch)-0x1D678+ord('I'))	# caps
        else:
            ns.append(ord(ch)-0x2217+ord('*'))	# operators
    try:
        asc = ''.join(map(chr, ns))
        return asc
    except Exception as err:
        pass

    return ustr	# can't do anything

#-----------------------------------------------------------------------------
# dot operator

try:
    LatticeOp = sympy.core.operations.LatticeOp
except Exception as err:
    LatticeOp = sympy.operations.LatticeOp

class dot(LatticeOp):	# my dot product
    zero = sympy.Symbol('dotzero')
    identity = sympy.Symbol('dotidentity')

#-----------------------------------------------------------------------------
# single qubit rotation gates

class RotationGate(UGate):
    '''
    Matrix is self.label[1]
    '''
    # gate_axis = u'x'
    # gate_axis_mat = Matrix([[0,1],[1,0]])
    # gate_name = u'R'+gate_axis
    # gate_name_latex = u'R_'+gate_axis

    @classmethod
    def _eval_args(cls, args):
        if not len(args)==2:
            raise Exception("Rotation gate arguments should be target_qubit, angle")
        if not type(args[0])==int:
            raise Exception("Rotation gate arguments should be target_qubit, angle")
        targets = (args[0],)
        targets = Gate._eval_args(targets)
        angle = args[1]
        mat = (-gate.I*angle/2*cls.gate_axis_mat).exp()
        # print("[RotationGate] targets=%s, angle=%s" % (targets, angle))	# for debugging
        mat = mat.as_immutable()				# so that qapply works (python3)
        return (targets, mat, angle)		# this becomes self.label
        #return (targets, mat)

    def ____pretty(self, printer, *args):
        return "%s(%s,%s)" % (self.gate_name, self.targets[0], self.label[1])

    def _print_label(self, printer, *args):
        # print("in print_label, label=%s" % str(self.label))
        return "%s,%s" % (self.targets[0], self.label[2])

    @property
    def gate_name_plot(self):
        return r'[mathjaxinline]%s(%s)[/mathjaxinline]' % (self.gate_name_latex,sympy.latex(self.label[2]))

    def _print_targets(self,printer,*args):
        return '%s,%s' % (self.label[0][0],self.label[2])
    def _print_contents_latex(self, printer, *args):
        return r'%s\left(%s\right)' % (self.gate_name_latex, sympy.latex(self.label[2]))

    def plot_gate(self, circ_plot, gate_idx):
        circ_plot.one_qubit_box(
            self.gate_name_plot,
            gate_idx, int(self.targets[0]),
            use_mathjax=True,
            width=1,
        )

class Rx(RotationGate):
    gate_axis = 'x'
    gate_name = 'R'+gate_axis
    gate_name_latex = 'R_'+gate_axis
    gate_axis_mat = Matrix([[0,1],[1,0]])
        
class Ry(RotationGate):
    gate_axis = 'y'
    gate_name = 'R'+gate_axis
    gate_name_latex = 'R_'+gate_axis
    gate_axis_mat = Matrix([[0,-gate.I],[gate.I,0]])

class Rz(RotationGate):
    gate_axis = 'z'
    gate_name = 'R'+gate_axis
    gate_name_latex = 'R_'+gate_axis
    gate_axis_mat = Matrix([[1,0],[0,-1]])

# hadamard [H(0)] is [Z(0),Ry(0,pi/2)]

GATES_DICT['Rx'] = Rx
GATES_DICT['Ry'] = Ry
GATES_DICT['Rz'] = Rz

#-----------------------------------------------------------------------------
# single qubit Zalpha gate (Rz up to global phase): [[1,0],[0,exp(-i*alpha)]]

class Zalpha(UGate):
    gate_name = 'Zalpha'
    gate_name_latex = 'Z_\alpha'

    @classmethod
    def _eval_args(cls, args):
        if not len(args)==2:
            raise Exception("Zalpha gate arguments should be target_qubit, angle")
        if not type(args[0])==int:
            raise Exception("Zalpha gate arguments should be target_qubit, angle")
        targets = (args[0],)
        targets = Gate._eval_args(targets)
        angle = args[1]
        # print("[Zalpha] angle=%s" % angle)			# DEBUG
        mat = Matrix([[1,0],[0,sympy.exp(-gate.I*angle)]])
        mat = mat.as_immutable()				# so that qapply works (python3)
        return (targets, mat, angle)

    def _print_label(self, printer, *args):
        # print("in print_label, label=%s" % str(self.label))
        return "%s,%s" % (self.targets[0], self.label[2])

    @property
    def gate_name_plot(self):
        return r'$%s(%s)$' % (self.gate_name_latex,sympy.latex(self.label[2]))

    def _print_targets(self,printer,*args):
        return '%s,%s' % (self.label[0][0],self.label[2])
    def _print_contents_latex(self, printer, *args):
        return r'%s\left(%s\right)' % (self.gate_name_latex, sympy.latex(self.label[2]))

    def plot_gate(self, circ_plot, gate_idx):
        circ_plot.one_qubit_box(
            self.gate_name_plot,
            gate_idx, int(self.targets[0])
        )

GATES_DICT['Zalpha'] = Zalpha

#-----------------------------------------------------------------------------
# identity gate (single qubit)

class IdentityGate(UGate):

    gate_name = "Identity"

    @classmethod
    def _eval_args(cls, args):
        targets = (args[0],)
        targets = Gate._eval_args(targets)
        return (targets,Matrix([[1,0],[0,1]]))

    def _print_targets(self,printer,*args):
        return '%s' % (self.label[0][0])
    def _print_contents_latex(self, printer, *args):
        return r'' 

    def plot_gate(self, circ_plot, gate_idx):
        return

GATES_DICT['IdentityGate'] = IdentityGate
GATES_DICT['pi'] = sympy.pi
GATES_DICT['exp'] = sympy.exp
GATES_DICT['sqrt'] = sympy.sqrt
GATES_DICT['I'] = sympy.I
GATES_DICT['i'] = sympy.I

#-----------------------------------------------------------------------------
# cphase gate

class ControlledPhaseGate(spq.gate.CNotGate):
    """Two qubit CPHASE gate.

    Parameters
    ----------
    label : tuple
        A tuple of the form (target1, target2).

    Examples
    --------

    """
    gate_name = 'CPHASE'
    gate_name_latex = r'\Lambda_Z'

    @property
    def gate(self):
        """The non-controlled gate that will be applied to the targets."""
        return GATES_DICT['ZGate'](self.label[1])

    def plot_gate(self, circ_plot, gate_idx):
        min_wire = int(min(self.targets))
        max_wire = int(max(self.controls))
        circ_plot.control_line(gate_idx, min_wire, max_wire)
        circ_plot.control_point(gate_idx, min_wire)	# two circles
        circ_plot.control_point(gate_idx, max_wire)

GATES_DICT['CPHASE'] = ControlledPhaseGate
GATES_DICT['CZ'] = ControlledPhaseGate

#-----------------------------------------------------------------------------
# controlled-S and controlled-H gates

class COneQubitGate(CGate):
    #gate_name = u'CS'
    #gate_name_latex = u'CS'
    #gate_matrix = Matrix([[1,0],[0,gate.I]])
    #one_qubit_gate_name = u'S'
    
    @classmethod
    def _eval_args(cls, args):
        controls = args[0]
        target = args[1]
        gate = cls.one_qubit_gate(target)
        controls = (controls,)
        return (controls, gate)

    def _print_contents(self, printer, *args):
        controls = self._print_sequence(self.controls, ',', printer, *args)
        return '%s(%s,%s)' %\
            (self.gate_name, controls[0], self.gate.label[0])

class CSGate(COneQubitGate):
    gate_name = 'CS'
    gate_name_latex = 'CS'
    one_qubit_gate = GATES_DICT['S']

class CHGate(COneQubitGate):
    gate_name = 'CH'
    gate_name_latex = 'CH'
    one_qubit_gate = GATES_DICT['H']

GATES_DICT['CS'] = CSGate
GATES_DICT['CH'] = CHGate
GATES_DICT['CSGate'] = CSGate
GATES_DICT['CHGate'] = CHGate

# example test: qp.represent(qp.CHGate(1,0),nqubits=2)

# from controlled-S to controlled-H
# qp.QuantumCircuit('[T(1).inv(),S(0),H(0),CS(1,0),H(0),S(0).inv(),CZ(0,1)]',2).matrix().evalf(chop=True)

#-----------------------------------------------------------------------------
# random single qubit U and two-qubit CU gates

class Urand(UGate):
    gate_name = u'U'
    gate_name_latex = u'U'
    random_seed = 617

    @classmethod
    def _eval_args(cls, args):
        if not len(args)==1:
            raise Exception("Urand gate arguments should be target_qubit")
        if not type(args[0])==int:
            raise Exception("Urand gate arguments should be target_qubit")
        targets = (args[0],)
        targets = Gate._eval_args(targets)
        numpy.random.seed(cls.random_seed)
        A = numpy.matrix(10*(numpy.random.rand(2,2) + (0+1j) * numpy.random.rand(2,2)))
        U = scipy.linalg.expm(A + A.H)
        mat = Matrix(U)
        return (targets, mat)

    @property
    def gate_name_plot(self):
        return '$U$'

    def _print_targets(self,printer,*args):
        return '%s,%s' % (self.label[0][0],self.label[2])
    def _print_contents_latex(self, printer, *args):
        return r'%s\left(%s\right)' % (self.gate_name_latex, sympy.latex(self.label[2]))

    def plot_gate(self, circ_plot, gate_idx):
        circ_plot.one_qubit_box(
            self.gate_name_plot,
            gate_idx, int(self.targets[0])
        )

class CUrandGate(COneQubitGate):
    gate_name = u'CU'
    gate_name_latex = u'CU'
    one_qubit_gate = Urand

#-----------------------------------------------------------------------------
# Toffoli gate

class Toffoli(CGate):
    '''
    Example: Toffoli(ctrl1,ctrl2,target)
    '''
    gate_name = 'Toffoli'
    gate_name_latex = 'U_{tof}'
    
    @classmethod
    def _eval_args(cls, args):
        controls = (args[0],args[1])
        target = args[2]
        gate = GATES_DICT['X'](target)
        return (controls, gate)

    def _print_contents(self, printer, *args):
        # controls = self._print_sequence(self.controls, ',', printer, *args)
        return '%s(%s,%s,%s)' %\
            (self.gate_name, self.controls[0], self.controls[1], self.gate.label[0])

GATES_DICT['Toffoli'] = Toffoli

#=============================================================================
# turn string into sympy object

def my_sympify(expr,normphase=False,matrix=False,abcsym=False,do_qubit=False,do_ket=False,symtab=None):
    '''
    Parse a string expression expr, and return sympy math object.
    If abcsym=True, then treat (almost) all lowercase letters as real-valued symbols
    If matrix=True, and if expr is a list of lists, then return a Matrix.
    If normphase=True, and if expr is a list of numbers, then remove the overall phase.
    '''
    if do_ket and type(expr)==str or type(expr)==str:
        # expr = re.sub('\|([01]+?)>',r"qubit('\1')",expr.lower().replace('\n','').replace('\r',''))
        expr = re.sub('|([01]+?)>',r"qubit('\1')",expr.lower().replace('\n','').replace('\r',''))
        # expr = re.sub('\|(.*?)>',r"Ket(\1)",expr.lower().replace('\n','').replace('\r',''))

    # make all lowercase real?
    if not symtab==None:
        varset = symtab
    else:
        varset = {'p':sympy.Symbol('p',real=True),
                  'g':sympy.Symbol('g',real=True),
                  'e':sympy.E,			# for exp
                  'i':sympy.sympify('I'),		# lowercase i is also sqrt(-1)
                  'X':sympy.sympify('Matrix([[0,1],[1,0]])'),
                  'Y':sympy.sympify('Matrix([[0,-I],[I,0]])'),
                  'Z':sympy.sympify('Matrix([[1,0],[0,-1]])'),
                  'choose':sympy.Function('choose'),	# binomial
                  }
    if do_ket:
        do_qubit = True

    if do_qubit:		# turn qubit(...) into Qubit instance
        varset.update({'qubit':sympy.physics.quantum.qubit.Qubit,
                       'Ket':sympy.physics.quantum.state.Ket,
                       'dot':dot,
                       'bit':sympy.Function('bit'),
                       })
    if abcsym:			# consider all lowercase letters as real symbols, in the parsing
        for letter in string.lowercase:
            if letter in varset:	# exclude those already done
                continue
            varset.update({letter:sympy.Symbol(letter,real=True)})

    sexpr = sympy.sympify(expr,locals=varset)
    if normphase:	# remove overall phase if sexpr is a list
        if type(sexpr)==list:
            if sexpr[0].is_number:
                ophase = sympy.sympify('exp(-I*arg(%s))' % sexpr[0])
                sexpr = [ sympy.Mul(x,ophase) for x in sexpr ]

    def to_matrix(x):		# if x is a list of lists, and is rectangular, then return Matrix(x)
        if not type(x)==list:
            return x
        for row in x:
            if (not type(row)==list):
                return x
        rdim = len(x[0])
        for row in x:
            if not len(row)==rdim:
                return x
        return sympy.Matrix(x)

    if matrix:
        sexpr = to_matrix(sexpr)
    return sexpr

#=============================================================================
# Routine to generate image of given quantum circuit

def circuit2image(circuit,nqubits):
    '''
    Generate image of circuit, using CircuitPlotSVG
    Return SVG
    '''
    cp = CircuitPlotSVG(circuit, nqubits=nqubits)
    return str(cp.svg)

#=============================================================================
# interface

def str2state(s):
    #return sympy.sympify(s)
    return eval(s)

def str2circuit(s):
    s = s.strip()
    s = s.replace('\n','').replace('\r','')

    if not s.startswith('['):
        s = '[' + s
    if not s.endswith(']'):
        s += ']'

    try:
    	clist = eval(s, GATES_DICT)
    except Exception as err:
        raise Exception("Cannot parse circuit spec %s" % s)

    #print "clist = ",clist
    if not type(clist)==list:
        raise Exception("Input circuit should be a list, eg [ H(0), CNOT(0,1) ]")
    circuit = reduce(sympy.Mul,clist[::-1])	# multiply together in reverse order
    return circuit

def to_latex(x,inline=False,dott=False,istex=False,br="<br/>"):
    xs = x if istex else sympy.latex(x) 
    xs = xs.replace(r'\XI','XI')	# workaround for strange greek
    mj = 'mathjax%s' % ('inline' if inline else '')
    if xs[0]=='$': xs = xs[1:-1]	# for sympy v6
    # return '[%s]%s[/%s]<br/>' % (mj,xs[1:-1],mj)	# for sympy v6
    if dott: xs = '{\\tt{ %s } }' % xs
    return '[%s]%s[/%s]%s' % (mj,xs,mj,br)		# for sympy v7

def to_latex_old(x):
    xs = sympy.latex(x)
    if xs[0]=='$':
        return '[mathjax]%s[/mathjax]<br/>' % (xs[1:-1])	# for sympy v6
    return '[mathjax]%s[/mathjax]<br/>' % (xs)		# for sympy v7

def vec2latex(x):	# return qubit representation of a state vector (or list)
    if type(x)==sympy.Matrix:
        if not x.shape(1)==1:
            return to_latex(x)	# abort
        vec = x
    elif type(x)==list:
        vec = Matrix(x)
    else:
        return to_latex(x)	# abort
    nq = math.log(vec.shape[0],2)
    if not int(nq)==nq:
        return to_latex(x)	# abort
    return to_latex(matrix_to_qubit(vec))

def circuit2tex(circ,nqubits):
    return to_latex(represent(circ,nqubits=nqubits))

def state2vec(state):
    return represent(state)

def circuit2mat(circuit,nqubits):
    return represent(circuit,nqubits=nqubits)

def stateDimension(state):
    return len(represent(state))

def stateNQubits(state):
    return int(math.log(stateDimension(state),2))

def circuitOutput(circuit,nqubits):
    instate = Qubit('0'*nqubits)
    outstate = qapply(circuit*instate)
    return outstate

#-----------------------------------------------------------------------------


class SceneSVG:
    def __init__(self,name="svg",height=400,width=400):
        self.name = name
        self.items = []
        self.height = height
        self.width = width
        return

    def add(self,item): self.items.append(item)

    def strarray(self):
        var = ['<svg  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height=\"%d\" width=\"%d\" >\n' % (self.height,self.width),
               " <g style=\"fill-opacity:1.0; stroke:black;",
               "  stroke-width:1;\" >\n"]
        for item in self.items: var += item.strarray()            
        var += [" </g>\n</svg>\n"]
        return var

    def write_svg(self,filename=None):
        if filename:
            self.svgname = filename
        else:
            self.svgname = self.name + ".svg"
        file = open(self.svgname,'w')
        file.writelines(self.strarray())
        file.close()
        return

    def __str__(self):
        '''
        Return SVG as string
        '''
        return ''.join(self.strarray())

    def display(self,prog='open -a firefox'):
        os.system("%s %s" % (prog,self.svgname))
        return        

class Line:
    def __init__(self,start,end,color,width):
        self.start = start
        self.end = end
        self.color = color
        self.width = width
        return

    def strarray(self):
        return ["  <line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" style=\"stroke:%s;stroke-width:%d\"></line>\n" %\
                (self.start[0],self.start[1],self.end[0],self.end[1],colorstr(self.color),self.width)]

class Circle:
    def __init__(self,center,radius,fill_color,line_color,line_width):
        self.center = center
        self.radius = radius
        self.fill_color = fill_color
        self.line_color = line_color
        self.line_width = line_width
        return

    def strarray(self):
        return ["  <circle cx=\"%d\" cy=\"%d\" r=\"%d\"" %\
                (self.center[0],self.center[1],self.radius),
                "    style=\"fill:%s;stroke:%s;stroke-width:%d\"></circle>\n" % (colorstr(self.fill_color),colorstr(self.line_color),self.line_width)]

class Ellipse:
    def __init__(self,center,radius_x,radius_y,fill_color,line_color,line_width):
        self.center = center
        self.radiusx = radius_x
        self.radiusy = radius_y
        self.fill_color = fill_color
        self.line_color = line_color
        self.line_width = line_width
    def strarray(self):
        return ["  <ellipse cx=\"%d\" cy=\"%d\" rx=\"%d\" ry=\"%d\"" %\
                (self.center[0],self.center[1],self.radius_x,self.radius_y),
                "    style=\"fill:%s;stroke:%s;stroke-width:%d\"></ellipse>\n" % (colorstr(self.fill_color),colorstr(self.line_color),self.line_width)]

class Polygon:
    def __init__(self,points,fill_color,line_color,line_width):
        self.points = points
        self.fill_color = fill_color
        self.line_color = line_color
        self.line_width = line_width
    def strarray(self):
        polygon="<polygon points=\""
        for point in self.points:
            polygon+=" %d,%d" % (point[0],point[1])
        return [polygon,\
               "\" \nstyle=\"fill:%s;stroke:%s;stroke-width:%d\"></polygon>\n" %\
               (colorstr(self.fill_color),colorstr(self.line_color),self.line_width)]

class Rectangle:
    def __init__(self,origin,height,width,fill_color,line_color,line_width):
        self.origin = origin
        self.height = height
        self.width = width
        self.fill_color = fill_color
        self.line_color = line_color
        self.line_width = line_width
        return

    def strarray(self):
        return ["  <rect x=\"%d\" y=\"%d\" height=\"%d\"" %\
                (self.origin[0],self.origin[1],self.height),
                "    width=\"%d\" style=\"fill:%s;stroke:%s;stroke-width:%d\"></rect>\n" %\
                (self.width,colorstr(self.fill_color),colorstr(self.line_color),self.line_width)]

class Text:
    def __init__(self,origin,text,size,color):
        self.origin = origin
        self.text = text
        self.size = size
        self.color = color
        return

    def strarray(self):
        return ["  <text x=\"%d\" y=\"%d\" font-size=\"%d\" fill=\"%s\" style='text-anchor: middle; dominant-baseline:middle'>\n" %\
                (self.origin[0],self.origin[1],self.size,colorstr(self.color)),
                "   %s\n" % self.text,
                "  </text>\n"]

class ForeignObject:
    def __init__(self, origin, text, size):
        self.origin = origin
        self.text = text
        self.size = size
        return

        # <foreignObject x="100" y="100" width="100" height="100">
        # <div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Times; font-size:15px">
        # \(\displaystyle{x+1\over y-1}\)
        # </div>
        # </foreignObject>

    def strarray(self):
        return ["  <foreignObject x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\">\n" %\
                (self.origin[0],self.origin[1], self.size[0], self.size[1]),
                '<div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Times; font-size:12px; font-color:blue;">\n',
                "   %s\n" % self.text,
                "</div> </foreignObject>\n"]

def colorstr(rgb): 
    if rgb=='none':
        return rgb
    colors = {'black': (0,0,0),
              'white': (255,255,255),
              'red': (255,0,0),
              'green': (0,255,0),
              'blue': (0,0,255),
          }
    if rgb in colors:
        rgb = colors[rgb]
    return "#%x%x%x" % (int(rgb[0]/16), int(rgb[1]/16), int(rgb[2]/16))


def test_svg():
    scene = SceneSVG("test")
    scene.add(Rectangle((100,100),200,200,(0,255,255),(0,0,0),1))
    scene.add(Line((200,200),(200,300),(0,0,0),1))
    scene.add(Line((200,200),(300,200),(0,0,0),1))
    scene.add(Line((200,200),(100,200),(0,0,0),1))
    scene.add(Line((200,200),(200,100),(0,0,0),1))
    scene.add(Circle((200,200),30,(0,0,255),(0,0,0),1))
    scene.add(Circle((200,300),30,(0,255,0),(0,0,0),1))
    scene.add(Circle((300,200),30,(255,0,0),(0,0,0),1))
    scene.add(Circle((100,200),30,(255,255,0),(0,0,0),1))
    scene.add(Circle((200,100),30,(255,0,255),(0,0,0),1))
    scene.add(Text((50,50),"Testing SVG",24,(0,0,0)))
    scene.write_svg()
    assert(os.path.exists('test.svg'))
    assert('Testing SVG' in str(scene))
    # scene.display()

#-----------------------------------------------------------------------------

class CircuitPlotSVG(object):
    """A class for managing an SVG circuit plot."""

    xscale = 40.0
    yscale = 60.0
    fontsize = 20.0
    linewidth = 2.0
    scale = yscale
    control_radius = 0.08 * scale
    not_radius = 0.20 * scale
    box_width = 0.30 * scale
    box_height = 0.30 * scale
    swap_delta = 0.10 * scale

    def __init__(self, c, nqubits, **kwargs):
        self.name = "qc"
        self.circuit = c
        self.ngates = len(self.circuit.args)
        self.nqubits = nqubits
        self.update(kwargs)
        self._create_grid()
        self._create_figure()
        self._plot_wires()
        self._plot_gates()
        self._finish()

    def update(self, kwargs):
        """Load the kwargs into the instance dict."""
        self.__dict__.update(kwargs)

    def _create_grid(self):
        """Create the grid of wires."""
        xscale = self.xscale
        yscale = self.yscale
        wire_grid = numpy.arange(self.nqubits*yscale, 0.0, -yscale, dtype=float)	# y locations
        gate_grid = numpy.arange(0.0,self.ngates*xscale, xscale, dtype=float)	# x locations
        self._wire_grid = wire_grid - 0.5*yscale
        self._gate_grid = gate_grid + xscale

    def _create_figure(self):
        """Create the main matplotlib figure."""
        self.svg = SceneSVG(self.name, width=(self.ngates+1)*self.xscale, height=(self.nqubits+0.2)*self.yscale)

    def _plot_wires(self):
        """Plot the wires of the circuit diagram."""
        xstart = self._gate_grid[0]
        xstop =  self._gate_grid[-1]
        xdata = (xstart-self.xscale, xstop+self.xscale)
        for i in range(self.nqubits):
            ydata = (self._wire_grid[i], self._wire_grid[i])
            line = Line((xdata[0], ydata[0]), (xdata[1], ydata[1]), 'black', self.linewidth)
            self.svg.add(line)

    def _plot_gates(self):
        gates = []
        #print "circuit args: ",self.circuit.circuit.args
        for g in reversed(self.circuit.args):	# don't use circuit.circuit.args because Mul collapses same gates together!
            #print "considering ",g
            if isinstance(g, Mul):		# if Mul then coefficient in front of gate; take last arg as gate
                g = g.args[-1]
            if 'plot_gate' in dir(g):
                gates.append(g)
        for i, gate in enumerate(gates):
            # print "i=%d, gate=%s" % (i,gate)
            gate.plot_gate(self, i)

    def _plot_gates_old(self):
        """Iterate through the gates and plot each of them."""
        gates = []
        if isinstance(self.circuit, Mul):
            for g in reversed(self.circuit.args):
                if isinstance(g, Gate):
                    gates.append(g)
        elif isinstance(self.circuit, Gate):
            gates.append(self.circuit)
        for i, gate in enumerate(gates):
            gate.plot_gate(self, i)

    def _finish(self):
        # Disable clipping to make panning work well for large circuits.
        #for o in self.svg.findobj():
        #    o.set_clip_on(False)
        return

    def one_qubit_box(self, t, gate_idx, wire_idx, use_mathjax=False, width=1):
        """Draw a box for a single qubit gate."""
        x = self._gate_grid[gate_idx]
        y = self._wire_grid[wire_idx]
        dx = self.box_width*width
        dy = self.box_height
        self.svg.add(Rectangle([x-dx, y-dy], 2*dy, 2*dx, 'white', 'black', self.linewidth))
        if not use_mathjax:
            t = t[1:-1]
            self.svg.add(Text([x,y], t, size=self.fontsize, color='blue'))
        else:
            self.svg.add(ForeignObject([x-dx+2,y-dy+5],t, [2*dx, 2*dy]))

    def control_line(self, gate_idx, min_wire, max_wire):
        """Draw a vertical control line."""
        xdata = (self._gate_grid[gate_idx], self._gate_grid[gate_idx])
        ydata = (self._wire_grid[min_wire], self._wire_grid[max_wire])
        radius = self.not_radius
        self.svg.add(Line((xdata[0], ydata[0]), (xdata[1], ydata[1]), 'black', self.linewidth))

    def control_point(self, gate_idx, wire_idx):
        """Draw a control point."""
        x = self._gate_grid[gate_idx]
        y = self._wire_grid[wire_idx]
        radius = self.control_radius
        c = Circle((x,y), radius, 'blue', 'black', self.linewidth)
        self.svg.add(c)

    def not_point(self, gate_idx, wire_idx):
        """Draw a NOT gates as the circle with plus in the middle."""
        x = self._gate_grid[gate_idx]
        y = self._wire_grid[wire_idx]
        radius = self.not_radius
        self.svg.add(Circle((x,y), radius, 'none', 'black', self.linewidth))
        self.svg.add(Line((x,y-radius), (x,y+radius), 'black', self.linewidth))
        self.svg.add(Line((x-radius,y), (x+radius,y), 'black', self.linewidth))

    def swap_point(self, gate_idx, wire_idx):
        """Draw a swap point as a cross."""
        x = self._gate_grid[gate_idx]
        y = self._wire_grid[wire_idx]
        d = self.swap_delta
        self.svg.add(Line((x-d,y-d), (x+d,y+d), 'black', self.linewidth))
        self.svg.add(Line((x-d,y+d), (x+d,y-d), 'black', self.linewidth))

#-----------------------------------------------------------------------------

def test_circuit_svg():
    c = str2circuit('H(0), CNOT(0,1)')
    cp = CircuitPlotSVG(c, 2)
    cp.svg.write_svg()
    # cp.svg.display()
    print(cp.svg)
    assert('<line x1="80" y1="90" x2="80" y2="30" style="stroke:#000;stroke-width:2"></line>' in str(cp.svg))

#=============================================================================
# answer checking routines

def parse_options(options, allow_multiple=False):
    '''
    Parse an "options" argument to a customresponse problem.  Returns dict.

    If allow_multiple then values in the dict are lists; this allows
    a key to have multiple values.
    '''
    if allow_multiple:
        odict = defaultdict(list)
    else:
        odict = {}
    if options is not None:
        options = options.replace('&amp;gt;', '>')	# hmm.  issues with escaping greater-than symbol!
        for option in options.split(';'):
            m = re.match(r'(\w+)=(.+)', option)
            if m:
                if allow_multiple:
                    odict[m.group(1)].append(m.group(2))
                else:
                    odict[m.group(1)] = m.group(2)
    return odict

def test_parse_options():
    options="altanswer=III XII III;altanswer=III III XII" 
    odict = parse_options(options, allow_multiple=True)
    assert('altanswer' in odict)
    assert("III XII III" in odict['altanswer'])

#-----------------------------------------------------------------------------
# test quantum circuit output (uses qpython)

def check_qcircuit_output(expect, ans, options=None):

    displaymat = True

    if options is not None:
        for option in options.split(';'):
            if 'expect' in option:
                expect = option.split('=',1)[-1]

    if '__AND__' in expect:			# multiple cases (typically used when testing multiple inputs)
        (ex1,ex2) = expect.split('__AND__')
        ret = check_qcircuit_output(ex1,ans)
        if not ret['ok']:
            return ret
        return check_qcircuit_output(ex2,ans)

    if '__NOMAT__' in expect:
        displaymat = False
        expect = expect.replace('__NOMAT__','')

    inprep = None
    if ';' in expect:
        (inprep,expect) = expect.split(';')		# allowed syntax = input prepration circuit ; expected state

    try:
        state = str2state(expect)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating state from %s' % (err,expect)}

    if inprep:
        try:
            inprep = str2circuit(inprep)
        except Exception as err:
            return{'ok':False,'msg': 'Error %s our input state prepration circuit from %s' % (err,inprep)}

    try:
        circuit = str2circuit(ans)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating circuit from %s' % (err,ans)}
    nqubits = stateNQubits(state)

    url = circuit2image(circuit,nqubits)

    try:
        if inprep:
            circuit = circuit * inprep
        outstate = circuitOutput(circuit,nqubits)
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s computing output of circuit %s' % (err,ans)}

    #is_ok = (outstate==state)
    is_ok = (outstate.evalf()==state.evalf())

    # debugging
    # return {'ok':is_ok, 'msg': 'output of your circuit %s is %s, expected %s' % (circuit,outstate,state)}

    msg = 'Graphical rendition of your circuit :<center>%s</center>' % (url)

    #if displaymat:
    #    tex = circuit2tex(circuit,nqubits)
    #    msg += '<br/>Unitary transform: %s' % (tex)

    return {'ok':is_ok, 'msg':msg}

#-----------------------------------------------------------------------------
# compare two quantum circuits (uses qpython)

def check_qcircuit_compare(expect, ans, options=None):
    '''
    see if expected and given quantum circuits are the same, based on comparing their matrix forms
    
    example options:

      options="nqubits=1;NUMERICAL=1;EXCLUDE=[T,Rx,Ry,Rz]" 
      options="nqubits=2;NUMERICAL=1;altanswer=[CPHASE(1,0),H(1)]" 

    '''

    odict = parse_options(options)
    nqubits = int(odict.get('nqubits', 0))
    excludeset = eval(odict.get('EXCLUDE', '[]'), GATES_DICT)
    altanswer = odict.get('altanswer', '')
    enable_urand = odict.get('RANDU', False)
    skiptex = odict.get("SKIPTEX", False)
    expect = odict.get("expect", expect)

    if enable_urand:
        GATES_DICT['U'] = Urand
        GATES_DICT['CU'] = CUrandGate

    try:
        expect_circ = QuantumCircuit(expect,nqubits)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating OUR circuit from %s' % (err,expect)}

    if altanswer:
        try:
            alt_circ = QuantumCircuit(altanswer, nqubits)
        except Exception as err:
            return{'ok':False,'msg': 'Error %s creating OUR circuit from %s' % (err, altanswer)}

    try:
        # circuit = str2circuit(ans)
        circuit = QuantumCircuit(ans, nqubits, excludeset=excludeset)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating circuit from %s' % (err,ans)}

    try:
        # url = circuit2image(circuit,nqubits)
        svg = circuit.plot(xscale=70, box_width=0.50*60)
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s drawing your circuit %s' % (err,ans)}
        
    if skiptex:
        tex = None
    else:        
        if odict.get('NUMERICAL', False):
            tex = to_latex(circuit.matrix().evalf(chop=True))
        else:
            tex = circuit.matrix_tex()

    if enable_urand:				# set random number generator seed using current time
        Urand.random_seed = int(time.time()) % 32767

    try:
        ansmat = circuit.matrix()
        # ansmat = circuit2mat(circuit,nqubits)
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s computing matrix for circuit %s' % (err,ans)}
       
    def do_is_ok(ecirc, amat):
        threshold = 0.001
        expectmat = ecirc.matrix()
        dm = (amat-expectmat).evalf(chop=True)
        return abs(dm.vec().norm().evalf())<threshold

    if enable_urand:		# using random unitary - repeat check 5 times, with different seeds
        okset = [0] * 5
        for k in range(5):
            okset[k] = do_is_ok(expect_circ, ansmat)
            Urand.random_seed = 2 * Urand.random_seed
            ansmat = circuit.matrix()
        is_ok = all(okset)
    else:
        is_ok = do_is_ok(expect_circ, ansmat)
        if (not is_ok) and altanswer:
            is_ok = do_is_ok(alt_circ, ansmat)

    if skiptex:
        msg = 'Graphical rendition of your circuit :<center>%s</center><br/>' % (svg)
    else:
        msg = 'Graphical rendition of your circuit :<center>%s</center><br/>Unitary transform: %s' % (svg, tex)
    return {'ok':is_ok, 'msg': msg}


def test_check_qcircuit_compare1():
    expect="[H(0)]" 
    options="nqubits=1;EXCLUDE=[H]"
    ans = "[H(0)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    assert('Error Gate H(0) not allowed in the quantum circuit creating circuit from [H(0)]' in ret['msg'])
    assert(not ret['ok'])

def test_check_qcircuit_compare2():
    expect="[H(0)]" 
    options="nqubits=1;EXCLUDE=[H]"
    ans = "[Z(0),Ry(0,pi/2)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    assert('Graphical rendition of your circuit' in ret['msg'])
    assert(ret['ok'])

def test_check_qcircuit_compare3():
    expect="[T(0)]" 
    options="nqubits=1;EXCLUDE=[T,H]"
    ans = "[exp(i*pi/8) *Rz(0,pi/4)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    assert('Graphical rendition of your circuit' in ret['msg'])
    assert(ret['ok'])

def test_check_qcircuit_compare4():
    expect="[CPHASE(1,0),H(0)]" 
    options="nqubits=2;NUMERICAL=1;altanswer=[CPHASE(1,0),H(1)]" 
    ans = "[CPHASE(1,0),H(1)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    assert('Graphical rendition of your circuit' in ret['msg'])
    assert(ret['ok'])

def test_check_qcircuit_compare5():
    expect="[CPHASE(2,1),Z(0)]" 
    options="nqubits=3;NUMERICAL=1" 
    ans = "[Z(0),H(2),CNOT(1,2),H(2)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    assert('Graphical rendition of your circuit' in ret['msg'])
    assert(ret['ok'])

def test_check_qcircuit_compare_randU1():
    expect="[H(0),CU(0,1),H(0)]" 
    options="nqubits=2;NUMERICAL=1;RANDU=1;SKIPTEX=1" 
    ans = "[H(0),CU(0,1),H(0),H(0),H(0)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    print("ok = %s" % ret['ok'])
    assert('Graphical rendition of your circuit' in ret['msg'])
    assert(ret['ok'])

def test_check_qcircuit_compare_randU2():
    expect="[H(0),CU(0,1),H(0)]" 
    options="nqubits=2;NUMERICAL=1;RANDU=1;SKIPTEX=1" 
    ans = "[H(0),CU(0,1)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    print("ok = %s" % ret['ok'])
    assert('Graphical rendition of your circuit' in ret['msg'])
    assert(not ret['ok'])

def test_check_qcircuit_compare_randU3():
    expect="[H(0),CU(0,1),H(0)]" 
    options="nqubits=2;NUMERICAL=1;RANDU=1;SKIPTEX=1" 
    ans = "[H(0),CNOT(0,1)]"
    ret = check_qcircuit_compare(expect, ans, options)
    print(ret['msg'])
    print("ok = %s" % ret['ok'])
    assert('Graphical rendition of your circuit' in ret['msg'])
    assert(not ret['ok'])
    
#-----------------------------------------------------------------------------
# compare OUTPUT of two quantum circuits (uses qpython)

def check_qcircuit_compare_output(expect, ans, options=None):

    # (nqubits,expect) = expect.split(';')

    odict = parse_options(options)
    nqubits = int(odict.get('nqubits', 0))

    try:
        expect_circ = str2circuit(expect)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating OUR circuit from %s' % (err,expect)}

    try:
        circuit = str2circuit(ans)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating circuit from %s' % (err,ans)}

    try:
        url = circuit2image(circuit,nqubits)
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s drawing your circuit %s' % (err,ans)}
        
    # tex = circuit2tex(circuit,nqubits)

    try:
        outstate = circuitOutput(circuit,nqubits)
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s computing output of circuit %s' % (err,ans)}

    try:
        state = circuitOutput(expect_circ,nqubits)
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s computing output of OUR circuit %s' % (err,ans)}

    tex = to_latex(outstate)
    is_ok = (outstate.evalf()==state.evalf())

    return {'ok':is_ok, 'msg':'Graphical rendition of your circuit :<center>%s</center><br/>Output: %s' % (url,tex)}

#-----------------------------------------------------------------------------
# partial trace of density matrix - using sympy

def is_square_matrix(state):
    '''
    returns True if state is a square matrix.
    '''
    if type(state)==sympy.Matrix:	# see if is square sympy Matrix
        (n,m) = state.shape
        if n==m:
            return True
        return False
    if not type(state)==list:		# see if square list of lists
        return False
    for row in state:
        if not (type(row)==list):
            return False
    rdim = len(state[0])
    for row in state:
        if not len(row)==rdim:
            return False
    return True

def kron(m1,m2):
    '''
    Return Kronecker (tensor) product of two matrices, M = M1 otimes M2.
    We use the convention that the "least-sigificant matrix" is the right-most matrix.
    And we take M2 as the right-most of the two matrices.  
    '''
    if m1==None:	# if no m1 supplied, just return m2
        return m2 
    lm = []
    def row_join(x,y):	# append rows of two matrices
        return [sympy.flatten(list(z)) for z in zip(x,y)]
        
    for r in m1.tolist():	# iterate over rows of m1
        lmr = reduce(row_join,[ (c * m2).tolist() for c in r ])	# compute c * m2 for each element of the row
        lm += lmr		# append rows to the matrix we're building as a list
    return sympy.Matrix(lm)

def is_denmat(m):
    '''
    Returns True if m is a valid density matrix (only works for numerical matrice...)
    '''
    if not m.trace()==1:
        return False
    return (m==m.H)

def rdbasis(nq,qubits=[],bset=[],rdmat=None,smat=None,n=0):
    '''
    construct basis for reduced density matrix, together with corresponding basis for state
    do this recursively.  Note that qubits are numbered starting with zero, with the
    zero^th qubit being the right-most digit in the label.

    qubits = list of qubits to trace over
    nq = number of qubits in resulting reduced density matrix
    bset = list where reduced basis matrices are to be stored.  returns pairs (rdm,sm)
           where rdm is in the space of the rdm, and sm is in the state space (pre-reduction).
    '''

    I = sympy.Matrix([[1,0],[0,1]])
    X = sympy.Matrix([[0,1],[1,0]])
    Y = sympy.Matrix([[0,-sympy.I],[sympy.I,0]])
    Z = sympy.Matrix([[1,0],[0,-1]])
    # global I, X, Y, Z

    curqubit = nq-1-n
    #print "curqubit = ",curqubit
    if curqubit<0:		# done with adding more operators - return
        bset.append([rdmat,smat])
        #print "rdmat=",rdmat.tolist()
        #print "smat=",smat.tolist()
        return bset
    if curqubit in qubits:	# are we tracing over the current qubit?
        # don't add any operator to rdmat, and add only I to smat
        return rdbasis(nq,qubits,bset,rdmat,kron(smat,I),n+1)
    # add all four operators I,X,Y,Z 
    for op in [I,X,Y,Z]:
        #print "  op=",op.tolist()
        rdbasis(nq,qubits,bset,kron(rdmat,op),kron(smat,op),n+1)
    return bset

def ptrace(state,qubits):
    '''
    Return the partial trace of the given state, over the specified qubits.
    The state should have a dimension which is a power of two.
    The state may be a vector or a matrix (or a list or list of lists)
    The specified qubits should be a list of integers, ranging from zero to log_2(dim(state))-1.
    The returned state is a sympy Matrix.

    Examples:

    In [210]: ptrace(Matrix([[1,0,0,0],[0,2,0,0],[0,0,3,0],[0,0,0,4]])/10,0)
    Out[210]: 
              [3/10,    0]
              [   0, 7/10]
    
    In [206]: ptrace(Matrix([1,1,1,0])/sqrt(3),0)
    Out[206]: 
              [2/3, 1/3]
              [1/3, 1/3]    

    '''
    if type(qubits)==int:
        return ptrace(state,[qubits])
    if type(state)==list:
        if not type(state[0])==list:	# is state a vector (pure state)?
            state = sympy.Matrix(state)	# convert to column vector
            return ptrace(state * state.H,qubits)	# transform to matrix and recurse to self
    if type(state)==sympy.Matrix:
        (nr,nc) = state.shape
        if nc==1:			# state is vector
            return ptrace(state * state.H,qubits)	# transform to matrix and recurse to self
    if is_square_matrix(state):
        if type(state)==list:
            state = sympy.Matrix(state)
    if not is_square_matrix(state):
        raise Exception('[ptrace] input state must be a square matrix!  state shape=%s' % repr(state.shape))

    # double check that input is properly normalized
    if not state.trace()==1:
        print("[ptrace] warning, 1 != trace(state) = ",state.trace())

    nq = int(math.log(state.shape[0],2))		# number of qubits in state
    #print "state = ",state.tolist()
    #print "nq = ",nq

    # We now use the fact that any density matrix can be written as a weighted sum of
    # tensor products of pauli matrices.  Namely,
    #
    # rho = \sum_{k} C_k \sigma_{k_0}\otimes \sigma_{k_1}\otimes \cdots \sigma_{k_n}
    #
    # where k is a base-4 number, and k_0, k_1, ... are the digits of k.  The coefficients
    # are given by
    #
    # C_k = Tr(rho * \sigma_{k_0}\otimes \sigma_{k_1}\otimes \cdots \sigma_{k_n}) * 2^{-n}
    #
    # by virtue of the trace orthogonality of the Pauli matrices.
    #
    # Given this representation, the partial trace over the jth qubit is thus given by
    #
    # Tr_j(rho) = \sum_{k'} C_{k'} \sigma_{k'_0}\otimes \sigma_{k'_1}\otimes \cdots \sigma_{k'_{n-1}}
    #
    # where k' now has n-1 digits, and the coefficients are given by
    #
    # C_{k'} = Tr(rho * \sigma_{k_0}\otimes \cdots \otimes I \otimes \cdots \sigma_{k_n}) * 2^{-n}
    #
    # ie the identity matrix is inserted in place of \sigma_{k_j}.

    rdb = []
    rdbasis(nq,qubits,rdb)
    #print "[ptrace] len(rdb)=",len(rdb)
    rstate = None
    for (rdmat,smat) in rdb:
        x = (state*smat).trace() * rdmat	# weighted sum over basis matrices
        if rstate == None:
            rstate = x
        else:
            rstate += x

    rstate /= 2**(nq-len(qubits))
    return(rstate)

def check_ptrace(expect_in, ans_in, nq):
    '''
    Check to see if partial trace over qubit 0 of ans gives the expected density matrix.
    '''
    try:
        expect = my_sympify(str(expect_in),matrix=True)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s parsing OUR expression %s' % (err,expect_in)}
        
    try:
        ans = my_sympify(str(ans_in), do_qubit=True, do_ket=True)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s parsing your expression %s' % (err,ans_in)}

    msg0 = '<p/>Your expresion was parsed as %s' % to_latex(ans)
    msg0 += '<p/>= %s' % vec2latex(ans)
    
    # ans should be a pure state, ie a list
    #if not type(ans)==list:
    #    msg = 'Error: your expression should be a vector (ie a list), eg [1,0].'
    #    msg += msg0
    #    return{'ok':False,'msg': msg}

    ans = represent(ans)	# transform to column matrix

    if not len(ans)==(2**nq):
        msg = 'Error: your expression should be a %d-qubit state vector' % nq
        msg += msg0
        return{'ok':False,'msg': msg}
        
    rdm = ptrace(ans,0)

    # ok = (rdm.evalf()==expect.evalf())
    sfc = SympyFormulaChecker()
    ok = sfc.sympy_is_formula_equal(rdm, expect)
    return{'ok':ok,'msg': msg0}
        
def check_ptrace_2qubit(expect_in, ans_in, options=None):
    return check_ptrace(options, ans_in, nq=2)

def test_ptrace1():
    expect="[[3/10,0],[0,7/10]]"
    ans = "sqrt(3/10)*|00> +sqrt(7/10)*|11>"
    ret =  check_ptrace_2qubit('', ans, expect)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_ptrace2():
    expect="[[3/10,0],[0,7/10]]"
    ans = "sqrt(3/10)*|01> +sqrt(7/10)*|10>"
    ret =  check_ptrace_2qubit('', ans, expect)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_ptrace3():
    expect="[[3/10,0],[0,7/10]]"
    ans = "sqrt(3/10)*|10> +sqrt(7/10)*|01>"
    ret =  check_ptrace_2qubit('', ans, expect)
    print(ret['msg'])
    assert(ret['ok']==False)

#-----------------------------------------------------------------------------
# test state with |0110> notation

# from tutor.python_lib.sympy_check import check

def ket2state(ket,var=False):
    """
    Use string replacement to change |xxx> to qubit('xxx'), for xxx in {0,1}*
    if var=True, then allow strings for xxx, but change to Ket(xxx)
    """
    if not var:
        return re.sub('|([01]+?)>',r"qubit('\1')",ket.lower().replace('\n','').replace('\r',''))
    return re.sub('|(.*?)>',r"Ket(\1)",ket.lower().replace('\n','').replace('\r',''))

def check_quantum_state_ket(expect,ans):
    try:
        ret = check(ket2state(expect),ket2state(ans),matrix=True,do_qubit=True)
    except Exception as err:
        return {'ok': False,
                'msg': 'Error %s<br/>Failed in evaluating check(%s,%s)' % (err,expect,ans)
                }
    return ret

def check_quantum_state_varket(expect,ans):
    try:
        ret = check(ket2state(expect,var=True),ket2state(ans,var=True),matrix=True,do_qubit=True)
    except Exception as err:
        return {'ok': False,
                'msg': 'Error %s<br/>Failed in evaluating check(%s,%s)' % (err,expect,ans)
                }
    return ret

#-----------------------------------------------------------------------------

def my_chop(v,thresh=1e-8):
    '''
    Take a quantum state and chop all numerical coefficients (below default 1e-8 threshold) to zero.
    '''
    v = v.expand().evalf(chop=True)
    def chop(x):
        if 'is_real' in dir(x) and x.is_real and abs(x)<thresh: return 0
        return x
    if isinstance(v,sympy.Mul):
        return sympy.Mul(*[chop(x) for x in v.args])
    if isinstance(v,sympy.Add):
        return sympy.Add(*[my_chop(x) for x in v.args])	# recurse
    return chop(x)

def states_equal_up_to_phase(x,y,zq=None):
    '''
    Try and determine if two quantum states are equal, up to a global phase.
    Return True if equal, False if cannot tell.
    '''
    
    if x==y: return True
    if x==-y: return True
    if x==sympy.I * y: return True
    if x==-sympy.I * y: return True

    if x.evalf()==y.evalf(): return True

    try:
        ip = qapply(Dagger(y)*x)
        # print "ip=", ip
        if abs(ip.evalf())==1: return True
    except Exception as err:
        pass
    
    if zq is None: return False

    sfc = SympyFormulaChecker(do_quantum=True)

    try:
        # phase = (y.coeff(zq) / x.coeff(zq))
        phase = sympy.simplify(represent(y)[0,0] / represent(x)[0,0])
        # print("[qpython4.states_equal_up_to_phase] phase=%s, ycoef=%s, xcoef=%s, x=%s, y=%s" % (phase, y.coeff(zq), x.coeff(zq), x, y)) # DEBUG
        if (x*phase).evalf() == y.evalf(): return True
        if (x*phase-y).evalf() == 0: return True
        ok = sfc.sympy_is_formula_equal(x*phase, y)	# more robust equality check
        if ok: return True
        # print '(1) phase=%s, x=%s, y=%s' % (phase,x,y)
    except Exception as err:
        print('Warning, error %s while trying phase difference check' % err)
        try:
            print("[qpython4.states_equal_up_to_phase] phase=%s, ycoef=%s, xcoef=%s, x=%s, y=%s" % (phase, y.coeff(zq), x.coeff(zq), x, y))
        except Exception as err:
            pass
    
    def zqcoeff(s):
        v = s.as_independent(zq)[1]	# get part dependent on zq
        return v.as_coefficient(zq)	# separate coefficient from zq, and return

    try:
        zqcx = zqcoeff(x)
        if zqcx is not None:
            phase = zqcoeff(y) / zqcx
            if (x*phase).evalf() == y.evalf(): return True
            if (x*phase-y).evalf() == 0: return True
            ok = sfc.sympy_is_formula_equal(x*phase, y)	# more robust equality check
            if ok: return True
        else:
            # print("[states_up_to_phase] x=%s, y=%s, zqcx=%s, zqcy=%s" % (x, y, zqcx, zqcoeff(y)))
            pass
        # print '(2) phase=%s, x=%s, y=%s' % (phase,x,y)
    except Exception as err:
        print('Warning, error %s while trying phase difference check, traceback=%s' % (err, traceback.format_exc()))
    
    return False


#-----------------------------------------------------------------------------
# class for single qubit clifford group gates

class Clifford1Gate(object):
    '''
    Representation of single qubit Clifford group elements.
    These are generated by H (Hadamard) and S (phase gate), and thus we represent
    the group element as a string with characters in 'HSXYZ', where the order of operation is from
    left to right.
    '''
    def __init__(self,cgstr):
        if type(cgstr)==str:
            cgstr = str(MathUnicodeToAscii(cgstr)).strip()
        if type(cgstr)==str:			# if it is a string
            self.string_to_cge(cgstr)
        else:
            raise Exception("[CliffordElement] Error - can't import '%s'" % (cgstr))
        
    def string_to_cge(self,s):
        '''
        Takes a string of H,S and import this to become our gate.
        '''
        s = s.replace(' ','').upper()
        m = re.match('([IHSXYZ]+)$',s)
        if not m:
            msg = '<p>Cannot parse "%s" into a one-qubit clifford group element.' % s
            msg += '<br/>Input should be a string with characters from "HSXYZ"; the order of operation is from left to right'
            raise Exception(msg)
        self.cge = m.group(1)

    def circuit(self,qubit=1,nqubits=1):	# return circuit representation of self
        if self.cge=='I': return CliffordCircuit('[]',nqubits)
        return CliffordCircuit('[%s]' % (','.join(['%s(%d)' % (x,qubit) for x in self.cge])),nqubits)

    def inverse_circuit(self,qubit=1,nqubits=1):	# return circuit representation of inverse of self
        inv = self.cge[::-1].replace('S','SSS')
        while 'SSSS' in inv:
            inv = inv.replace('SSSS','')
        return Clifford1Gate(inv).circuit(qubit,nqubits)

    def __str__(self):
        return self.cge

    __repr__ = __str__

    def __eq__(self,other):
        '''
        Compute equality of two Clifford Group operations based on equality of their maps of X,Y,Z
        '''
        mymap = self.conjugate(['X','Y','Z'])
        othermap = other.conjugate(['X','Y','Z'])
        return mymap==othermap

    CliffordMaps = {'H': {'X':'Z',
                          'Y':'-Y',
                          'Z':'X'},
                    'S': {'X':'Y',
                          'Y':'-X',
                          'Z':'Z'},
                    'X': {'X':'X',
                          'Y':'-Y',
                          'Z':'-Z'},
                    'Y': {'X':'-X',
                          'Y':'Y',
                          'Z':'-Z'},
                    'Z': {'X':'-X',
                          'Y':'-Y',
                          'Z':'Z'},
                    'I': {'X':'X',
                          'Y':'Y',
                          'Z':'Z'},
                    }
    
    def conjugate(self,p):
        '''
        Act upon the Pauli operator p (a character from 'XYZ') and return the resuting Pauli operator.
        '''
        if type(p)==list:
            return [self.conjugate(x) for x in p]

        # sop = Matrix([[1,0],[0,I]])
        # sx = Matrix([[0,1],[1,0]])
        # sy = Matrix([[0,-I],[I,0]])
        # sop*sy*sop.H
        # sop*sx*sop.H

        mysign = 1
        for op in self.cge:			# loop over all clifford group operators in our string
            mapout = self.CliffordMaps[op][p]
            if mapout[0]=='-': mysign *= -1	# handle sign changes
            p = mapout[-1]			# take last character as output of map
        return ('-' if mysign<0 else '') + p

#-----------------------------------------------------------------------------
# class for two qubit clifford group gates

class Clifford2Gate(object):
    '''
    Representation of two qubit Clifford group elements.
    We deal with the CNOT and SWAP for now.
    '''
    def __init__(self,cgstr):
        if type(cgstr)==str:
            cgstr = str(MathUnicodeToAscii(cgstr)).strip()
        if type(cgstr)==str:			# if it is a string
            self.string_to_cge(cgstr)
        else:
            raise Exception("[CliffordElement] Error - can't import '%s'" % (cgstr))
        
    def string_to_cge(self,s):
        '''
        Just CNOT and SWAP for now.
        '''
        s = s.replace(' ','').upper()
        if not s in ['CNOT','SWAP']:
            msg = '<p>Cannot parse "%s" into a two-qubit clifford group element.' % s
            msg += '<br/>Input should be CNOT (nothing else right now)'
            raise Exception(msg)
        self.cge = [s]

    def __str__(self):
        return ' '.join(self.cge)

    __repr__ = __str__

    CliffordMaps = {'CNOT': {'II':'II',
                             'IX':'IX',
                             'IY':'ZY',
                             'IZ':'ZZ',
                             'XI':'XX',
                             'YI':'YX',
                             'ZI':'ZI',
                             },
                    'SWAP': {'II':'II',
                             'IX':'XI',
                             'IY':'YI',
                             'IZ':'ZI',
                             'XI':'IX',
                             'YI':'IY',
                             'ZI':'IZ',
                             },
                    }
    
    def conjugate(self,p):
        '''
        Act upon the two-qubit Pauli operator p (two characters from 'XYZ') and return the resuting Pauli operator.
        '''
        if type(p)==list:
            return [self.conjugate(x) for x in p]

        mysign = 1
        pout = StabilizerElement('II')
        for op in self.cge:			# loop over all clifford group operators in our string
            for k in range(2):			# loop over operators in p from left to right
                g = ['I']*2
                g[k] = p[k]
                mapout = self.CliffordMaps[op][''.join(g)]
                pout *= StabilizerElement(mapout)
        return pout.string

#-----------------------------------------------------------------------------
# class for stabilizer element

class StabilizerElement(object):
    '''
    Representation of a single stabilizer set element.
    This can be, for example, ZXZI, or -X, or -IX.
    Internally, this is represented as a string, but equivalently
    it may be represented as a binary matrix row [ Xbits | Zbits ].
    It may also be a sympy quantum circuit (tensor product of Pauli gates).

    attributes:

      - nq        : number of qubits which this stabilizer acts upon
      - matrix    : binary matrix representation of this stabilizer
      - string    : string representation of this stabilizer (with sign, if not +)
      - circuit   : sympy quantum circuit representation of this stabilizer
      - op        : 2**nq by 2**nq matrix operator representation of this stabilizer
      - basis     : vector space basis (+1 eigenvalue eigenvector space) for this stabilizer
      - weight    : returns the Pauli weight -- the number of non I operators in this stabilizer 

      self.string_no_sign is an internal attribute which should not be used externally.  Instead, use
      self[k] to retrieve the kth element of the Pauli operator string for this stabilizer element.

    methods:

      - init      : construct using StabilizerElement(s) where s is a string, eg 'IXXY'
                    alternatively, s can be a binary matrix row (a sympy Matrix)
      - __mul__   : returns product of self * other, where other should be another StabilizerElement
      - __eq__    : equality test for two StabilizerElements
      - conjugate : Transforms this stabilizer element by conjugation, eg se.conjugate('H')
                    May also specify which qubit(s) the operator is to act upon.
      - commutes  : For se.commutes(s), returns true if s commutes with this stabilizer

    '''
    def __init__(self,stab='I',sign=None):
        if type(stab)==type(sympy.eye(0)):	# if it is a Matrix (ie binary matrix row)
            stab = self.binary_row_to_string(stab)
        if type(stab)==str:
            #stab = str(stab).strip()
            stab = str(MathUnicodeToAscii(stab)).strip()
        if type(stab)==str:			# if it is a string
            # (self.string_no_sign, self.sign, self.nq) = 
            self.string_to_stabilizer(stab,sign)
        else:
            raise Exception("[StabilizerElement] Error - can't import %s as a stabilizer element" % (stab))

    def __str__(self):
        return self.string

    __repr__ = __str__

    def binary_row_to_string(self,row):
        '''
        Return IXYZ string representation of a given binary matrix row representation [xrow yrow].
        '''
        nq = int(len(row)/2)
        paulis = 'IXZY'
        xss = [x[0]+x[1]*2 for x in zip(row[:nq],row[nq:])]
        return ''.join([paulis[x] for x in xss])

    def string_to_binary_row(self):
        '''
        Return a binary matrix row representation of ourself.
        The binary matrix has 1's for X's on the left, and 1's for
        Z's on the right.

        Note that this ignores signs.
        '''
        x2bin = {'X':1,'Y':1,'Z':0,'I':0}
        z2bin = {'X':0,'Y':1,'Z':1,'I':0}
        g = self.string
        while g[0] in '-i':
            g = g[1:]
        xrow = [x2bin[s.upper()] for s in g]
        zrow = [z2bin[s.upper()] for s in g]
        return sympy.Matrix(xrow+zrow).T

    matrix = property(string_to_binary_row,None,None,'Binary matrix row representation of stabilizer')

    def __getitem__(self,k):
        return self.string_no_sign[k]

    def qubit_pauli(self,k,nosign=False):
        '''
        Return the Pauli for a specific qubit, with sign (unless nosign=True)
        '''
        p = self.string_no_sign[self.nq-1-k]
        if not nosign:
            signs = {-1:'-',sympy.I:'i',-sympy.I:'-i',+1:'',sympy.sympify('-1'):'-',sympy.sympify('1'):''}
            p = signs[self.sign]+p
        return p

    def string_to_stabilizer(self,s,sign=None):
        '''
        Takes a string of Pauli operators (leading minus sign ok), validates it, and
        imports the string to become our state (stabilizer element), stored
        as three pieces of information: self.string_no_sign, self.sign, and self.nq
        '''
        s = s.replace(' ','')
        m = re.match('-I+$',s)	# disallow -I (and -II, -III...)
        if m:
            msg = '<p>%s cannot be an element of a stabilizer, by definition' % s
            raise Exception(msg)

        m = re.match('(-*)([XYZI]+)$',s)
        if not m:
            msg = '<p>Cannot parse "%s" into a stabilizer.' % s
            msg += '<br/>Input should be of the form "XIY"'
            msg += '<br/>Spaces, lowercase letters, and a leading minus sign are acceptable.'
            raise Exception(msg)
        self.sign = -1 if (m.group(1)=='-') else +1
        self.string_no_sign = m.group(2)
        self.nq = len(self.string_no_sign)
        if not sign==None:
            self.sign = sign

    def make_string(self):
        signs = {-1:'-',sympy.I:'i',-sympy.I:'-i',+1:'',sympy.sympify('-1'):'-',sympy.sympify('1'):''}
        #return ('-' if self.sign==-1 else '') + self.string_no_sign
        return signs[self.sign] + self.string_no_sign
    string = property(make_string,string_to_stabilizer,None,'string representation of stabilizer element')

    def make_circuit(self):
        '''
        Return a sympy quantum circuit representation of the stabilizer element
        '''
        def c2g(cn):
            return GATES_DICT[cn[0]](cn[1]) if (cn[0] in 'XYZ') else 1
        gates = [c2g(x) for x in zip(self.string_no_sign,list(range(self.nq-1,-1,-1)))]
        circuit = reduce(sympy.Mul,gates[::-1])	# multiply together in reverse order
        if self.sign==-1:
            circuit = -circuit
        return circuit

    circuit = property(make_circuit,None,'sympy quantum circuit representation of the stabilizer element')

    def __mul__(self,other):
        '''
        Return product of self * other, where other should be another StabilizerElement
        '''
        if not type(other)==StabilizerElement:
            raise Exception("Can't multiply StabilizerElement by %s" % other)

        def PauliProdStr(a,b):	# product a*b of two Pauli operators a, b represented as strings
            i = sympy.I
            if a=='I': return (1,b)	# return (sign,new-op-string)
            if b=='I': return (1,a)
            if a==b: return (1,'I')
            pmm = {'X': {'Y':(i,'Z'),'Z':(-i,'Y')},
                   'Y': {'Z':(i,'X'),'X':(-i,'Z')},
                   'Z': {'X':(i,'Y'),'Y':(-i,'X')},
                   }
            return pmm[a][b]

        newsign = self.sign * other.sign
        # don't use binary matrix for multiplication - looses track of the sign
        #newmatrix = self.matrix + other.matrix				# pauli multiplication is binary matrix addition
        #newmatrix = newmatrix.applyfunc(lambda x: int(x)&1)		# do addition modulo 2
        #return StabilizerElement(newmatrix,sign=newsign)

        pps = list(map(PauliProdStr,self.string_no_sign,other.string_no_sign))
        #print "pps = ",pps
        newsigns, newstring = list(zip(*pps))
        newsign *= reduce(operator.mul,newsigns)
        newstring = ''.join(newstring)
        return StabilizerElement(newstring,sign=newsign)

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.__dict__ == other.__dict__	# for StabilizerElement, this is {nq, sign, string_no_sign}
        else:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):				# need this for equality testing of sets of StabilizerElements
        return self.string.__hash__()

    def conjugate_2cg(self,op,qubits=None,verbose=True):		# conjugate stabilizer by two-qubit Clifford
        '''
        Transform the stabilizer element by conjugation: S -> op * S * op^dagger

        op is a two-qubit Clifford gate (Clifford2Gate).  qubits should specify a pair of qubits.
        '''
        if not len(qubits)==2:
            raise Exception('conjugate_2cg should be called with qubits being a length 2 list of qubit indices')
        if qubits[0]==qubits[1]:
            raise Exception('conjugate_2cg should be called with qubits being a length 2 list of DIFFERENT qubit indices')

        newstring = [x for x in self.string_no_sign]
        old = self.string
        
        nqm = self.nq-1			# beware: qubit indexing 0=right-most symbol, but string indexing happens from left
        try:
            p = newstring[nqm-qubits[0]] + newstring[nqm-qubits[1]]
        except IndexError:
            raise Exception('conjugate_2cg: illegal qubit indices %s, nqubits=%d' % (str(qubits),self.nq))
        newp = op.conjugate(p)
        newstring[nqm-qubits[0]] = newp[-2]
        newstring[nqm-qubits[1]] = newp[-1]
        self.sign *= -1 if newp[0]=='-' else +1
        self.string_no_sign = ''.join(newstring)
        if verbose:
            print('op=%s%s : %s -> %s' % (op,str(qubits),old,self.string))
        return self

    def conjugate(self,op,qubits=None,verbose=True):			# conjugate stabilizer by operation
        '''
        Transform the stabilizer element by conjugation: S -> op * S * op^dagger
        op must be in the Clifford group.  More specifically, op must be in IXYZHS, or CNOT,SWAP.
        We use built-in tables to perform the transformation.
        
        if op is a single letter, then assume op acts on each of the qubits.
        if op is a string of len(self.nq), then act on each qubit correspondingly.
        if op is CNOT or SWAP, then qubits should specify pair of qubit indices (0=right-most-label), with the
        first index being the control, and the second being the target.

        qubits specifies which qubits to act upon (list of integers) - defaults to all qubits
        '''
        if op in ['CNOT','SWAP']:
            return self.conjugate_2cg(Clifford2Gate(op),qubits,verbose)
        elif type(op)==Clifford2Gate:
            return self.conjugate_2cg(op,qubits,verbose)
        else:
            m = re.match('[HSXYZI]+$',op)
            if not m:
                raise Exception('Error: conjugation of stabilizer element can only be computed for op in IXYZHS')
        if len(op)==1:
            if not qubits:
                op = op*self.nq
            else:
                opstr = ['I']*self.nq
                for nk in qubits: opstr[self.nq-nk-1]=op
                op = ''.join(opstr)
        old = self.string
        #newstring = ['I']*self.nq
        newstring = [x for x in self.string_no_sign]
        if not qubits:
            qubits = list(range(self.nq))
        for nk in qubits:
            if nk > (self.nq-1) or nk<0:
                raise Exception("StabilizerElement %s has only %d qubits, can't act on qubit %s" % (self.string,self.nq,nk))
            k = self.nq - nk - 1		# qubit 0 is the right-most operator in the stabilizer element
            g = self.string_no_sign[k]
            if not g=='I':
                #mapout = CliffordGates[op[k]][g]
                mapout = Clifford1Gate(op[k]).conjugate(g)
                newstring[k] = mapout[-1]	# do transformation on stabilizer string
                self.sign *= -1 if (mapout[0]=='-') else +1
                # print "  (%d) %s -> %s" % (k,g,mapout)
        self.string_no_sign = ''.join(newstring)
        if verbose:
            print('op=%s : %s -> %s' % (op,old,self.string))
        return self

    def make_op(self):
        '''
        Construct matrix operator representation of the stabilizer element, given by the
        tensor product of all the Pauli operators.  The resulting matrix is square and
        has dimension 2**(self.nq), ie it acts on an nq qubit state.
        '''
        I = sympy.Matrix([[1,0],[0,1]])
        X = sympy.Matrix([[0,1],[1,0]])
        Y = sympy.Matrix([[0,-sympy.I],[sympy.I,0]])
        Z = sympy.Matrix([[1,0],[0,-1]])
        
        str2mat = {'I':I,'X':X,'Y':Y,'Z':Z}

        return self.sign * reduce(kron,[str2mat[x] for x in self.string_no_sign])

    op = property(make_op,None,None,'matrix operator representation of stabilizer element')
    
    def make_basis(self):
        '''
        Return vector space basis for the +1 eigenspace of this stabilizer element.
        The result is a sympy Matrix with rows being the (unnormalized) eigenvectors.
        '''
        evset = self.op.eigenvects()
        if evset[0][0]==1:
            evset = evset[0]	# get the +1 eigenspace
        else:
            evset = evset[1]
        m = sympy.Matrix(evset[2])
        if m.shape[1]==1:	# bug in sympy: need to reshape
            m = m.reshape(evset[1],m.shape[0]/evset[1])
        return m

    basis = property(make_basis,None,None,'vector space basis for stabilizer element')

    def compute_weight(self):
        '''
        Return the Pauli weight (the number of non-I operators) in this stabilizer
        '''
        s = self.string_no_sign
        return s.count('X')+s.count('Y')+s.count('Z')

    weight = property(compute_weight,None,None,'Return the Pauli weight (the number of non-I operators) in this stabilizer')

    def commutes(self,s):
        '''
        Return True if the stabilizer element s commutes with ourself.
        Otherwise return False.
        s should be a StabilizerElement.
        '''
        if not type(s)==StabilizerElement:
            raise Exception('Argument to StabilizerElement.commutes must be a StabilizerElement')
        if not s.nq==self.nq:
            raise Exception('Argument to StabilizerElement.commutes must be a StabilizerElement of same number of qubits')
        return self*s == s*self

    def is_identity(self):
        '''
        Return True if the stabilizer is the identity
        '''
        return self.string_no_sign == 'I'*self.nq

    def is_orthogonal(self,s):
        '''
        Return True if the stabilizer is orthogonal to s (another StabilizerElement)
        '''
        if not type(s)==StabilizerElement:
            raise Exception('Argument to StabilizerElement.is_orthogonal must be a StabilizerElement')
        if not s.nq==self.nq:
            raise Exception('Argument to StabilizerElement.is_orthogonal must be a StabilizerElement of same number of qubits')
        p = (s*self)
        return p.is_identity

#-----------------------------------------------------------------------------
# class for stabilizer set

class Stabilizer(StabilizerElement):
    '''
    Representation of a stabilizer set.  Provides methods for inputting string or list
    representations of a stabilizer set.  Provides methods for outputting string, binary,
    and circuit representations of the stabilizer set

    attributes (other than those inherited from StabilizerElement):

      - stabilizer_set : set of StabilizerElements for this stabilizer set
      - strings        : list of string representations of the elements in this stabilizer set
      - circuits       : list of circuit representations of the elements in this stabilizer set
      - signs          : list of the signs of stabilizer elements in this stabilizer set
      - cs_dict        : list of dicts of circuit and string representations
      - nops           : number of stabilizer elements in this stabilizer set
      - n              : same as nops
      - k              : number of qubits in the space stabilized by this stbailizer set
      - basis          : vector space basis for simultaneous +1 eigenvalue eigenvector space for thsi stabilizer set
      - qubit_basis    : sympy quantum Qubit representation of stabilized vector space basis
      
    methods (other than those inherited from StabilizerElement):

      - check_if_stabilizes    : return dict with 'ok':True if state given is stabilized by this stabilizer set
      - is_independent        : returns dict with 'ok':True if this stabilizer set has independent elements
      - is_commutative        : returns dict with 'ok':True if all elements in this stabilizer set commute with each other
      - is_good_generators    : returns dict with 'ok':True if elements in this stabilizer set commute and are independent
      - all_stabilizers       : returns set of all StabilizerElements generated by this stabilizer set
      - conjugate             : conjugates all elements in this stabilizer set by the given Clifford group operator
      - commutes              : returns dict with 'ok':True if all elements in this set commute with the given StabilizerElement

    '''

    def __init__(self,stabset='[I]'):
        self.stabilizer_set = None			# set of StabilizerElements for this stabilizer set
        self.sympmat = None				# binary matrix version of stabilizer set
        if type(stabset)==list:
            if type(stabset[0])==StabilizerElement:
                self.stabilizer_set = stabset
                self.nq = self.stabilizer_set[0].nq	# should do some error checking to make sure all are same size
                return
        if type(stabset)==str:			# convert unicode to string
            stabset = str(MathUnicodeToAscii(stabset)).strip()
            # stabset = str(stabset).strip()
        if type(stabset)==str:
            stabset = stabset.strip()			# remove leading and trailing spaces
        if type(stabset)==str and stabset[0]=='[':	# string with list, eg '[IX,XI]'
            self.string_to_stabilizerset(stabset)
        elif type(stabset)==str and ',' in stabset:	# one string but with a comma -> error
            msg = '<p>Error: a stabilizer set should be specified by a list, eg [IX,XI] (don\'t forget the brackets)'
            raise Exception(msg)
        elif type(stabset)==str:			# just one string, eg 'IXYZ'
            self.string_to_stabilizerset('['+stabset+']')
        else:
            msg = '<p>Error: unknown input "%s"' % stabset
            msg += '<br/>a stabilizer set should be specified by a list, eg [IX,XI] (don\'t forget the brackets)'
            raise Exception(msg)
        # todo: input binary form

    def __str__(self):
        return '[%s]' % (','.join(self.strings))

    __repr__ = __str__

    def make_strings(self):
        return [x.string for x in self.stabilizer_set]

    strings = property(make_strings,None,None,'list of string representations of the elements in the stabilizer set')

    def make_signs(self):
        return [x.sign for x in self.stabilizer_set]

    signs = property(make_signs,None,None,'list of signs of stabilizers in the stabilizer set')

    def make_circuits(self):
        return [x.circuit for x in self.stabilizer_set]

    circuits = property(make_circuits,None,None,'list of circuit representations of stabilizers in the stabilizer set')

    def __getitem__(self,k):
        return self.stabilizer_set[k]

    def check_if_stabilizes(self,state,msg=''):
        '''
        Return ok:True if state is stabilized by our stabilizer set
        '''
        # if state is a list, then run ourself on each element on the list
        if type(state)==list:
            for k in state:
                ret = self.check_if_stabilizes(k,msg)
                if not ret['ok']:
                    return ret
            return ret

        # see if ans_state is a +1 eigenstate of all the stabilizer generators
        for g in self.cs_dict:
            try:
                qastate = qapply(g['circuit']*state)
                ok = (qastate==state)
                if not ok:				# fallback to expansion, fixes (...)/sqrt(...) failure
                    ok = (qastate==sympy.expand(state))
            except Exception as err:
                msg += '<p>Error %s' % err
                msg += '<p>Failed in applying the stabilizer operator %s to the state %s' % (to_latex(g['str']),to_latex(state))
                # msg +='<br/>Input should be an expression with kets, eg (|011>+|101>)/sqrt(2)'
                raise Exception(msg)
            if not ok:
                msg += '<br/>Your state is not a +1 eigenstate of %s' % to_latex(g['str'])
                msg += '<br/>=%s' % to_latex(g['circuit'])
                break
        return {'ok':ok,'msg':msg}

    
    def string_to_stabilizerset(self,s):
        '''
        Imports a string like "[XI,IX,ZZ]" as a stabilizer set
        '''
        m = re.match('\[([XYZI,\-]+)\]',s.replace(' ','').strip().upper())
        if not m:
            msg = '<p>Cannot parse "%s" into a set of stabilizer generators.  ' % s
            msg += '<br/>Input should be of the form "[-XII,IZI,IZY]"'
            msg += '<br/>Spaces and lowercase letters are acceptable.'
            raise Exception(msg)
        sset = m.group(1).split(',')
        self.stabilizer_set = [StabilizerElement(x) for x in sset]
        # make sure all are the same length
        self.nq = self.stabilizer_set[0].nq
        for s in self.stabilizer_set:
            if not self.nq==s.nq:
                msg = '<p>Error: all stabilizer operators should act on the same number of qubits!'
                msg += '<br/>Offending operator: %s' % s.string
                raise Exception(msg)
    
    def get_cs_dict(self):	# return a list of dicts of circuit and string representations
        return [{'circuit':x[1],'str':x[0],'sign':x[2]} for x in zip(self.strings,self.circuits,self.signs)]

    cs_dict = property(get_cs_dict,None,None,'list of dicts of circuit and string representations')

    def get_binary_matrix(self):
        if self.sympmat:
            return self.sympmat
        self.sympmat = self.stabilizerStrings2binary()
        return self.sympmat
        
    def set_binary_matrix(self,sympmat=None):
        '''
        Set the stabilizer to the be given binary matrix, and build the corresponding stabilizer strings & circuits.
        '''
        if not sympmat==None:
            self.sympmat = sympmat
        self.stabilizer_set = []
        for k in range(sympmat.shape[0]):	# construct IXYZ string for each row
            self.stabilizer_set.append(StabilizerElement(sympmat[k,:]))

    matrix = property(get_binary_matrix,set_binary_matrix,None,"binary representation of stabilizer set")

    def number_of_operators(self):
        return len(self.strings)

    nops = property(number_of_operators,None,None,"number of stabilizer operators in set")
    n = nops

    def qubit_dimension_stabilized(self):
        return self.nq - self.n			# for [[n,k]] return k, assuming generators are linearly independent

    k = property(qubit_dimension_stabilized,None,None,'number of qubits in space stabilized')

    def stabilizerStrings2binary(self):
        '''
        Return a binary matrix representation of the stabilizer set.
        '''
        mat = [x.string_to_binary_row() for x in self.stabilizer_set]
        return sympy.Matrix(mat)
    
    def is_independent(self,msg=''):
        '''
        Checks to see if our stabilizer set is linearly independent.
        '''
        return self.make_independent(testonly=True,msg=msg)

    def is_independent_from_set(self,s,sset=None):
        '''
        Checks to see if a given StabilizerElement s is independent of our set.

        Do this with brute force: see if s is in the set of stabilizers generated by our set.
        '''
        if s.is_identity(): return False
        if sset==None: sset = self.stabilizer_set
        if len(sset)==0: return True
        def stab_recurse(snum,stab):		# recusre, and find all products of generators, turning one on at a time
            if snum==len(sset):
                # print "  ",stab
                if stab==s: raise Exception("Not Independent")
                return True
            stab_recurse(snum+1,stab)
            if sset[snum] is not None:
                stab_recurse(snum+1,stab * sset[snum])	# uses __mul__ of StabilizerElement
            return True

        try:
            stab_recurse(0,StabilizerElement('I'*self.nq))
        except Exception as err:
            if str(err)=="Not Independent":
                return False
            raise Exception(err)
        return True
      
    def make_independent(self,verbose=True,testonly=False,msg=''):
        '''
        Remove any non-independent stabilizers from the set.
        If testonly=True, then do not do the removal, just return error message.

        Do this using brute force, with is_indepenent_from_set method.
        '''
        sset = self.stabilizer_set
        for k in range(self.n):
            if sset[k].is_identity():
                if verbose: print("%s is identity" % sset[k])
                if testonly:
                    msg += "<br/>%s is identity" % sset[k]
                    return {'ok':False,'msg':msg}
                sset[k] = None				# mark for removal from set
                continue
            if k==0: continue
            # print "testing %s against %s" % (sset[k],sset[0:k])
            if not self.is_independent_from_set(sset[k],sset=sset[0:k]):
                if testonly:
                    msg += "%s is not independent from %s" % (sset[k],sset[0:k])                
                    return {'ok':False,'msg':msg}
                if verbose: print("%s is not independent from %s" % (sset[k],sset[0:k]))
                sset[k] = None				# mark for removal from set
        if testonly: return {'ok':True,'msg':msg}
        while None in sset:				# remove dropped stabilizer elements
            sset.remove(None)
        self.sympmat = None				# force re-computation of binary matrix

    def old_make_independent(self,verbose=True,testonly=False,msg=''):
        '''
        Remove any non-independent stabilizers from the set.
        If testonly=True, then do not do the removal, just return error message.
        '''
        stabmat = self.matrix[:,:]			# copy of matrix
        (nr,nc) = stabmat.shape
        # go through all pairs, and check for linear independence
        # do this by subtracting dot product with all previous rows 
        if self.stabilizer_set[0].is_identity():	# drop first row if it is identity
            self.stabilizer_set[0] = None
        for r in range(1,nr):
            g1 = stabmat[r,:]
            if sum(g1)==0:				# if the sum(row)=0 it is identity (I), so drop it
                self.stabilizer_set[r] = None
                continue
            for s in range(r):
                g2 = stabmat[s,:]
                #print "  g1=%s, g2=%s" % (g1,g2)
                if g1.dot(g2):
                    g1 = (g1 - g2).applyfunc(abs)	# subtract dot product
            if not sum(g1):				# not linearly independent: zero it
                if testonly:
                    msg += "<p>Stabilizer set NOT linearly independent."
                    msg += "<br/>'%s' and '%s' are not orthogonal" % (self.binary_row_to_string(g1),
                                                                     self.binary_row_to_string(g2))
                    return {'ok':False,'msg':msg}
                self.matrix[r,:] = sympy.Matrix([0]*nc).T
                if verbose:
                    print("Removed '%s'" % self.stabilizer_set[r].string)
                self.stabilizer_set[r] = None
            else:
                stabmat[r,:] = g1			# do gaussian elimination, so independence check works
        if testonly:
            return {'ok':True,'msg':msg}
        #if verbose: print "stabmat = %s" % stabmat
        while None in self.stabilizer_set:			# remove dropped stabilizer elements
            self.stabilizer_set.remove(None)
        self.sympmat = None				# force re-computation of binary matrix

    def is_commutative(self,msg=''):
        '''
        Checks to see if all elements in our stabilizer set commute with each other.
        '''
        stabmat = self.matrix
        nr = stabmat.shape[0]
        nq = int(stabmat.shape[1]/2)		# number of qubits (should always be int)
        # go through all pairs, and check for commutativity
        for r in range(1,nr):
            g1 = stabmat[r,:]
            X1 = g1[:nq]
            Z1 = g1[nq:]
            for s in range(r):
                g2 = stabmat[s,:]
                # twist product: multiply Z2 by X1 and X2 by Z1 and sum
                prod = Matrix(g2[nq:]).dot(X1) + Matrix(g2[:nq]).dot(Z1)
                if int(prod)&1:			# prod modulo 2 nonzero -> don't commute
                    msg += "<p>Stabilizer set NOT legal."
                    msg += "<br/>'%s' and '%s' do not commute" % (self.binary_row_to_string(g1),
                                                                 self.binary_row_to_string(g2))
                    return {'ok':False,'msg':msg}
        return {'ok':True,'msg':msg}

    def is_good_generators(self,msg=''):
        '''
        Checks to see if our stabilizer set is a good set of generators: linearly independent,
        does not contain -I, and all commute with each other
        '''

        minusI = '-'+('I'*self.nq)
        if minusI in self.strings:
            msg += '<p>Stabilizer set NOT legal: cannot contain %s' % minusI
            return {'ok':False,'msg':msg}

        ret = self.is_commutative(msg)
        if not ret['ok']: return ret

        ret = self.is_independent(msg)
        return ret

    def all_stabilizers(self):
        '''
        Return set of all stabilizers generated by our stabilizer set.
        For k independent generators, the set should have 2^k elements.
        '''
        self.make_independent(verbose=False)	# begin by making sure generators are independent
        aset = set()
        def stab_recurse(snum,stab,n):		# recusre, and find all products of generators, turning one on at a time
            #print "stab_recurse qn=%d, stab=%s, n=%d" % (snum,stab,n)
            if snum==n:
                aset.add(stab)
                return
            stab_recurse(snum+1,stab,n)
            stab_recurse(snum+1,stab * self.stabilizer_set[snum],n)	# uses __mul__ of StabilizerElement

        stab_recurse(0,StabilizerElement('I'*self.nq),self.n)
        return aset

    def conjugate(self,op,verbose=True):			# conjugate stabilizer set by operation
        '''
        Transform the stabilizer set by conjugation: S -> op * S * op^dagger
        op must be in the Clifford group.  More specifically, op must be in IXYZHS.
        We use StabilizerElement.conjugate.
        '''
        for s in self.stabilizer_set:
            s.conjugate(op,verbose)
        self.sympmat = None				# force re-computation of binary matrix
        return self

    def make_basis_via_projections(self):
        '''
        Compute vector space basis for simultaneous +1 eigenspace of this stabilizer set.
        Uses StabilizerElement.basis.  Projects basis spaces onto each other, taking
        only the nonzero result.

        Deprecated.

        Is this slower than finding eigenvalues just once (see new make_basis routine)?
        '''
        ret = self.is_commutative()
        if not ret['ok']:
            raise Exception('<p>Error: can\'t create basis unless stabilizer is legal set.'+ret['msg'])

        cbm = []			# cumulative basis matrix
        def project(b1,b2):
            #print "  projecting %s and %s" % (b1.tolist(),b2.tolist())
            cproj = []
            rm = b1 * b2.T * b2		# project
            for k in range(rm.rows):		# remove zero and duplicate rows
                myrow = rm[k,:]
                if myrow.norm()==0: continue
                dup = False
                for j in range(k):
                    if myrow.dot(rm[j,:]): dup = True
                if not dup: cproj.append(myrow)
            return sympy.Matrix(cproj)

        for s in self.stabilizer_set:
            b = s.basis
            cbm = b if not cbm else project(cbm,b)
        return cbm

    def make_basis(self):
        '''
        Compute vector space basis for simultaneous +1 eigenspace of this stabilizer set.
        Uses StabilizerElement.op, and computes basis as the 0-eigenvalue eigenvectors
        of (n*I - sum(op)).
        '''
        ret = self.is_commutative()
        if not ret['ok']:
            raise Exception('<p>Error: can\'t create basis unless stabilizer is legal set.'+ret['msg'])

        m = self.n*sympy.eye(2**self.nq)
        for g in self.stabilizer_set:
            m -= g.op
        evset = m.eigenvects()
        for ev in evset:		# eigenvalue, multiplicity, list-of-eigenvectors
            if ev[0]==0:
                basis = sympy.Matrix(ev[2])
                if basis.shape[1]==1:	# bug in sympy: need to reshape
                    basis = basis.reshape(ev[1],basis.shape[0]/ev[1])
                return basis
        return None

    basis = property(make_basis,None,None,'vector space basis for simultaneous +1 eigenspace of this stabilizer set')

    def make_qubit_basis(self):
        '''
        Return +1 eigennspace of this stabilizer set as a normalized quantum state, using sympy Qubit instances.
        If the space has more than one state, then return a list of basis states.
        '''
        vb = self.basis
        def int2bin(x, width):
            return ''.join(str((x>>i)&1) for i in range(width-1,-1,-1))

        stateset = []
        for r in range(vb.rows):
            state = 0
            csum = 0
            for c in range(vb.cols):
                if vb[r,c]:
                    x = vb[r,c]
                    state += x * Qubit(int2bin(c,self.nq))
                    csum += x * sympy.conjugate(x)
            state = state / sympy.sqrt(csum)
            state = sympy.simplify(state)
            stateset.append(state)

        return stateset[0] if len(stateset)==1 else stateset

    qubit_basis = property(make_qubit_basis,None,None,'qubit basis for simultaneous +1 eigenspace of this stabilizer set')

    def __eq__(self,other):
        return self.all_stabilizers() == other.all_stabilizers()	# equal if sets of all stabilizers are equal

    __hash__ = None

    def commutes(self,s,tf=False):
        '''
        Return dict "ok":True if the stabilizer element s commutes with all elements in our set.
        Otherwise return dict "ok":False with "msg" specifying which element anticommutes.
        s should be a StabilizerElement.
        '''
        for g in self.stabilizer_set:
            if not g.commutes(s):
                msg = '%s does not commute with generator %s' % (s,g)
                return False if tf else {'ok':False,'msg':msg}
        return True if tf else {'ok':True,'msg':''}

    def find_pauli_normalizers(self):
        '''
        Exhaustively search for all normalizers of this stabilizer set, which are not in the stabilizer set,
        and which are made of products of Pauli operators.

        More generally, normalizer elements could be in the Clifford group.

        The algorithm we use is simple but slow: recursively generate all possible stabilizer elements
        of the same number of qubits as those in this set, discard if in our set, otherwise check to see
        if it commutes with all elements in our set; keep if so.

        Also rule out elements which are products of already found normalizer elements and a group element.

        Checking independence is very slow.  We speed this up at a bit at the expense of using more memory,
        by keeping a huge list of all the elements generated so far by the stabilizer set and normalizer set found.

        '''
        normset = []
        identity = StabilizerElement('I'*self.nq)
        aset = list(self.all_stabilizers())

        def mkpauli(op,aset):				# recursive walk through all self.nq qubit Pauli operators
            if len(op)==self.nq:			# base case
                g = StabilizerElement(op)
                if g in aset: return
                # if not self.is_independent_from_set(g,sset=self.stabilizer_set+normset): return
                if not self.commutes(g,tf=True): return	# not a normalizer if it doesn't commute with this stabilizer set
                normset.append(g)
                aset += [g*x for x in aset]	# each normalizer doubles the size of the all-stabilizer-set 
            else:
                for x in 'IXYZ':
                    mkpauli(op+x,aset)

        mkpauli('',aset)
        return Stabilizer(normset)

    normalizers = property(find_pauli_normalizers,None,None,"Pauli group normalizer generator set for this stabilizer set")

    def is_normalizer(self,normset,check_not_stabilizer=True):
        '''
        Return dict with 'ok':True if the Stabilizer specified by normset is a normalizer of this stabilizer set.
        '''
        # see if they all commute with the stabilizer set generators
        for g in normset:
            if not g.nq==self.nq:
                return {'ok':False,'msg':'%s has the wrong number of qubits for stabilizer set' % g}
            if not self.commutes(g,tf=True):
                return {'ok':False,'msg':'%s does not commute with the stabilizer set' % g}

        if not check_not_stabilizer: return {'ok':True,'msg':''}

        # make sure none of the normalizers provided are generated by other normalizers times a stabilizer element

        aset = list(self.all_stabilizers())
        for g in normset:
            if g in aset:
                return {'ok':False,'msg':'%s is in the stabilizer set or a product of another normalizer and the stabilizer' % g}
            aset += [g*x for x in aset]

        # ok 
        return {'ok':True,'msg':''}

    def __mul__(self,other):
        '''
        Return product of set of (g * other), where other should be a StabilizerElement, for g in this stabilizer set
        '''
        if not type(other)==StabilizerElement:
            raise Exception("Can't multiply StabilizerElement by %s" % other)

        newss = [other * g for g in self.stabilizer_set]
        return Stabilizer(newss)

#-----------------------------------------------------------------------------
# Stabilizer tests

def test_stabilizer1():
    s = Stabilizer('[XXIZ, YXIY, IZIX]')
    assert(len(s.strings)==3)

def test_stabilizer2():
    s2 = Stabilizer('[XXIZ, YXIY, IZIX, ZZII, YYIZ, XYIY, ZIIX, IIII]')
    assert(len(s2.all_stabilizers())==16)

def test_stabilizer3():
    s2 = Stabilizer('[XXIZ, YXIY, IZIX, ZZII, -YYIZ, XYIY, ZIIX, IIII]')
    assert(len(s2.all_stabilizers())==8)

    s2.make_independent()
    assert(len(s2.strings)==3)
    assert('XXIZ' in s2.strings)
    assert('YXIY' in s2.strings)
    
def test_stabilizer3():
    s2 = Stabilizer('[XXIZ, YXIY, IZIX, ZZII, -YYIZ, XYIY, ZIIX, IIII]')
    s2.make_independent()
    s = Stabilizer('[XXIZ, YXIY, IZIX]')
    assert(s.all_stabilizers()==s2.all_stabilizers())

#-----------------------------------------------------------------------------
# stabilizer property checking

def check_stabilizer_state(expect, ans, options=None):
    '''
    Check to see if ans is a state stabilized by the generators given in the options
    string, for "stab".

    ans is a string; it should be given an expression with kets.
    '''
    try:
        odict = parse_options(options)
        expect = odict.get('stab', expect)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse OUR input "%s"' % options
        return {'ok':False,'msg':msg}

    sgenset = Stabilizer(expect)
    try:
        ans_state = my_sympify(ket2state(ans),do_qubit=True)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        msg +='<br/>Input should be an expression with kets, eg (|011>+|101>)/sqrt(2)'
        return {'ok': False, 'msg': msg}

    msg = 'Your input was parsed as %s' % to_latex(ans_state)
    
    ret = sgenset.check_if_stabilizes(ans_state,msg)
    return ret

def test_check_stabilizer_state():
    expect="See solutions"
    options="stab=[IIZZ,ZZII,XXXX]"
    ans = "(|0000> + |1111>)/sqrt(2)"
    ret = check_stabilizer_state(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_check_stabilizer_state2():
    expect="See solutions"
    options="stab=[IIZZ,ZZII,XXXX]"
    ans = ""
    ret = check_stabilizer_state(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==False)
    assert('Failed to parse' in ret['msg'])


def check_state_orthogonality(s1s,s2s):
    '''
    Return ok,msg checking if the states specified by the qubit/ket strings s1s and s2s are orthogonal
    '''
    try:
        s1 = my_sympify(ket2state(s1s),do_qubit=True)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % s1s
        msg +='<br/>Input should be an expression with kets, eg (|011>+|101>)/sqrt(2)'
        raise Exception(msg)
    try:
        s2 = my_sympify(ket2state(s2s),do_qubit=True)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % s2s
        msg +='<br/>Input should be an expression with kets, eg (|011>+|101>)/sqrt(2)'
        raise Exception(msg)
    ok = (qapply(Dagger(s1)*s2)==0)
    msg = "<p/>Orthogonality check of %s and %s" % (to_latex(s1),to_latex(s2))
    if not ok:
        msg = "<p/>States are not orthogonal!"
    return {'ok':ok,'msg':msg}


def check_stabilizer_state_pair(expect, ans, options=None):
    ret1 = check_stabilizer_state(expect, ans[0], options)
    if not ret1['ok']: 
        ret1['msg'] += "<p/>First state no good"
        return ret1

    ret2 = check_stabilizer_state(expect, ans[1], options)
    if not ret2['ok']: 
        ret2['msg'] += "<p/>Second state no good"
        return ret2

    ret3 = check_state_orthogonality(ans[0], ans[1])
    return ret3

def test_check_stabilizer_state_pair1():
    expect="See solutions"
    options="stab=[IIZZ,ZZII,XXXX]"
    ans1 = "(|0000>+|1111>)/sqrt(2)"
    ans2 = "(|0011>+|1100>)/sqrt(2)"
    ret = check_stabilizer_state_pair(expect, [ans1, ans2], options)
    print(ret['msg'])
    assert(ret['ok'])
    
def test_check_stabilizer_state_pair2():
    expect="See solutions"
    options="stab=[IIZZ,ZZII,XXXX]"
    ans1 = "(|0000>+|1111>)/sqrt(2)"
    ans2 = "(|0000>+|1111>)/sqrt(2)"
    ret = check_stabilizer_state_pair(expect, [ans1, ans2], options)
    print(ret['msg'])
    assert(not ret['ok'])

def check_stabilizer_generators(expect_in, ans, options=None):
    '''
    Check to see if ans is a legal set of stabilizer generators which stabilize the state
    given by expect.  The stabilizers in the generator set should be linearly independent.
    They should also commute with each other, and the set should not contain -I.

    options should be of the form "nq=3;state=|00>+|11>" where nq gives an integer, the number of
    qubits in the space stabilized by the state specified.

    '''

    try:
        odict = parse_options(options)
        nq = int(odict.get('nq', 0))
        expect = odict.get('state', expect_in)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse OUR input "%s"' % urllib.parse.urlencode(options)
        return {'ok':False,'msg':msg}

    try:
        expect = expect.replace('?','>')	# hack: so that kets can be specified as |00? instead of |00>
        state = my_sympify(ket2state(expect),do_qubit=True)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse OUR input "%s"' % expect
        return {'ok':False,'msg':msg}

    try:
        sgenset = Stabilizer(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        return {'ok':False,'msg':msg}

    msg = '<p>Your input parsed as "%s"' % str(sgenset)

    if not sgenset.k==nq:
        msg += "<br/>Oops, your stabilizer set is too small; it stabilizes a space of %d qubits" % sgenset.k
        return {'ok':False,'msg':msg}

    ret = sgenset.is_good_generators(msg)
    if not ret['ok']:
        return ret

    try:
        ret = sgenset.check_if_stabilizes(state,msg)
    except Exception as err:
        msg = '<p>Error %s' % err
        return {'ok':False,'msg':msg}
    return ret

def test_check_stabilizer_generators1():
    expect=""
    options="nq=0;state=|01>-|10>"
    ans="[-XX,-ZZ]"
    ret = check_stabilizer_generators(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_check_stabilizer_generators2():
    expect=""
    options="nq=0;state=|01>-|10>"
    ans="[-XX,ZZ]"
    ret = check_stabilizer_generators(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==False)

def test_check_stabilizer_generators3():
    expect=""
    options="nq=1;state=[|00>+|11>,|01>+|10>]"
    ans="[XX]"
    ret = check_stabilizer_generators(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_check_stabilizer_generators4():
    expect=""
    options="nq=0;state=|0>+i*|1>"
    ans="[Y]"
    ret = check_stabilizer_generators(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_check_stabilizer_generators5():
    expect=""
    options="nq=0;state=|0?+i*|1?"
    ans="[Y]"
    ret = check_stabilizer_generators(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_check_stabilizer_generators6():
    expect=""
    options="nq=1;state=[|001?,|110?]"
    ans="[ZZI,-IZZ]"
    ret = check_stabilizer_generators(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)


def check_stabilizer_equality(expect, ans, options=None):
    '''
    Check to see if the stabilizer sets given in expect and ans are equivalent.
    Do this by using the Stabilizer class to generate the entire stabilizer set
    for both of these, and comparing the two sets.

    "options" may specify multiple possible alternately acceptable answers, 
    using "altanswer"

    '''

    odict = parse_options(options, allow_multiple=True)
    if 'altanswer' in odict:
        eset = [expect]
        eset += odict['altanswer']
        # print "testing eset=", eset
        for eone in eset:
            ret = check_stabilizer_equality(eone, ans)
            if ret['ok']: return ret
        return ret

    try:
        ss_expect = Stabilizer(expect)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse OUR expected set "%s"' % expect
        return {'ok':False,'msg':msg}

    try:
        ss_ans = Stabilizer(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        return {'ok':False,'msg':msg}

    msg = '<p>Your input parsed as "%s"' % str(ss_ans)

    try:
        ok = (ss_ans.all_stabilizers()==ss_expect.all_stabilizers())
    except Exception as err:
        msg += '<p>Error %s' % err
        msg += '<br/>Failed to compute all_stabilizers'
        return {'ok':False,'msg':msg}

    return {'ok':ok,'msg':msg}

def test_check_stabilizer_equality1():
    expect="XII III III" 
    options="altanswer=III XII III;altanswer=III III XII" 
    ans = "IIIXIIIII"
    ret = check_stabilizer_equality(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

#-----------------------------------------------------------------------------

def check_stabilizer_one_normalizer(expect, ans, options=None):
    '''
    See if ans is a valid normalizer for the stabilizer given by expect, with the weight desired.
    Useful in checking for code distance.

    options should be of the form "weight=XX;stab=YY".
    '''
    odict = parse_options(options)
    weight = int(odict.get('weight', 0))
    cs = odict.get('stab','')

    # get the code stabilizer
    try:
        ss = Stabilizer(cs)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse given stabilizer for the code "%s"' % cs
        return {'ok':False,'msg':msg}
        
    # get the normalizer provided (should be just one)
    try:
        ng_ans = Stabilizer(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        return {'ok':False,'msg':msg}

    msg = '<p>Your input parsed as "%s"' % str(ng_ans)

    # check to see if ng_ans has the right number of elements
    if not ng_ans.n == 1:
        msg += '<br/>Sorry, %s has the wrong number of elements' % ng_ans
        return {'ok':False,'msg':msg}

    # check to see if ng_ans normalizes the code (skip checking to see if in S)
    ret = ss.is_normalizer(ng_ans,check_not_stabilizer=False)
    if not ret['ok']:
        msg += '<br/>%s' % ret['msg']
        return {'ok':False,'msg':msg}

    # check to see if ng_ans has the desired weight
    if not ng_ans[0].weight==weight:
        msg += '<br/>Wrong weight'
        return {'ok':False,'msg':msg}

    return {'ok':True,'msg':msg}


def test_check_stabilizer_one_normalizer1():
    expect="See solutions"
    options="weight=3;stab=[IIIIIIIZZZZZZZZ, IIIZZZZIIIIZZZZ, IZZIIZZIIZZIIZZ, ZIZIZIZIZIZIZIZ, IIIIIIIXXXXXXXX, IIIXXXXIIIIXXXX, IXXIIXXIIXXIIXX, XIXIXIXIXIXIXIX, IIIIIIIIIIIZZZZ, IIIIIIIIIZZIIZZ, IIIIIIIIZIZIZIZ, IIIIIZZIIIIIIZZ, IIIIZIZIIIIIZIZ, IIZIIIZIIIZIIIZ]" 
    ans = "ZZZIIIIIIIIIIII"
    ret = check_stabilizer_one_normalizer(expect, ans, options)
    print(ret['msg'])
    assert('Your input parsed as "[ZZZIIIIIIIIIIII]"' in ret['msg'])
    assert(ret['ok'])

def test_check_stabilizer_one_normalizer2():
    expect="See solutions"
    options="weight=3;stab=[IIIIIIIZZZZZZZZ, IIIZZZZIIIIZZZZ, IZZIIZZIIZZIIZZ, ZIZIZIZIZIZIZIZ, IIIIIIIXXXXXXXX, IIIXXXXIIIIXXXX, IXXIIXXIIXXIIXX, XIXIXIXIXIXIXIX, IIIIIIIIIIIZZZZ, IIIIIIIIIZZIIZZ, IIIIIIIIZIZIZIZ, IIIIIZZIIIIIIZZ, IIIIZIZIIIIIZIZ, IIZIIIZIIIZIIIZ]" 
    ans = "ZZZIIIIIIIIIII"
    ret = check_stabilizer_one_normalizer(expect, ans, options)
    print(ret['msg'])
    assert('has the wrong number of qubits for stabilizer set' in ret['msg'])
    assert(not ret['ok'])

#-----------------------------------------------------------------------------

def check_stabilizer_bad_clifford(expect, ans, options=None):
    '''
    See if ans.conjugate(op) anticommutes with the stabilizer.
    ans should also be one of the stabilizer generators.

    op is, for example H

    options should be of the form "op=XX;stab=YY".
    '''
    odict = parse_options(options)
    op = odict.get('op', '')
    cs = odict.get('stab','')

    # get the code stabilizer
    try:
        ss = Stabilizer(cs)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse given stabilizer for the code "%s"' % cs
        return {'ok':False,'msg':msg}
        
    # get the stabilizer provided (should be just one)
    try:
        ng_ans = Stabilizer(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        return {'ok':False,'msg':msg}

    msg = '<p>Your input parsed as "%s"' % str(ng_ans)

    # check to see if ng_ans has the right number of elements
    if not ng_ans.n == 1:
        msg += '<br/>Sorry, %s has the wrong number of elements' % ng_ans
        return {'ok':False,'msg':msg}

    # check to see if ng_ans is in the stabilizer generator set
    if not ng_ans[0] in ss:
        msg += '<br/>Stabilizer given is not one of the generators'
        return {'ok':False,'msg':msg}

    # conjugate it
    ng_ans[0].conjugate(op)
    msg += '<br/>After conjugation by %s the stabilizer given becomes <tt>%s</tt>' % (op,ng_ans)

    # check to see if ng_ans normalizes the code (skip checking to see if in S)
    ret = ss.is_normalizer(ng_ans,check_not_stabilizer=False)
    if not ret['ok']:
        msg += '<br/>%s' % ret['msg']
        return {'ok':True,'msg':msg}

    msg += '<br/>Sorry, that commutes with the stabilizer'
    return {'ok':False,'msg':msg}

def test_check_stabilizer_bad_clifford1():
    expect="See solutions"
    options="op=H;stab=[IIIIIIIZZZZZZZZ, IIIZZZZIIIIZZZZ, IZZIIZZIIZZIIZZ, ZIZIZIZIZIZIZIZ, IIIIIIIXXXXXXXX, IIIXXXXIIIIXXXX, IXXIIXXIIXXIIXX, XIXIXIXIXIXIXIX, IIIIIIIIIIIZZZZ, IIIIIIIIIZZIIZZ, IIIIIIIIZIZIZIZ, IIIIIZZIIIIIIZZ, IIIIZIZIIIIIZIZ, IIZIIIZIIIZIIIZ]" 
    ans = "IIZIIIZIIIZIIIZ"
    ret = check_stabilizer_bad_clifford(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

#-----------------------------------------------------------------------------
# graph states

class GraphState(Stabilizer):

    amat = None

    def make_graph(self,verbose=True):
        '''
        Construct graph state representation of ourself (our stabilizer set)

        We do this by doing a modified form of Gaussian elimination on the
        set of stabilizer elements.
        '''
        # this only works if the stabilizer set is a legal set of generators
        # and if the space stabilized has dimension zero.
        if not self.k==0:
            msg = "Error: can't create graph for stabilizer of nonzero dimension space"
            raise Exception(msg)
        ret = self.is_good_generators()
        if not ret['ok']:
            raise Exception('<p>Error: can\'t create graph unless stabilizer is legal generator set'+ret['msg'])

        sset = self.stabilizer_set

        def find_pivot(rmin,curq):
            for r in range(rmin,self.n):		# loop through remaining elements
                if sset[r][curq] in 'XY':		# found pivot
                    return(r)
            return None

        def apply_hadamard(curq):			# apply H to all stabilizer set elements
            for g in sset:
                g.conjugate('H',qubits=[self.nq-curq-1],verbose=False)

        nq = self.nq		# number of qubits
        curq = 0		# current qubit
        cure = 0		# current stabilizer set element
        while (cure<self.n):		# loop through the elements
            if verbose: print("[graph] working on element %d, qubit %d" % (cure,curq))
            pivotr = find_pivot(cure,curq)
            if pivotr==None:		# no pivot: apply Hadamard to current qubit
                apply_hadamard(curq)
                if verbose: print("[graph] applying H to qubit %d" % (curq))
                pivotr = find_pivot(cure,curq)
                if pivotr==None:
                    raise Exception('oops, failed to find qubit %d with nonidentity stabilizer element' % curq)
            if not (pivotr==cure):	# swap elements, if element found is not the current one
                gtmp = sset[cure]
                sset[cure] = sset[pivotr]
                sset[pivotr] = gtmp
                if verbose: print("[graph] swapping elements %d and %d" % (pivotr,cure))
            if verbose: print("[graph]   got %s" % (sset[cure]))
            for k in range(cure+1,self.n):		# now eliminiate this element from all following elements
                g = sset[k]
                if not g[curq] in 'IZ':			# unless pivot qubit operator is 'I' or 'Z'
                    sset[k] = g*sset[cure]		# replace with product
                    if verbose: print("[graph]    element %d = %s -> %s" % (k, g, sset[k]))
            cure += 1
            curq += 1

        if verbose: print("[graph] Done with lower triangle, now have ",self.strings)

        # now make it diagonal by removing the upper triangular part
        for k in range(self.n-1,0,-1):	# go through rows from bottom to top
            curq = k			# qubit we're clearing
            g = sset[k]			# our stabilizer element
            if verbose: print("[graph] working on stabilizer %d, qubit %d" % (k,curq))

            for j in range(k-1,-1,-1):
                if not sset[j][curq] in 'IZ':			# if pivot qubit operator not 'I' or 'Z'
                    sset[j] = g*sset[j]				# multiply stabilizer element
                    if verbose: print("[graph]    element %d = %s -> %s" % (j,sset[j], sset[j]))

        self.sympmat = None	# force rebuild of binary matrix

        # double check that the X matrix is the identity
        sm = self.matrix
        xmat = sm[:,:self.n]
        if not (xmat-sympy.eye(self.n)).norm()==0:
            raise Exception('[graph] Failed to create graph state matrix: LHS matrix = %s not identity!' % to_latex(xmat))
        # take RHS matrix as adjacency matrix
        zmat = sm[:,self.n:]
        self.amat = zmat

    def make_graph_via_matrix(self,verbose=True):
        '''
        Construct graph state representation of ourself (our stabilizer set)

        We do this by doing a modified form of Gaussian elimination on the
        binary matrix form of the stabilizer.
        '''
        sm = self.matrix
        # this only works if the stabilizer set is a legal set of generators
        # and if the space stabilized has dimension zero.
        if not self.k==0:
            msg = "Error: can't create graph for stabilizer of nonzero dimension space"
            raise Exception(msg)
        ret = self.is_good_generators()
        if not ret['ok']:
            raise Exception('<p>Error: can\'t create graph unless stabilizer is legal generator set'+ret['msg'])

        # helper routines

        def apply_hadamard(col):	# apply Hadamard operation - swaps columns in left & right halves
            # HXH = Z and HZH = X, so this amounts to swapping 
            # columns on the left and right halves of the matrix.
            c1 = col
            c2 = col+nr
            for r in range(nr):
                x = sm[r,c1]
                sm[r,c1] = sm[r,c2]
                sm[r,c2] = x

        # our first goal is to reduce the matrix into upper triangular form.
        # this is possible since the matrix has linearly independent rows.
        # do this using a form of gaussian elimination
        # keep track of which columns the pivots are on

        nr,nc = sm.shape		# number of rows and columns
        curr = 0			# current row
        curc = 0			# current column
        while (curr<nr):		# loop through the rows.
            if sum(sm[curr:,curc])==0:	# if this column has no nonzero pivots
                apply_hadamard(curc)	# apply hadamard to this column
                if verbose: print("[graph] applying H to column %d" % (curc))
                if sum(sm[curr:,curc])==0:	# fail if still have no pivot candidate
                    raise Exception('oops, failed to find column %d with nonzero element' % curc)
            if verbose: print("[graph] working on row %d, column %d" % (curr,curc))
            r = curr
            while sm[r,curc]==0:
                r += 1
                if r >= nr:
                    raise Exception('oops, failed to find row with nonzero pivot')
            if not (r==curr):		# swap rows, if row found is not the current row
                sm.row_swap(r,curr)
                if verbose: print("[graph] swapping rows %d and %d" % (r,curr))
            smr = sm[curr,:]		# current row
            for k in range(curr+1,nr):	# now eliminate this row from all following rows
                if not sm[k,curc]==0:
                    if verbose: print("[graph]    row %d = %s" % (k,sm[k,:]))
                    sm.row(k,lambda v,i: int(v+smr[i])&1)	# multiply row by current row
                    #for j in range(nc):
                    #    sm[k,j] = sm[k,j]+smr[j]
                    if verbose: print(" -> %s" % sm[k,:])
            curr += 1
            curc += 1
            
        # now make it diagonal by removing the upper triangular part
        for k in range(nr-1,0,-1):	# go through rows from bottom to top
            curc = k			# column we're zeroing
            smr = sm[k,:]
            if verbose: print("[graph] working on row %d, column %d" % (k,curc))
            for j in range(k-1,-1,-1):
                if not sm[j,curc]==0:	# if element not zero
                    if verbose: print("[graph]    row %d = %s" % (k,sm[k,:]))
                    sm.row(j,lambda v,i: int(v+smr[i])&1)	# multiply row
                    if verbose: print(" -> %s" % sm[k,:])

        # double check that the LHS matrix is the identity
        xmat = sm[:,:nr]
        if not (xmat-sympy.eye(nr)).norm()==0:
            raise Exception('[graph] Failed to create graph state matrix: LHS matrix = %s not identity!' % to_latex(xmat))
        # take RHS matrix as adjacency matrix
        zmat = sm[:,nr:]
        self.amat = zmat

        # self.matrix has now been changed by the above row operations; update the Pauli op strings accordingly
        self.set_binary_matrix(self.matrix)
                
    def compute_adjacency_matrix(self):
        if self.amat:
            return self.amat
        self.make_graph(verbose=False)
        return self.amat

    def set_adjacency_matrix(self,amat):
        '''
        Set the adjacency matrix as given, and build the corresponding stabilizer (and circuits).
        '''
        if type(amat)==str:
            amat = my_sympify(amat,matrix=True)
        if not type(amat)==type(sympy.eye(0)):
            raise Exception("Error: adjacency matrix %s must be a Matrix" % amat)
        self.amat = amat
        nq = amat.shape[0]
        m = sympy.eye(nq)	# make binary matrix from [ I | A ] where A = adjacency matrix
        self.matrix = m.row_join(amat)			# invokes Stabilizer.set_binary_matrix

    adjacency_matrix = property(compute_adjacency_matrix,set_adjacency_matrix,None,'return graph state adjacency matrix')
    
    def plot(self, **kwargs):
        '''
        Plot the graph state.  Returns SVG in a string.
        '''
        config = {'xsize':400,
                  'ysize':400,
                  'radius':170,
                  'fc':'r',
                  'ec':'k',
                  'clinewidth':3.0,
                  'linewidth':3.1,
                  'dotsize':15,
                  }

        config.update(kwargs)

        # initialize plot
        name = "Graph state"
        fig = SceneSVG(name, width=config['xsize'], height=config['ysize'])
        amat = self.adjacency_matrix

        # locate plot points for each qubit
        # put them on a circle, equally spaced
        dth = 2*3.14159/self.n
        r = config['radius']
        points = {}
        xm = config['xsize']/2
        ym = config['ysize']/2
        for k in range(self.n):
            xy = (r*math.cos(k*dth) + xm,r*math.sin(k*dth) + ym)
            points[k] = xy

        # plot lines between adjacent vertices, based on adjacency matrix
        for k in range(self.n):
            for j in range(k+1,self.n):
                if amat[k,j]:
                    xd,yd = list(zip(points[k],points[j]))
                    line = Line((xd[0],yd[0]), (xd[1],yd[1]), 'black', config['linewidth'])
                    fig.add(line)

        # plot circles for each vertex
        for k in points:
            c = Circle(points[k], config['dotsize'], 'blue', 'black', config['clinewidth'])
            fig.add(c)

        # fig.write_svg()
        return str(fig)

    def make_networkx_graph(self):
        '''
        Return a NetworkX graph representation of our graph state.
        '''
        if nx is None:
            return None
        amat = self.adjacency_matrix
        G=nx.Graph()
        G.add_nodes_from(list(range(self.n)))
        for k in range(self.n):
            for j in range(k+1,self.n):
                if amat[k,j]:
                    G.add_edge(k,j)
        return G

    graph = property(make_networkx_graph,None,None,"NetworkX representation of our graph state")

def old_test1():
    s = GraphState('[XZZXI,IXZZX,XIXZZ,ZXIXZ,XXXXX]')
    s.make_graph()
    return s

def old_test2():
    s = GraphState('[ZZI,IZZ,XXX]')
    s.make_graph()
    return s

def old_test3():
    s = GraphState('[XZZXI,IXZZX,XIXZZ,ZXIXZ,XXXXX]')
    s.plot()
    # pylab.savefig('graph1.png')
    return s

def check_graph_state_stabilizer_given_amat(expect, ans, options=None):
    '''
    options should be an adjacency matrix = amat
    ans should be a valid stabilizer generator set which produces the same graph as that specified by amat.

    Note that this is a graph isomorpmishm problem.
    '''
    if type(options)==type(sympy.eye(0)):
        amat = options
    else:
        try:
            amat = my_sympify(options,matrix=True)
        except Exception as err:
            msg = "<p>Error %s parsing OUR expected string for the adjacency matrix '%s' " % (err,options)
            return {'ok':False,'msg':msg}

    try:
        expect_stabset = GraphState()
        expect_stabset.adjacency_matrix = amat
    except Exception as err:
        # raise Exception("failed in to_matrix err=%s, traceback=%s" % (err, traceback.format_exc()))
        msg = "<p>Error %s creating stabilizer set from OUR expected string for the adjacency matrix '%s' " % (err,options)
        return {'ok':False,'msg':msg}

    try:
        stabset = GraphState(ans)
    except Exception as err:
        msg = "<p>Cannot parse your expression '%s'" % ans
        msg += "<br/>Your input should be a list of stabilizers, eg [IXX,ZZZ]"
        msg += "<br/>Error: %s" % err
        return {'ok':False,'msg':msg}

    try:
        ans_amat = stabset.adjacency_matrix
        svg = stabset.plot()
    except Exception as err:
        msg = "<p>Cannot generate a graph state from your input '%s'" % ans
        msg += "<br/>Error: %s" % err
        return {'ok':False,'msg':msg}

    msg = "<p>Your stabilizer generator set corresponds to this graph state:"
    msg += "<center>%s</center>" % svg

    try:
        ok = (ans_amat-amat).norm()==0
    except Exception as err:
        msg += "<p>Your stabilizer generator set corresponds to a graph of the wrong size"
        msg += "<br/>Error: %s" % err
        return {'ok':False,'msg':msg}
    
    if not ok and (nx is not None):	# try graph isomorphism test just in case
        try:
            ok = nx.is_isomorphic(stabset.graph,expect_stabset.graph)
        except Exception as err:
            msg += "<p>Failed in trying to check for isomorphism between your graph and the expected one"
            msg += "<br/>Error: %s" % err
            return {'ok':False,'msg':msg}
        if ok:
            msg += "<br/>Your graph is isomorphic to the expected one"

    return {'ok':ok,'msg':msg}

def check_graph_state_stabilizer(expect, ans, options=None):
    '''
    expect should be a stabilizer generator set
    ans should be a valid stabilizer generator set which produces the same graph as that specified by expect.

    Note that this is a graph isomorpmishm problem.
    '''
    try:
        ss_expect = GraphState(expect)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse OUR expected set "%s"' % expect
        return {'ok':False,'msg':msg}
    return check_graph_state_stabilizer_given_amat(ss_expect.adjacency_matrix,ans)

def test_check_graph_state_stabilizer_given_amat1():
    # equal
    expect = "see soln"
    options = '[[0, 1, 1, 0],[1,0, 0, 1],[1, 0, 0, 0],[0, 1, 0, 0]]'
    ret = check_graph_state_stabilizer_given_amat(expect, '[IXXZ,XIZX,IZIX,ZIXI]', options)    
    print(ret['msg'])
    assert(ret['ok'])
    # isomorphic
    print(check_graph_state_stabilizer_given_amat(expect, '[XXZI,IZXX,ZIXI,IXIZ]', options))
    print(ret['msg'])
    assert(ret['ok'])

def test_check_graph_state_stabilizer_given_amat2():
    expect="See solution" 
    options="[[0,1,1],[1,0,1],[1,1,0]]" 
    ans = '[XZZ,ZXZ,ZZX]'
    ret = check_graph_state_stabilizer_given_amat(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])
    assert('<svg' in ret['msg'])

#-----------------------------------------------------------------------------
# graph testing

def check_graph_isomorphism_amat(expect, ans):
    '''
    Check if two graphs (expect and ans) are isomorphic based on the adjacency matrices given
    '''
    import networkx as nx

    try:
        amat_expect = my_sympify(str(expect),matrix=True)
    except Exception as err:
        msg = "<p>Error %s parsing OUR expected string for the adjacency matrix '%s' " % (err,expect)
        return {'ok':False,'msg':msg}

    try:
        amat_ans = my_sympify(str(ans),matrix=True)
    except Exception as err:
        msg = "<p>Error %s parsing your input for the adjacency matrix '%s' " % (err,ans)
        return {'ok':False,'msg':msg}

    if not type(amat_ans)==type(sympy.eye(0)):
        msg = "<p>Your input should specify a matrix, eg [[0,1],[1,0]]"
        return {'ok':False,'msg':msg}

    msg = "<p>Your input was parsed as %s" % to_latex(amat_ans)

    (nr,nc) = amat_ans.shape
    if not nr==nc:
        msg += "<p>The adjacency matrix you give should be square."
        return {'ok':False,'msg':msg}

    for k in range(nr):
        if amat_ans[k,k]:
            msg += "<p>The adjacency matrix you give should have zeros on the diagonal."
            return {'ok':False,'msg':msg}

    for j in range(nr):
        for k in range(nr):
            if (not amat_ans[j,k]==1) and (not amat_ans[j,k]==0):
                msg += "<p>The adjacency matrix you give should only have zeros and ones."
                return {'ok':False,'msg':msg}

    def amat2graph(amat):
        if nx is None:
            return None
        G=nx.Graph()
        n = amat.shape[0]
        G.add_nodes_from(list(range(n)))
        for k in range(n):
            for j in range(k+1,n):
                if amat[k,j]:
                    G.add_edge(k,j)
        return G
        
    try:
        ok = nx.is_isomorphic(amat2graph(amat_ans),amat2graph(amat_expect))
    except Exception as err:
        msg += "<br/>Failed in checking for isomorphism with the expected answer"
        msg += "<br/>Error: %s" % err
        return {'ok':False,'msg':msg}

    return {'ok':ok,'msg':msg}
        
def test_check_graph_isomorphism_amat1():
    expect="[[0,1],[1,0]]" 
    ans="[[0,1],[1,0]]" 
    ret = check_graph_isomorphism_amat(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])
    
def test_check_graph_isomorphism_amat2():
    expect="[[0,1,1],[1,0,0],[1,0,0]]" 
    ans="[[0,1,0],[1,0,1],[0,1,0]]"
    ret = check_graph_isomorphism_amat(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_graph_isomorphism_amat3():
    expect="[[0,1],[1,0]]" 
    ans="[[1,1],[1,0]]" 
    ret = check_graph_isomorphism_amat(expect, ans)
    print(ret['msg'])
    assert(not ret['ok'])
    assert('have zeros' in ret['msg'])

def test_check_graph_isomorphism_amat4():
    expect="[[0,1],[1,0]]" 
    ans="[[0,3],[1,0]]" 
    ret = check_graph_isomorphism_amat(expect, ans)
    print(ret['msg'])
    assert(not ret['ok'])
    assert('have zeros and ones' in ret['msg'])


#-----------------------------------------------------------------------------
# simplistic stabilizer set testing

def compare_stabilizer_set(expect,ans):
    '''
    parse strings of lists of stabizers, but compare them as sets (so order does not matter)
    '''
    try:
        ss_expect = Stabilizer(expect)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse OUR expected set "%s"' % expect
        return {'ok':False,'msg':msg}

    try:
        ss_ans = Stabilizer(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        return {'ok':False,'msg':msg}

    msg = '<p>Your input parsed as "%s"' % str(ss_ans)

    try:
        ok = set(ss_ans.strings) == set(ss_expect.strings)
    except Exception as err:
        msg += '<p>Error %s' % err
        msg += '<br/>Failed to compare stabilizers'
        return {'ok':False,'msg':msg}

    return {'ok':ok,'msg':msg}

def check_stabilizer_equality_and_minimal(expect, ans, options=None):
    '''
    Check to see if the stabilizer sets given in expect and ans are equivalent.
    Do this by using the Stabilizer class to generate the entire stabilizer set
    for both of these, and comparing the two sets.

    Also make sure that ans is a minimal set of generators, ie log(|S|).

    expect should be of the form "3;[XIX,IZI]", where the leading int is the min gen set size.
    '''

    odict = parse_options(options)
    ngen = odict.get('ngen', 0)
    expect = odict.get('expect', expect)

    res = check_stabilizer_equality(expect,ans)
    if not res['ok']:
        return res

    ss_ans = Stabilizer(ans)
    msg = res['msg']
    ok = len(ss_ans.strings)==int(ngen)
    if not ok:
        msg += '<br/>Your stabilizer set has the wrong number of elements'

    return {'ok':ok,'msg':msg}

def test_check_stabilizer_equality_and_minimal1():
    expect="See solutions"
    options="ngen=3;expect=[IIII, IZIX, XXIZ, YXIY, XYIY, -YYIZ, ZIIX, ZZII]"    
    ans = "[XXIZ, YXIY, IZIX]"
    ret = check_stabilizer_equality_and_minimal(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)

#-----------------------------------------------------------------------------
# quantum codes

def check_stabilizer_code_bad_error(expect, ans, options=None, cs=None):
    '''
    See if ans is a bad error for the code specified by the stabilizers given.

    options should be of the form "weight=XX;nocheckweight=0".
    '''
    # options
    flags = parse_options(options)
    weight = int(flags.get('weight', 0))

    if not weight:
        (weight,cs) = expect.split(';')

    # get the code stabilizer
    try:
        ss = Stabilizer(cs)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse given stabilizer for the code "%s"' % cs
        return {'ok':False,'msg':msg}
        
    # get the error
    try:
        stab_ans = StabilizerElement(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        return {'ok':False,'msg':msg}

    msg = '<p>Your input parsed as "%s"' % str(stab_ans)

    # check to see if the weight of the error is correct
    if not 'nocheckweight' in flags:
        if not stab_ans.weight == weight:
            msg += '<br/>Sorry, %s has the wrong weight' % stab_ans
            return {'ok':False,'msg':msg}

    # see if the error is in S
    if stab_ans in ss.all_stabilizers():
        msg += '<br/>Sorry, %s is in the stabilizer generated by %s' % (stab_ans,ss)
        return {'ok':False,'msg':msg}

    # see if the error anticommutes with a generator in S
    ret = ss.commutes(stab_ans)
    if not ret['ok']:
        ret['msg'] = msg + '<br/>' + ret['msg']
        return ret
    return {'ok':True,'msg':msg}

def test_check_stabilizer_code_bad_error1():
    expect="See solutions"
    options="weight=4;nocheckweight=1" 
    ans = "XIIZXZ"
    cs = "[IXZZXI,IIXZZX,IXIXZZ,IZXIXZ,ZZZZZZ,XXXXXX]"
    ret = check_stabilizer_code_bad_error(expect, ans, options, cs=cs)
    print(ret['msg'])
    assert(ret['ok']==True)

def check_stabilizer_equality_and_code_error(expect, ans, options=None):
    '''
    See 6-qubit code problem
    '''
    odict = parse_options(options)
    stab = odict.get('stab')

    ret1 = check_stabilizer_equality(stab, ans[0])
    if not ret1['ok']:
        return ret1

    ret2 = check_stabilizer_code_bad_error("", ans[1], options=options, cs=ans[0])
    return ret2

def test_check_stabilizer_equality_and_code_error1():
    expect="See solution"
    options="stab=[IXZZXI,IIXZZX,IXIXZZ,IZXIXZ,ZZZZZZ,XXXXXX];weight=4;nocheckweight"
    ans=["[IXZZXI,IIXZZX,IXIXZZ,IZXIXZ,ZZZZZZ,XXXXXX]","XIIZXZ"]
    ret = check_stabilizer_equality_and_code_error(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

def check_stabilizer_normalizer(expect, ans, options=None):
    '''
    See if ans is a valid normalizer element (of specified weight) for the stabilizer given by expect.

    options should be of the form "stab=STABILIZER;weight=WEIGHT".
    
    '''
    odict = parse_options(options)
    cs = odict.get('stab')
    weight = int(odict.get('weight'))

    # get the code stabilizer
    try:
        ss = Stabilizer(cs)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse given stabilizer for the code "%s"' % cs
        return {'ok':False,'msg':msg}
        
    # get the normalizer provided
    try:
        ng_ans = StabilizerElement(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your input "%s"' % ans
        return {'ok':False,'msg':msg}

    msg = '<p>Your input parsed as "%s"' % str(ng_ans)

    # check to see if ng_ans has the right number of elements
    if not ng_ans.weight == weight:
        msg += '<br/>Sorry, %s has the wrong weight' % ng_ans
        return {'ok':False,'msg':msg}

    # check to see if ng_ans is independent
    #ret = ng_ans.is_independent()
    #if not ret['ok']:
    #    msg += '<br/>%s' % ret['msg']
    #    return {'ok':False,'msg':msg}

    if ng_ans in ss.all_stabilizers():
        msg += "<br/>Sorry, %s is in the stabilizer" % ng_ans
        return {'ok':False,'msg':msg}

    # check to see if ng_ans normalizes the code
    ret = ss.is_normalizer(Stabilizer([ng_ans]))
    if not ret['ok']:
        msg += '<br/>%s' % ret['msg']
        return {'ok':False,'msg':msg}

    return {'ok':True,'msg':msg}

def test_check_stabilizer_normalizer1():
    expect="See solution" 
    options="weight=3;stab=[XZZXI, IXZZX, XIXZZ, ZXIXZ]" 
    ans="IIXYX"
    ret = check_stabilizer_normalizer(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_stabilizer_normalizer2():
    expect="See solution" 
    options="weight=3;stab=[XZZXI, IXZZX, XIXZZ, ZXIXZ]" 
    ans="XXXXX"
    ret = check_stabilizer_normalizer(expect, ans, options)
    print(ret['msg'])
    assert('wrong weight' in ret['msg'])
    assert(not ret['ok'])


def check_clifford_group_equivalence(expect, ans, options=None):
    '''
    See if ans is equivalent to the single qubit CliffordGate given by expect.
    '''
    if expect=='none':
        return {'ok': ans.lower()=='none', 'msg': ''}
    elif ans.lower()=='none':
        return {'ok': False, 'msg': ''}

    # get the expected CliffordGate
    try:
        cg_expect = Clifford1Gate(expect)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse OUR clifford gate "%s"' % expect
        return {'ok':False,'msg':msg}

    # get the answer CliffordGate 
    try:
        cg_ans = Clifford1Gate(ans)
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed to parse your clifford gate "%s"' % ans
        return {'ok':False,'msg':msg}
        
    msg = '<p>Your input parsed as "%s"' % str(cg_ans)

    # see if they are equivalent
    try:
        ok = cg_ans == cg_expect
    except Exception as err:
        msg = '<p>Error %s' % err
        msg += '<br/>Failed in testing equivalence of the expected with your answer %s' % ans
        return {'ok':False,'msg':msg}

    return {'ok':ok,'msg':msg}

def test_check_clifford_group_equivalence1():
    expect="HS"    
    ans="HS"
    ret = check_clifford_group_equivalence(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])
    
def test_check_clifford_group_equivalence2():
    expect="HS"    
    ans="HSHH"
    ret = check_clifford_group_equivalence(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_clifford_group_equivalence3():
    expect="none"    
    ans="None"
    ret = check_clifford_group_equivalence(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])
    
def test_check_clifford_group_equivalence4():
    expect="HS"    
    ans="none"
    ret = check_clifford_group_equivalence(expect, ans)
    print(ret['msg'])
    assert(not ret['ok'])


#=============================================================================
# for measurementqc

def check_qubit_coord(expect,ans):
    es = set(eval(expect))
    aset = set(eval(ans))
    return es==aset

#=============================================================================
# old junk

if __name__ == '__main__' and False:
    #circuit = CNOT(0,1) * H(0)

    s = "Qubit('00')"
    state = str2state(s)
    print(state)

    s = '[ H(0), CNOT(0,1) ]'
    circuit = str2circuit(s)
    print(circuit)
    print(circuit2image(circuit,2))
    
# test3()
# cgset = [Clifford1Gate('I'),Clifford1Gate('H'),Clifford1Gate('S')]

def old_testcg1(lvl=0,nmax=8):
    # find all 24 local clifford gates in terms of H,S
    for g in cgset:
        for op in [str(g)+'H',str(g)+'S']:
            cg = Clifford1Gate(op)
            if not(cg in cgset):
                print(cg)
                cgset.append(cg)
    
def old_testcg2():
    testcg1()
    for g in cgset:
        print("%s: %s" % (g,g.conjugate(['X','Y','Z'])))

#=============================================================================
# unit tests

def test_parse1():
    ans = 'X/2'
    sfc = SympyFormulaChecker()
    r = sfc.parse_input(ans)
    print(r)
    assert(r==sympy.sympify("Matrix([[0,1],[1,0]])/2"))

def test_parse2():
    ans = '[[0,1],[1,0]]/2'
    sfc = SympyFormulaChecker()
    r = sfc.parse_input(ans)
    print(r)
    assert(r==sympy.sympify("Matrix([[0,1],[1,0]])/2"))

def test_make_samples():
    r = sympy.sympify('exp(1-p)')
    s = sympy.sympify('cos(1-g)')
    sfc = SympyFormulaChecker()
    samples = sfc.sympy_make_samples([r,s])
    assert(samples=='p,g@0,0:0.999,0.999#20')

def test_form_eq1():
    r = sympy.sympify('exp(1-p)')
    s = sympy.sympify('cos(1-g)')
    sfc = SympyFormulaChecker()
    eq = sfc.sympy_is_formula_equal(r, s)
    assert(eq==False)

def test_form_eq2():
    sfc = SympyFormulaChecker()
    r = sfc.parse_input('sqrt(1-sin(1-p)^2)')
    s = sympy.sympify('cos(1-p)')
    eq = sfc.sympy_is_formula_equal(r, s)
    assert(eq==True)

def test_sfc1():
    ans = 'sqrt(1-sin(1-p)^2)'
    exp = 'cos(1-p)'
    sfc = SympyFormulaChecker()
    ret = sfc.sympy_formula_check(exp, ans)
    print(ret['msg'])
    assert(ret['ok']==True)

def test_sfc2():
    ans = 'qux(1-sin(1-p)^2)'
    exp = 'cos(1-p)'
    sfc = SympyFormulaChecker()
    ret = sfc.sympy_formula_check(exp, ans)
    print(ret['msg'])
    assert(ret['ok']==False)

def test_sfc3a():
    ans = 'foo(-sin(1-p)^2)'
    exp = 'None'
    sfc = SympyFormulaChecker()
    ret = sfc.sympy_formula_check(exp, ans, options="check_none=1")
    print(ret['msg'])
    assert(ret['ok']==False)

def test_sfc4a():
    ans = 'none'
    exp = 'None'
    sfc = SympyFormulaChecker()
    ret = sfc.sympy_formula_check(exp, ans, options="check_none=1")
    print(ret['msg'])
    assert(ret['ok']==True)

def test_sfc5():
    sfc = SympyFormulaChecker()
    ret = sfc.sympy_formula_check(expect="(-1)^b * ZI", ans="ZI")
    assert(ret['ok']==False)
    ret = sfc.sympy_formula_check(expect="(-1)^b * ZI", ans="ZI * (-1)^b")
    assert(ret['ok']==True)

#--------------------

def test_circuit_plot1():
    s = '[ H(0), CNOT(0,1) ]'
    circuit = str2circuit(s)
    print(circuit)
    print(circuit2image(circuit,2))
    return circuit

def test_nine_qubit_circuit_plot():
    s = '[CNOT(8,5),CNOT(8,2),H(8),H(5),H(2),CNOT(8,7),CNOT(8,6),CNOT(5,4),CNOT(5,3),CNOT(2,1),CNOT(2,0)]'
    circuit = str2circuit(s)
    print(circuit)
    print(circuit2image(circuit,9))
    return circuit
    
def test_nine_qubit_circuit_plot2():
    ans = '[CNOT(8,5),CNOT(8,2),H(8),H(5),H(2),CNOT(8,7),CNOT(8,6),CNOT(5,4),CNOT(5,3),CNOT(2,1),CNOT(2,0)]'
    expect="[CNOT(8,5),CNOT(8,2),H(8),H(5),H(2),CNOT(8,7),CNOT(8,6),CNOT(5,4),CNOT(5,3),CNOT(2,1),CNOT(2,0)]" 
    options="nqubits=9"
    ret = check_qcircuit_compare_output(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok']==True)

#-----------------------------------------------------------------------------
# represent matrix as a sum over Pauli group elements

def MatrixAsPauli(mat,verbose=False):
    '''
    Represent a square matrix (of dimension which is a power of two) as a weighted sum over Pauli operators.
    In NMR, this is known as the product operator representation.

    Compute this using the trace orthogonalaity of the Pauli matrices.

    Returns a dict with keys = Pauli operators (as StabilizerElement instances) and vals = weights.
    '''
    if not mat.rows==mat.cols:
        raise Exception('[MatrixAsPauli] Matrix must be square')
    nq = int(math.log(mat.rows,2))
    if verbose: print("nq = ",nq)
    if not mat.rows==2**nq:
        raise Exception('[MatrixAsPauli] Matrix dimension must be power of two')
    
    dtab = {}

    def precurse(k,g=None):
        if k==nq:
            c = sympy.simplify((mat*g.op).trace()/(2**nq))
            if verbose: print("%s : %s" % (g,c))
            if c: dtab[g] = c
            return
        for p in 'IXYZ':
            precurse(k+1,StabilizerElement(p+(g.string if g else '')))

    precurse(0)
    return dtab

#-----------------------------------------------------------------------------
# Class for general quantum circuit

# example: qp.QuantumCircuit('[CGate((1),H(0))]',2).PauliMap()

class QuantumCircuit(object):
    '''
    Representation of a quantum circuit.

    Internally, the circuit is stored as a list of sympy gates, self.qc, and the number of qubits it operates on.

    Provides methods for producing the matrix representation, and plotting the circuit.
    Also provides methods for producing the Pauli map for the transform given by the circuit.

    Attributes:

       - qc:      gate list
       - nqubits: number of qubits

    '''

    def __init__(self, qc, nqubits, excludeset=[], verbose=False):
        '''
        Initialize quantum circuit instance.

        qc = string representation of circuit, e.g. "[Rx(0, pi/4)]"
        '''
        self.verbose = verbose
        if type(qc)==str:
            qc = str(MathUnicodeToAscii(qc)).strip()
        if qc=='':
            qc = '[]'
        if type(qc)==str:
            qc = qc.replace('\n','').replace('\r','')
            if self.verbose:
                print("[QuantumCircuit] making circuit using eval, from qc=%s" % qc)
            qc = eval(qc, GATES_DICT)
            #qc = sympy.sympify(qc, locals=GATES_DICT)
            #qc = my_sympify(qc,symtab={})
        if type(qc)==QuantumCircuit:
            qc = qc.qc
        if not type(qc)==list:
            raise Exception("Input circuit should be a list, eg [ H(0), CNOT(0,1) ], got '%s' (type=%s)" % (str(qc),type(qc)))

        # check against exclusion list
        if excludeset:
            for gate in qc:
                for eg in excludeset:
                    if isinstance(gate,eg):
                        raise Exception("Gate %s not allowed in the quantum circuit" % gate)

        self.nqubits = nqubits		# nqubits and qc list are the only two things which define the QuantumCircuit
        self.qc = qc

    def __getitem__(self,k):
        return self.qc[k]

    def make_qc_string(self):
        return str(self.qc) if self.qc else ''

    string = property(make_qc_string,None,None,"String representation of quantum circuit")
    
    def make_qc_circuit(self):
        if not self.qc: return 1
        return reduce(sympy.Mul,self.qc[::-1])	# multiply together in reverse order

    circuit = property(make_qc_circuit,None,None,"Sympy quantum operator representation of quantum circuit")

    def __add__(self,other):	# combine two circuits to form one
        if not isinstance(other,QuantumCircuit):
            raise Exception("Can't add type %s to a QuantumCircuit" % type(other))
        if not other.nqubits==self.nqubits:
            raise Exception("Can't add %d qubit circuit to %d qubit circuit" % (other.nqubits,self.nqubits))
        return self.__class__(self.qc + other.qc,self.nqubits)

    def __str__(self):
        return str(self.qc)

    __repr__ = __str__

    def get_gates(self):
        return self.qc[::-1]

    args = property(get_gates,None,None,"List of gates in circuit, in reverse time order")

    def matrix(self):
        return represent(self.circuit,nqubits=self.nqubits)

    def matrix_tex(self):
        return to_latex(self.matrix())

    def output(self,instate=None):
        if instate==None:
            instate = Qubit('0'*nqubits)
        outstate = qapply(self.circuit*instate)
        return outstate
        
    def PauliForm(self):
        '''
        Return decomposition of the matrix for this circuit as a weighted sum over Pauli group elements.
        This is given as a dict with keys = Pauli operators (as StabilizerElement instances) and vals = weights.
        '''
        return MatrixAsPauli(self.matrix())

    def conjugate(self,g,mat=None,verbose=True):
        '''
        Return the mapping which our quantum circuit performs the Pauli operator g, when acting by conjugation.
        '''
        if type(g)==list:
            return [self.conjugate(x,verbose=verbose) for x in g]
        if type(g)==str:
            g = StabilizerElement(g)
        if mat==None:
            mat = self.matrix()
        cout = MatrixAsPauli(mat * g.op * mat.H)
        if len(cout)==1:
            se = list(cout.keys())[0]
            se.sign = cout[se]
            cout = se
        if verbose: print("%s -> %s" % (g,cout))

        return cout

    def PauliMap(self,verbose=True):
        '''
        Return the mapping which our quantum circuit performs on Pauli matrices, when acting by conjugation.
        We give this for all pre-images which are single qubit X and Z operators.

        The result is a list of [input,output] pairs, where input is a StabilizerElement instance,
        If the output is also a single Pauli operator, then it is also a StabilizerElement instance;
        otherwise, it is a dict from MatrixAsPauli.
        '''
        nq = self.nqubits
        mat = self.matrix()
        map = []
        for k in range(nq):
            for p in 'XZ':
                gstr = 'I'*(nq-k-1) + p + 'I'*k
                g = StabilizerElement(gstr)
                map.append([g,self.conjugate(g,mat=mat,verbose=verbose)])
        return map

    def plot(self, html=False, **params):
        '''
        Generate plot image of circuit, using CircuitPlot from sympy.physics.quantum
        return SVG / HTML
        '''

        if self.qc==[]:
            if html:
                return '<center>None</center>'
            else:
                return ''

        params['nqubits'] = self.nqubits
        
        # call CircuitPlot with ourself as instance, to avoid bug with
        # Mul collapsing sequential gates into Pow, eg
        # [H(0),CNOT(0,1),H(0),H(0),H(0)] -> H(0)**3 * CNOT(0,1) * H(0)
        cp = CircuitPlotSVG(self, **params)

        if html:
            return '<center>%s</center>' % str(cp.svg)
        else:
            return str(cp.svg)

#-----------------------------------------------------------------------------
# quantum circuits class tests

def test_qcirc1():
    qc = QuantumCircuit('[CGate((1),H(0))]',2).PauliMap()
    assert(str(qc[0][0])=='IX')

def test_qcirc2():
    qc = QuantumCircuit('[CGate((1),H(0))]',2)
    assert('H' in qc.plot())
    assert('[C((1),H(0))]' in str(qc.get_gates()))
    assert('1 & 0 & 0 & 0\\\\0 & 1 & 0 & 0\\\\0 & 0' in qc.matrix_tex())

#-----------------------------------------------------------------------------
# Clifford Circuits

def conjugate_stabilizer(self,g,verbose=True):
    '''
    Method added to Gate which conjugates the stabilizer element g by the gate.
    Acts properly on the appropriate qubits of g.
    g is modified.  No value is returned.

    Works only if Gate is a (known) clifford group element.
    Uses self.gate_name to figure out what to do.
    '''
    if self.gate_name in 'XYZHS' or self.gate_name in ['CNOT','SWAP']:
        g.conjugate(self.gate_name,qubits=self.label,verbose=verbose)
    else:
        raise Exception('No Clifford group transform available for gate %s%s' % (self.gate_name,
                                                                                 str(self.label).replace(',)',')').replace(' ','')
                                                                                 ))

Gate.conjugate_stabilizer = conjugate_stabilizer

class CliffordCircuit(QuantumCircuit):
    '''
    Represent a clifford circuit, and give properties of a clifford circuit.
    Clifford circuits are generated by H, S, and CNOT.

    The clifford circuit may also be specified on construction by a map on Pauli operators,
    given in standard form.  
    '''

    def __init__(self,qc,nqubits):
        if type(qc)==dict or (type(qc)==list and type(qc[0])==list and (type(qc[0][0])==str or type(qc[0][0]==StabilizerElement))):
            qc = str(self.MapToCliffordCircuit(qc))	# make circuit from Pauli map if input of the right form
        super(CliffordCircuit,self).__init__(qc,nqubits)	# otherwise fall back and just make circuit the usual way

    cg1maps = {'H': ['Z', 'X'],
               'HS': ['Z', 'Y'],
               'HSH': ['X', '-Y'],
               'HSHS': ['Y', 'X'],
               'HSHSS': ['-X', 'Y'],
               'HSHSSH': ['-Z', '-Y'],
               'HSHSSS': ['-Y', '-X'],
               'HSS': ['Z', '-X'],
               'HSSH': ['X', '-Z'],
               'HSSHS': ['Y', '-Z'],
               'HSSHSS': ['-X', '-Z'],
               'HSSS': ['Z', '-Y'],
               'I': ['X', 'Z'],
               'S': ['Y', 'Z'],
               'SH': ['-Y', 'X'],
               'SHS': ['X', 'Y'],
               'SHSS': ['Y', '-X'],
               'SHSSH': ['-Y', '-Z'],
               'SHSSS': ['-X', '-Y'],
               'SS': ['-X', 'Z'],
               'SSH': ['-Z', 'X'],
               'SSHS': ['-Z', 'Y'],
               'SSHSS': ['-Z', '-X'],
               'SSS': ['-Y', 'Z']}

    def MapToCliffordCircuit(self,pmap_in,verbose=True):
        '''
        Take a map of Pauli operators to Pauli operators and construct from it a Clifford circuit performing
        the map by conjugation.
        
        The map should be given in standard form, ie with pre-images being single-qubit Pauli operators.
        
        The map may be a dict, with the keys being the pre-images, or a list of pairs, with the first element
        in each pair being the pre-image.
        
        images and pre-images may be strings of Pauli operators, or StabilizerElement instances.
        '''
        if type(pmap_in)==list:
            pmap = dict(pmap_in)		# make it a dict
        else:
            pmap = pmap_in
    
        nq = len(list(pmap.keys())[0])	# assume all of the same length
        for k in pmap:
            if type(k)==StabilizerElement:
                pmap[k.string] = pmap[k]
    
        # order the elements of the map so that the pre-images are standard: IIX, IIZ, IXI, IZI, ...
        # make sure image elements of the map all StabilizerElement instances
        pset = []			# set of Pauli operations which are images of the standard pre-images
        for k in range(nq):
            for p in 'XZ':
                gstr = 'I'*(nq-k-1) + p + 'I'*k
                if gstr not in pmap:
                    raise Exception('MapToCliffordCircuit error: missing entry for %s' % gstr)
                mg = pmap[gstr]
                # re-create StabilizerElement instances, so we don't modify the source map
                pset.append(StabilizerElement(mg) if type(mg)==str else StabilizerElement(mg.string))
    
        # helper routines
    
        def find_single_qubit_clifford_inverse(xbar,zbar,target,nqubits):
            '''
            Return the CliffordCircuit which maps xbar, zbar to X,Z
            '''
            cgop = None
            for cg in self.cg1maps:
                if self.cg1maps[cg]==[xbar,zbar]:
                    return Clifford1Gate(cg).inverse_circuit(target,nqubits)
            raise Exception('Failed to find a suitable single-qubit Clifford op to map X,Z to %s' % str([gz,gx]))
    
        def make_controlled_pauli(ctrl,target,p,nq):
            '''
            Return a controlled-p operation, where p is a single qubit Pauli.  ctrl specifies the control qubit,
            target specifies the target qubit.
            '''
            if p=='X':
                return CliffordCircuit('[CNOT(%d,%d)]' % (ctrl,target),nq)
            if p=='Z':
                return CliffordCircuit('[H(%d),CNOT(%d,%d),H(%d)]' % (target,ctrl,target,target),nq)
            if p=='Y':
                return CliffordCircuit('[S(%d),S(%d),S(%d),CNOT(%d,%d),S(%d)]' % (target,target,target,ctrl,target,target),nq)
            raise Exception("don't know how to make controlled-%s" % p)
    
        def make_controlled_g(ctrl,g,nq):
            '''
            Return a controlled-g operation, where g is a StabilizerElement. ctrl specifies which qubit is the control
            (0 = right-most qubit label).
             Ignores any Pauli on the control qubit.
            '''
            cgc = CliffordCircuit('[]',nq)
            for j in range(nq):
                if j==ctrl: continue
                p = g.qubit_pauli(j)
                if p in 'XYZ':
                    cgc += make_controlled_pauli(ctrl,j,p,nq)
            return cgc
    
        # construct the circuit by iterating through all the qubits, and removing one qubit at a time from the unitary
        # remember all the transforms used; their inverse will be the circuit
    
        cc = CliffordCircuit('[]',nq)			# clifford circuit we've constructed so far
    
        if verbose:
            print("starting pset:")
            print("    --> ",pset)
    
        def xz_stab(k,j):
            return [ pset[2*k+x].qubit_pauli(j,nosign=True) for x in [0, 1] ]

        for k in range(nq-1):		# loop over all but one qubit

            # find a stabilizer with a nontrivial Pauli for this qubit
            if verbose: print("qubit %d" % k)
            xz = xz_stab(k,k)
            if xz[0]=='I' or xz[1]=='I': 	# swap un-processed qubits until get nontrivial Paulis for this qubit
                for j in range(k+1,nq):
                    xz = xz_stab(k,j)
                    if not (xz[0]=='I' or xz[1]=='I'):	# found a suitable qubit: swap it with the active one
                        op = CliffordCircuit('[SWAP(%d,%d)]' % (j,k),nq)
                        cc += op
                        if verbose: print("    swap: %s" % op)
                        pset = op.conjugate(pset,verbose=False)	# act on our Pauli set by SWAP
                        if verbose: print("    --> ",pset)
    
            # make the map X->Z*h, Z->X*g
            gx = pset[k*2].qubit_pauli(k)
            gz = pset[k*2+1].qubit_pauli(k)
            if not [gz,gx]==['X','Z']:
                cgc = find_single_qubit_clifford_inverse(gz,gx,k,nq)		# note flip of x,z (we want an extra Hadamard)
                if verbose: print("    %s" % cgc)
                cc += cgc
                pset = cgc.conjugate(pset,verbose=False)	# act on our Pauli set by cgop
                if verbose: print("    --> ",pset)
    
            # now construct V=C(h)*H*C(g)
            gx = pset[k*2]
            gz = pset[k*2+1]
            V = make_controlled_g(k,gz,nq) + CliffordCircuit('[H(%d)]'%k,nq) + make_controlled_g(k,gx,nq)
    
            # conjugate pset by V
            cc += V
            if verbose: print("    V=%s" % V)
            pset = V.conjugate(pset,verbose=False)
            if verbose: print("    --> ",pset)
    
        # now do the final single qubit remaining
        k = nq-1
        if verbose: print("qubit %d" % k)
        gx = pset[k*2].qubit_pauli(k)
        gz = pset[k*2+1].qubit_pauli(k)
        cgc = find_single_qubit_clifford_inverse(gx,gz,k,nq)
        if verbose: print("    %s" % cgc)
        cc += cgc
        pset = cgc.conjugate(pset,verbose=False)	# act on our Pauli set by cgop
        if verbose: print("    --> ",pset)
    
        if verbose: print(cc)
        return cc	# return the clifford circuit created
    
    def inverse(self):
        '''
        Return the inverse of this circuit.  Assumes S is the only operator which has to be daggered.
        '''
        revc = []
        for k in self.qc[::-1]:
            m = re.match('S\(([0-9]+)\)',str(k))
            if m:
                revc += [k]*3
            else:
                revc.append(k)
        newcc = CliffordCircuit(revc,self.nqubits)
        newcc.simplify()
        return newcc

    def simplify(self):
        '''
        Remove obvious excess Clifford gates, like SSSS->S and HH->[]
        Simplistic.  But helps with inverse.
        '''
        newqc = []
        lastg = None
        stack = []
        for g in self.qc:
            if not g.gate_name in 'HS':
                if stack:
                    newqc += stack
                    stack = []
                newqc.append(g)
                lastg = g
                continue
            if g==lastg:
                lastg = g
                if g.gate_name=='H':
                    stack = []		# two identical H in a row - flush them
                    continue
                if g.gate_name=='S':	
                    stack.append(g)
                    if len(stack)==4: stack = []	# four identical S in a row - flush
                continue
            if stack:
                newqc += stack
                stack = []
            stack.append(g)
            lastg = g  
        if stack: newqc += stack
        self.qc = newqc

    def PauliMap(self,verbose=False):
        '''
        Return the mapping which our clifford circuit performs on Pauli matrices.  It suffices
        to give this for all pre-images which are single qubit X and Z operators.

        The result is a list of [input,output] pairs, where input and output are StabilizerElement instances.
        '''
        nq = self.nqubits
        map = []
        for k in range(nq):
            for p in 'XZ':
                gstr = 'I'*(nq-k-1) + p + 'I'*k
                map.append([StabilizerElement(gstr),self.conjugate(StabilizerElement(gstr),verbose=verbose)])
        return map

    def __eq__(self,other):
        return self.PauliMap(verbose=False)==other.PauliMap(verbose=False)

    def conjugate(self,g,verbose=True):
        '''
        return conjugation of stabilizer operator op by our clifford circuit
        g should be a StabilizerElement or a string or a list
        '''
        if type(g)==list:
            return [self.conjugate(x,verbose=verbose) for x in g]
        if type(g)==str: 
            g = str(MathUnicodeToAscii(g))
        if type(g)==str:
            g = StabilizerElement(g)
        for gate in self.qc:		# each gate should be an instance of (a subclass of) Gate
            gate.conjugate_stabilizer(g,verbose=verbose)
        return g

#-----------------------------------------------------------------------------
# clifford circuit checking

def check_clifford_circuit_eq(expect, ans, options=None):
    '''
    See if the two clifford circuits are equivalent.  Based on Pauli Map comparison.

    options should be of the form "nqubits=#"
    '''
    odict = parse_options(options)
    nqubits = int(odict.get('nqubits', None))

    #for op in options:				# find options in expect string
    #    if op in expect:
    #        expect = expect.replace(op,'')
    #        options[op] = True

    try:
        expect_circ = CliffordCircuit(expect,nqubits)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating OUR circuit from %s' % (err,expect)}

    try:
        circuit = CliffordCircuit(ans,nqubits)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating circuit from %s' % (err,ans)}

    try:
        svg = circuit.plot()
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s drawing your circuit %s' % (err,ans)}
    
    try:
        ansmap = circuit.PauliMap(verbose=False)
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s computing Pauli map for circuit %s' % (err,ans)}
       
    is_ok = (circuit==expect_circ)	# checks equality of PauliMaps

    msg = 'Graphical rendition of your circuit :<center>%s</center>' % (svg)

    if not odict.get('SKIPMAT', False):
        tex = circuit.matrix_tex()
        msg += '<br/>Unitary transform: %s' % (tex)

    if odict.get('GIVEPM', False):
        msg += '<br/>Your circuit performs the following map on Pauli operators:<br/>'
        (a,b) = list(zip(*ansmap))
        msg += '<p><center>%s &rarr; %s</center>' % (to_latex(str(list(a)),inline=True,dott=True,istex=True,br=''),
                                                  to_latex(str(list(b)),inline=True,dott=True,istex=True,br=''))

    return {'ok':is_ok, 'msg':msg}

#-----------------------------------------------------------------------------
# tests for check_clifford_circuit_eq

def test_clifford_circuit_conjugation1():
    x = CliffordCircuit("[H(0),H(0),H(0), CNOT(1,0), H(0)]", 2)
    assert(str(x.PauliMap())=='[[IX, ZX], [IZ, IZ], [XI, XZ], [ZI, ZI]]')

def test_check_clifford_circuit_eq1():
    expect="[H(0),CNOT(1,0),H(0)]" 
    options="nqubits=2" 
    ans = "[H(0),H(0),H(0), CNOT(1,0), H(0)]"
    ret = check_clifford_circuit_eq(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])


def test_check_clifford_circuit_eq2():
    expect="[CNOT(1,2), H(2), S(1), H(1), CNOT(0,1), H(1)]" 
    options="nqubits=3;GIVEPM=1;SKIPMAT=1" 
    ans = "[CNOT(1,2), H(2), S(1), H(1), CNOT(0,1), H(1),H(0), H(0)]"
    ret = check_clifford_circuit_eq(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

    
#-----------------------------------------------------------------------------
# check Pauli conjugation properties of Clifford circuit

def check_clifford_paulis(expect, ans, options=None):
    '''
    See if the given Clifford circuit conjugates Pauli operators as expected
    '''

    odict = parse_options(options)
    precirc = odict.get('precirc', '')
    nqubits = int(odict.get('nqubits', 0))
    pset = eval(odict.get('pset', ''))

    try:
        expect_pset = dict([x.split(',') for x in pset.split(':')])
    except Exception as err:
        return{'ok':False,'msg': 'Error %s parsing Pauli operator set from %s' % (err,expect)}

    try:
        circuit = CliffordCircuit(ans,nqubits)
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating circuit from %s' % (err,ans)}

    try:
        svg = circuit.plot()
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s drawing your circuit %s' % (err,ans)}
    
    try:
        if precirc:
            circuit = CliffordCircuit(precirc, nqubits) + circuit
    except Exception as err:
        return{'ok':False,'msg': 'Error %s creating circuit from %s' % (err,ans)}

    try:
        ansmap = dict([[x,circuit.conjugate(x,verbose=False)] for x in expect_pset])
    except Exception as err: 
        return{'ok':False,'msg': 'Error %s computing Pauli conjugations for circuit %s' % (err,ans)}
       
    print("expect_pset = ",expect_pset)
    print("ansmap = ",ansmap)
    print("circuit = ",circuit)
    msg = '<p>Graphical rendition of your circuit :<center>%s</center>' % (svg)

    is_ok = True
    for p in expect_pset:
        if not re.match(expect_pset[p],str(ansmap[p])):
            is_ok = False
            msg += '<br/>Your overall circuit maps %s to %s, which is undesired' % (p,ansmap[p])

    if odict.get('GIVEPM', False):
        msg += '<br/>Your overall circuit performs the following map on Pauli operators:<br/>'
        (a,b) = list(zip(*circuit.PauliMap(verbose=False)))
        msg += '<p><center>%s &rarr; %s</center>' % (to_latex(str(list(a)),inline=True,dott=True,istex=True,br=''),
                                                  to_latex(str(list(b)),inline=True,dott=True,istex=True,br=''))

    return {'ok':is_ok, 'msg':msg}

#-----------------------------------------------------------------------------
# tests for check_clifford_paulis

def test_check_clifford_paulis1():
    expect="See solution"
    options="nqubits=2;pset='-YY,[-i]*.Z:ZI,[-i]*.X'"
    ans = "[SWAP(1,0),S(0), H(0)]"
    ret = check_clifford_paulis(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_clifford_paulis2():
    expect="See solution"
    options="nqubits=2;pset='-YY,[-i]*.Z:ZI,[-i]*.X'"
    ans = "[SWAP(1,0),S(0), X(0)]"
    ret = check_clifford_paulis(expect, ans, options)
    print(ret['msg'])
    assert('Your overall circuit maps -YY to YX, which is undesired' in ret['msg'])
    assert(not ret['ok'])

def test_check_clifford_paulis3():
    expect="See solution"
    options="nqubits=2;precirc=[SWAP(1,0),S(0), H(0)];pset='-YY,IX:ZI,IZ'"
    ans = "[H(0), S(1), S(1), S(1),  CNOT(0,1), S(1)]"
    ret = check_clifford_paulis(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_clifford_paulis4():
    expect="See solution"
    options="nqubits=2;precirc=[SWAP(1,0),S(0), H(0), H(0), S(1), S(1), S(1),  CNOT(0,1), S(1)];pset='-YY,IX:ZI,IZ:ZZ,XI:ZX,ZI'"
    ans = "[H(1)]"
    ret = check_clifford_paulis(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

#-----------------------------------------------------------------------------
# teleportation circuits: unitary on state + ancilla followed by quantum operation

def my_tensor(s,p):
    '''
    Return tensor product of two quantum states (expressions with Qubit(x)), as another simpel quantum state.
    '''
    try:
        sp = (s*p).expand()		# compute naive product of the two expressions
    except Exception as err:
        try:
            s2 = my_sympify(str(s), do_ket=True)
            p2 = my_sympify(str(p), do_ket=True)
            sp = (s2*p2).expand()
        except Exception as err2:
            msg = "[my_tensor] failed to compute tensor product of %s and %s" % (repr(s), repr(p))
            msg += "\nError1 = %s" % str(err)
            msg += "\nError2 = %s" % str(err2)
            raise Exception(msg)

    if p==1 or s==1:
        return sp

    def qmerge(q1,q2):
        return Qubit(''.join([str(x) for x in (q1.label+q2.label)]))

    def fix_mul(x):
        if isinstance(x,sympy.Pow):
            return qmerge(x.args[0],x.args[0])
        if not isinstance(x,sympy.Mul):
            raise Exception('Cannot reduce tensor %s (type %s)' % (x,type(x)))
        xa = list(x.args)
        if isinstance(xa[-1],sympy.Pow):
            qs = xa[-1].args[0]
            xa[-1] = qmerge(qs,qs)
        if isinstance(xa[-1],Qubit) and isinstance(xa[-2],Qubit):
            xa = xa[:-2] + [qmerge(xa[-2],xa[-1])]
        return sympy.Mul(*xa)
    
    if isinstance(sp,sympy.Mul):
        return fix_mul(sp)

    if isinstance(sp,sympy.Add):
        return sympy.Add(*[fix_mul(x) for x in sp.args])

def test_mt1():
    a = sympy.Symbol('a')
    b = sympy.Symbol('b')
    s = Qubit('0')
    p = a*Qubit('0')+b*Qubit('1')
    sp = my_tensor(s,p)
    assert(str(sp)=="a*|00> + b*|01>")
    return s, p, sp

def test_mt2():
    a = sympy.Symbol('a')
    b = sympy.Symbol('b')
    p = a*Qubit('0')+b*Qubit('1')
    s = p
    sp = my_tensor(s,p)
    assert(str(sp)=="a**2*|00> + a*b*|01> + a*b*|10> + b**2*|11>")
    return s, p, sp

def test_mt3():
    s = my_sympify("a*|0>+b*|1>", do_ket=True)
    p = my_sympify("exp(-I*pi/8)*|0>/2 + exp(I*pi/8)*|0>/2 - exp(I*pi/8)*|1>/2 + exp(-I*pi/8)*|1>/2", do_ket=True)
    sp = my_tensor(s,p)
    assert(str(sp)=="a*exp(-I*pi/8)*|00>/2 + a*exp(I*pi/8)*|00>/2 - a*exp(I*pi/8)*|01>/2 + a*exp(-I*pi/8)*|01>/2 + b*exp(-I*pi/8)*|10>/2 + b*exp(I*pi/8)*|10>/2 - b*exp(I*pi/8)*|11>/2 + b*exp(-I*pi/8)*|11>/2")
    return s, p, sp

class TeleportCircuit(object):
    def __init__(self, nqubits, ancilla_circuit, teleport_circuit, fixup_circuits):
        '''
        fixup_circuits should be an ordered list of 2^nqbit entries, specifying the operation
        to apply to the post-measurement state, depending on the measurement outcome.  The order
        corresponds to 000... to 111...
        '''
        self.nqubits = nqubits			# should be size of ancilla, and size of state to be teleported
        self.ancilla_circuit = QuantumCircuit(ancilla_circuit,nqubits)
        self.teleport_circuit = QuantumCircuit(teleport_circuit,nqubits)
        self.fixup_circuits = [QuantumCircuit(x,nqubits) for x in fixup_circuits]

    def set_input_state(self,input_state):
        if type(input_state) in (str, str):
            input_state = my_sympify(input_state,do_ket=True,do_qubit=True)
        self.input_state = input_state
        
    def ancilla_state(self):
        return qapply(self.ancilla_circuit.circuit*Qubit('0'*self.nqubits))

    def before_measurement_state(self):
        try:
            self.state = my_tensor(self.input_state,self.ancilla_state())
        except Exception as err:
            msg = "Failed to compute before_measurement_state with input=%s, ancilla=%s" % (self.input_state, self.ancilla_state())
            msg += "\nError %s" % str(err)
            raise Exception(msg)
        return qapply(self.teleport_circuit.circuit*self.state)

    def post_measurement_state(self,evalf=False):
        '''
        Return dict of {measurement_value : state}
        The qubits to measure are self.nqubits to 2*self.nqubits-1 (the top nqubit wires in the circuit)
        Note that the qubit labels are qubit 0 on the RHS.  
        '''
        bms = self.before_measurement_state().expand()
        states = list(bms.args) if isinstance(bms,sympy.Add) else [bms]		# list of qubit states in state
        
        def measure(s):
            if isinstance(s,sympy.Mul):
                qs = s.args[-1]
                coef = s.args[:-1]
            elif isinstance(s,Qubit):
                qs = s
                coef = (1,)
            else:
                raise Exception("[teleport:post_measurement_state] Cannot find qubit in %s (bms=%s)" % (s,bms))
            mv = ''.join([str(x) for x in qs.label[:self.nqubits]])		# measurement value (string rep of bits)
            newqs = Qubit(''.join([str(x) for x in qs.label[self.nqubits:]]))	# lower qubits, 0:nqubits-1
            news = reduce(sympy.Mul,coef+(newqs,))	# post-measurement state
            return mv, news

        pms = {}
        for s in states:
            mv, news = measure(s)
            if mv in pms:
                pms[mv] += news
            else:
                pms[mv] = news

        if evalf:
            for mv in pms:
                pms[mv] = sympy.simplify(pms[mv]).evalf(chop=True)

        return pms

    def get_fixup_op(self,mv):
        if len(self.fixup_circuits)==2**self.nqubits:	# all possible 2^n circuits provided, so return one
            return self.fixup_circuits[int(mv,2)]
        if not len(self.fixup_circuits)==self.nqubits:
            raise Exception("[TeleportCircuit] Wrong number of fixup circuits provided")
        op = QuantumCircuit('',self.nqubits)
        for k in range(self.nqubits):		# do each bit one at a time
            if mv[self.nqubits-1-k]=='1':
                op = op+self.fixup_circuits[k]	# cascade circuits for each bit, starting at bit 0 (measure qubit nq...2*nq-1)
        return op

    def output_states(self, evalf=False, simplify=True):
        '''
        Return set of output states for each possible result from the measured qubits.
        Output is a dict of {measurement_value : state}
        State is given by applying the appropriate fixup circuit to the post-measurement state.
        '''
        pms = self.post_measurement_state(evalf=evalf)
        for mv in pms:
            op = self.get_fixup_op(mv)
            os = qapply(op.circuit*pms[mv])
            if simplify: os = sympy.simplify(os)
            if evalf: os = os.evalf(chop=True)
            if simplify: os = sympy.simplify(os)
            if evalf: os = sympy.N(os, chop=True)
            if simplify: os = sympy.simplify(os)
            pms[mv] = os
        return pms            

    def output_state(self,evalf=False,verbose=True):
        oset = self.output_states(evalf=evalf)		# dict with {meas_value: state, ...}
        o1 = None
        sfc = SympyFormulaChecker(do_quantum=True)
        for mv in oset:
            if not o1:
                o1 = oset[mv]
                continue
            if oset[mv]==o1: continue
            if oset[mv].evalf() == o1.evalf(): continue
            if sfc.sympy_is_formula_equal(oset[mv], o1): continue	# use sympy_check for equality test of output states
            zq = Qubit('0'*self.nqubits)
            try:				# FIXME - use ip = qapply(Dagger(y)*x) instead
                phase = (o1.coeff(zq) / oset[mv].coeff(zq)).evalf()
                if (oset[mv]*phase).evalf() == o1.evalf():
                    print("[TeleportCircuit] Warning: phase difference %s in outputs" % phase)
                    continue
            except Exception as err:
                pass
            err = "[TeleportCircuit] Outputs are not independent of measurement results"
            err += (': %s' % oset) if verbose else ''
            raise Exception(err)
        output = sympy.simplify(o1*sqrt(2**self.nqubits)).expand()
        if evalf:
            output = output.evalf(chop=True)
        return output
        
    def __str__(self):
        ret = "<TeleportCircuit instance, nqubits=%s" % self.nqubits
        ret += ", ancila_circuit=%s" % self.ancilla_circuit
        ret += ", teleport_circuit=%s" % self.teleport_circuit
        ret += ", fixup_circuits=%s" % self.fixup_circuits
        ret += ">"
        return ret

def test_teleport1():
    nq = 1
    ancilla_circuit = '[H(0),TGate(0)]'
    teleport_circuit = '[CNOT(0,1)]'
    fixup_circuits = ['','[exp(-I*pi/4)*X(0),S(0)]']
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|0>+b*|1>')
    try:
        os = tc.output_state()
    except Exception as err:
        assert('Outputs are not independent of measurement results' in str(err))
    return tc

def test_teleport2():
    nq = 2
    ancilla_circuit = '[H(0),H(1)]'
    teleport_circuit = '[CNOT(1,2),CNOT(0,3)]'
    fixup_circuits = ['','[X(1)]','[X(0)]','[X(0),X(1)]']
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|00>+b*|01>+c*|10>+d*|11>')
    assert(str(tc.output_state())=='a*|00> + b*|10> + c*|01> + d*|11>')
    return tc

def test_teleport3():
    nq = 2
    ancilla_circuit = '[H(1)]'
    teleport_circuit = '[CNOT(1,2),CNOT(3,0),H(3)]'
    fixup_circuits = ['','[X(1)]','[Z(0)]','[X(1),Z(0)]']
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|00>+b*|01>+c*|10>+d*|11>')
    assert(str(tc.output_state())=='a*|00> + b*|10> + c*|01> + d*|11>')
    return tc

def test_teleport4():	# identity
    nq = 2
    ancilla_circuit = '[H(0),H(1)]'
    teleport_circuit = '[CNOT(1,3),CNOT(0,2)]'
    fixup_circuits = ['','[X(0)]','[X(1)]','[X(0),X(1)]']
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|00>+b*|01>+c*|10>+d*|11>')
    assert(str(tc.output_state())=='a*|00> + b*|01> + c*|10> + d*|11>')
    return tc

def test_teleport5():	# controlled-S
    nq = 2
    ancilla_circuit = '[H(0),H(1),CGate(1,S(0))]'
    teleport_circuit = '[CNOT(1,3),CNOT(0,2)]'
    fixup_circuits = ['','[CZ(1,0),S(1),X(0)]','[CZ(1,0),X(1),S(0)]','[CZ(1,0),S(1),X(0),CZ(1,0),X(1),S(0)]']
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|00>+b*|01>+c*|10>+d*|11>')
    # get a*|00> + b*|01> + c*|10> + I*d*|11>
    assert(str(tc.output_state())=='a*|00> + b*|01> + c*|10> + I*d*|11>')
    return tc

def test_teleport6():
    nq = 2
    ancilla_circuit = '[H(1),CGate(1,H(0))]'
    teleport_circuit = '[CNOT(1,3),CZ(2,0),H(2)]'
    czh = 'CNOT(1,0),X(1),CZ(1,0),X(1)'
    fixup_circuits = ['','[%s]'% czh,'[X(1),H(0)]','[X(1),H(0),%s]' % czh]
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|00>+b*|01>+c*|10>+d*|11>')
    # expect:
    #  qp.qapply(qp.QuantumCircuit('[CGate(1,H(0))]',2).circuit * tc.input_state)
    #  = a*|00> + b*|01> + 2**(1/2)*c*|10>/2 + 2**(1/2)*c*|11>/2 + 2**(1/2)*d*|10>/2 - 2**(1/2)*d*|11>/2
    return tc

def test_teleport7():
    # teleport Rx(pi/4)
    # note:
    # qp.QuantumCircuit('[Rx(0,pi/4),Z(0),Rx(0,-pi/4)]',1).matrix().evalf(chop=True)
    # = qp.QuantumCircuit('[exp(I*pi/4)*Z(0),H(0),S(0).inv(),H(0)]',1).matrix().evalf(chop=True)
    #
    # In [815]: qapply(qp.QuantumCircuit('[Rx(0,pi/4)]',1).circuit*tc.input_state).evalf()
    # Out[815]: 0.923879532511287*a*|0> - 0.38268343236509*I*a*|1> - 0.38268343236509*I*b*|0> + 0.923879532511287*b*|1>
    # 
    # In [816]: tc.output_state().evalf()
    # Out[816]: 0.923879532511287*a*|0> + 0.38268343236509*I*a*|1> + 0.38268343236509*I*b*|0> + 0.923879532511287*b*|1>

    # note:
    # In [930]: qp.QuantumCircuit('[S(0),H(0),S(0),S(0),S(0)]',1).matrix().evalf(chop=True).H
    # Out[930]: 
    # [   0.707106781186548, 0.707106781186548*I]
    # [-0.707106781186548*I,  -0.707106781186548]
    # 
    # In [931]: qp.QuantumCircuit('[Rx(0,-pi/4),Z(0),Rx(0,pi/4)]',1).matrix().evalf(chop=True)
    # Out[931]: 
    # [   0.707106781186548, 0.707106781186548*I]
    # [-0.707106781186548*I,  -0.707106781186548]

    # In [949]: qapply(qp.QuantumCircuit('[Rx(0,pi/4)]',1).circuit*tc.input_state).evalf()
    # Out[949]: 0.923879532511287*a*|0> - 0.38268343236509*I*a*|1> - 0.38268343236509*I*b*|0> + 0.923879532511287*b*|1>
    # 
    # In [950]: tc = qp.test_teleport7()
    # 
    # In [951]: tc.output_state(evalf=True)
    # Out[951]: 0.923879532511287*a*|0> - 0.38268343236509*I*a*|1> - 0.38268343236509*I*b*|0> + 0.923879532511287*b*|1>

    nq = 1
    ancilla_circuit = '[Rx(0,pi/4)]'
    # ancilla_circuit = '[]'
    teleport_circuit = '[CNOT(1,0),H(1)]'
    fixup_circuits = ['[]','[S(0),H(0),S(0),S(0),S(0)]']
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|0>+b*|1>')
    print("output state=%s" % tc.output_state(evalf=True))
    out = tc.output_state(evalf=True)
    return tc

def test_teleport8():
    # teleport Toffoli
    nq = 3
    ancilla_circuit = '[H(1),H(2),Toffoli(2,1,0)]'
    teleport_circuit = '[CNOT(2,5),CNOT(1,4),CNOT(3,0),H(3)]'
    fixup_circuits = ['[CZ(1,2),Z(0)]','[CNOT(2,0),X(1)]','[X(2),CNOT(1,0)]']
    tc = TeleportCircuit(nq,ancilla_circuit,teleport_circuit,fixup_circuits)
    tc.set_input_state('a*|000>+b*|001>+c*|010>+d*|011>+f*|100>+g*|101>+h*|110>+k*|111>')
    assert(str(tc.output_state())=='a*|000> + b*|001> + c*|010> + d*|011> + f*|100> + g*|101> + h*|111> + k*|110>')
    return tc

#-----------------------------------------------------------------------------

def sanitize_response(value, allow_lists=True):
    """
    Strip unusual unicode from value
    """
    try:
        if isinstance(value, list):  # edX answers can be lists; sanitize all items in this case
            if allow_lists:
                return [sanitize_response(item) for item in value]
            else:
                value = str(value[0])	# if we don't allow lists, only take the first element
    
        if isinstance(value, str):  # Only do string substitution on strings
            for char in set(value):
                try:
                    category = unicodedata.category(str(char))
                    if category == 'Cc' or category == 'Cf':
                        value = value.replace(char, '')
                except Exception as err:
                    if 0:
                        print("Warning - failure to strip unicode from %s, err=%s" % (value, str(err)))
        return value
    except Exception as err:
        raise Exception("Failed to sanitize input %s, err=%s" % (value, str(err)))

#-----------------------------------------------------------------------------

def check_teleport(expect, ans, options=None, just_test=False):
    '''
    Check ans for proper teleportation circuit operation.

    expect is typically an XML expression giving the teleportation circuit, ancilla circuit, the
    fixup circuits, and a circuit specifying U, the expected unitary transform performed
    by the teleported gate.
    '''
    
    # fields
    # nq          - number of qubits
    # tc          - teleportation circuit
    # ac          - ancilla circuit
    # fc          - fixup circuit (attribute mv = measurement value, bit=which qubit)
    # U           - unitary transform expected to be performed
    # cinput      - string specifying circuit input state
    # fcbybit     - specifies that fixup circuits should be done by bit (so nq circuits)

    odict = parse_options(options)
    nq = int(odict.get('nq', 0))
    tc = odict.get('tc', '')
    acpat = odict.get('acpat', '')
    acrepl = odict.get('acrepl', '')
    fc = odict.get('fc', '')
    U = odict.get('U', '')
    cinput = odict.get('input', '')
    
    ans = sanitize_response(ans, allow_lists=True)
    # print("sanitized ans=%s" % ans)

    ac = ans[0].replace(acpat, acrepl)
    

    #if not options['loadfrom']==None:			# if loadfrom is specified, then get the return result
    #    name = options['loadfrom'].attrib['name']	# from adict[name] and don't go any further
    #    if not name in adict:
    #        return {'ok':False,'msg':'Your multi-part answer is incomplete and cannot be checked (ref %s)' % name}
    #    ret = adict[name]
    #    if not options['skipoutput']==False:
    #        return {'ok':ret['ok'],'msg':''}		# suppress the message if skipoutput=True
    #    return ret

    #if not skipsaveas:
    #    if not options['saveas']==None:			# if saveas is specified, then save our return result
    #        name = options['saveas'].attrib['name']	# in adict[name] for future use
    #        try:
    #            ret = check_teleport(expect_orig,ans,adict,skipsaveas=True)	# get return result
    #        except Exception,err:
    #            ret = {'ok':False,'msg':'Error <font color=red>%s</font><p><font color=blue>Note all parts must be entered correctly for the answer to the question to be check#ed.</font>' % err}
    #        adict[name] = ret				# save it
    #        if not options['skipoutput']==False:
    #            return {'ok':ret['ok'],'msg':''}	# suppress the message if skipoutput=True
    #        return ret

    #def gettag(tag,attrset={}):
    #    if not attrset:
    #        elem = root.find(tag)
    #    else:
    #        found = 0
    #        for elem in root.findall(tag):
    #            eitems = elem.attrib.items()
    #            if reduce(lambda x,y:x and y,[(x in eitems) for x in attrset.items()]):
    #                found = 1
    #                break
    #        if not found:
    #            raise Exception,"Can't find %s in expect XML with attributes %s!" % (tag,attrset)
    #    if elem==None:
    #        raise Exception,"Can't find %s in expect XML!" % tag
    #    if 'from' in elem.attrib:		# get circuit from adict
    #        entry = elem.attrib['from']
    #        if not entry in adict:
    #            raise Exception,"Missing %s in answers" % entry
    #        result = adict[entry]
    #    else:
    #        result = str(elem.text)
    #    if 'pat' in elem.attrib and 'repl' in elem.attrib: # replace pattern in string
    #        #result = re.sub(elem.attrib['pat'],elem.attrib['repl'],result)
    #        result = result.replace(elem.attrib['pat'],elem.attrib['repl'])	# escaping parens doesn't work with latex2tut
    #    return result

    def getcirc(circstr, nqubits, attrset=None, excludeset=[]):
        try:
            circuit = QuantumCircuit(circstr,nqubits,excludeset=excludeset)
        except Exception as err:
            raise Exception("Error %s in creating circuit from %s" % (err,circstr))
        return circuit

    def binstr(nbits,x):
        return bin(x)[2:].rjust(nbits, '0')
    def binstrs(nbits):
        return [ binstr(nbits,x) for x in range(0,2**nbits)]

    try:
        teleport_circuit = getcirc(tc,nq*2)
    except Exception as err:
        return {'ok': False, 'msg': "Could not create teleportation circuit %s" % tc}
    try:
        ancilla_circuit = getcirc(ac,nq)
    except Exception as err:
        return {'ok': False, 'msg': "Could not create ancilla circuit from your input %s" % ac}
    try:
        U_circuit = getcirc(U,nq)
    except Exception as err:
        return {'ok': False, 'msg': "Could not create U circuit from %s" % U}

    excludeset = [GATES_DICT[x] for x in ['Rx','Ry','Rz','T','Toffoli']]
    #    fixup_circuits = [ getcirc('fc',nq,attrset={'bit':str(x)},excludeset=excludeset) for x in range(nq) ]
    #else:
    #    fixup_circuits = [ getcirc('fc',nq,attrset={'mv':x},excludeset=excludeset) for x in binstrs(nq) ]
    
    fixup_circuits = [ ]
    if odict.get('fcbybit', ''):
        cnt = 0
        for x in range(nq):	# one bit at a time
            cnt += 1
            try:
                fixup_circuits.append( getcirc(ans[cnt], nq, attrset={'bit':str(x)}, excludeset=excludeset) )
            except Exception as err:
                return {'ok': False, 'msg': "Something wrong with your fix-up circuit; does it act on the right qubits?  err=<pre>%s</pre>" % str(err)}
    else:
        cnt = 0
        for x in binstrs(nq):	# all possible bit string values
            cnt += 1
            try:
                fixup_circuits.append( getcirc(ans[cnt], nq, attrset={'mv':str(x)}, excludeset=excludeset) )
            except Exception as err:
                return {'ok': False, 'msg': "Something wrong with your fix-up circuit; does it act on the right qubits?  err=<pre>%s</pre>" % str(err)}

    input_state = cinput
    tc = TeleportCircuit(nq, ancilla_circuit, teleport_circuit, fixup_circuits)
    tc.set_input_state(input_state)

    # return tc
    try:
        # test_mt3()
        outputs = tc.output_states(evalf=True)
    except Exception as err:
        if 1:
            msg = "<html>Cannot compute output of teleportation circuit, err=<pre>%s</pre>" % str(err).replace('<', '[')
            if 0:
                msg += "traceback: <pre>%s</pre>" % traceback.format_exc().replace('<', '[')
                msg += "response = <pre>%s</pre>" % repr(ans)
                msg += "options = <pre>%s</pre>" % options
            msg += "tc = <pre>%s</pre>" % odict.get('tc', '')
            msg += "ac = <pre>%s</pre>" % ac
            msg += "U = <pre>%s</pre>" % U
            try:
                msg += '<p>Ancilla circuit:</p> <center>%s</center>' % (ancilla_circuit.plot())
                msg += "<p>Teleportation circuit:</p> %s" % (teleport_circuit.plot(html=True))
                msg += '<p>Input state:</p> %s' % to_latex(tc.input_state)
            except Exception as err2:
                pass
            msg += "</html>"
            return {'ok': False, 'msg': msg}
        raise

    print("Ancilla circuit=", ancilla_circuit)
    print("Teleport circuit=", teleport_circuit)
    print("input_state=", tc.input_state)
    print("fixup_circuits", fixup_circuits)
    print("U", U_circuit)

    msg = '<html>'
    # msg += "ac = " + str(ancilla_circuit.qc)
    if True:
        msg += '<p>Ancilla circuit:</p> <center>%s</center>' % (ancilla_circuit.plot())
        msg += "<p>Teleportation circuit:</p> %s" % (teleport_circuit.plot(html=True))
        msg += '<p>Input state:</p> %s' % to_latex(tc.input_state)
        for mv in sorted(outputs.keys()):
            msg += "<p>Measurement outcome %s:</p>" % mv
            msg += "<blockquote>"
            msg += "<p>Fixup circuit: %s</p>" % (tc.get_fixup_op(mv).plot(html=True))
            msg += "<p>Teleportation circuit output: %s</p>" % to_latex(outputs[mv])
            msg += "</blockquote>"

    # raise Exception(msg)

    try:
        # tcout = tc.output_state(evalf=True, verbose=False)
        tcout = tc.output_state(evalf=True, verbose=True)
    except Exception as err:
        print("[check_teleport] error computing output state, tc=%s" % tc)
        print("[check_teleport] err=%s" % str(err))
        msg += '<p><font color=red>Error: %s</font></p></html>' % str(err)
        return {'ok': False, 'overall_message': msg, 'input_list': [{'ok': False} for k in range(len(ans))]}

    # FIXME: allow close answers
    try:
        expect_out = qapply(U_circuit.circuit*tc.input_state).evalf(chop=True)
        # is_ok = my_chop(tcout-expect_out)==0
        sfc = SympyFormulaChecker(do_quantum=True)
        is_ok = sfc.sympy_is_formula_equal(expect_out, tcout)		# use sympy_check for robustness
    except Exception as err:
        if 1:
            msg += "<p>Failed to compute expected output!</p>"
            msg += "<p>err=%s</p>" % str(err).replace('<', '[')
            msg += "traceback: <pre>%s</pre>" % traceback.format_exc().replace('<', '[')
            msg += "U_circuit = <pre>%s</pre>" % U_circuit.circuit
            msg += "</html>"
            return {'ok': False, 'msg': msg}
        raise 

    print("expect_out: ", expect_out)
    print("tcout: ", tcout)

    msg += '</html>'

    if just_test:
        return {'tc': tc, 
                'tcout': tcout,
                'expect_out': expect_out,
                'msg': msg,
                }

    if not is_ok:
        zq = Qubit('0'*nq)

        #print "zq=", zq
        #print "tc coef zq=", tcout.coeff(zq)
        #print "eo coef zq=", expect_out.coeff(zq)

        is_ok = states_equal_up_to_phase(tcout, expect_out, zq=zq)

    return {'ok': is_ok, 'overall_message': msg, 'input_list': [{'ok': is_ok} for k in range(len(ans))]}
    #return {'ok':is_ok, 'msg':msg}

def test_ct1_ac():
    circstr = '[Rx(0, pi/4)]'
    circuit = QuantumCircuit(circstr, nqubits=1, excludeset=[])
    print("circstr=%s" % circstr)
    print("circuit=%s" % circuit)
    assert(str(circuit)=="[Rx(0,pi/4)]")

def test_ct1():
    #adict = {'ancilla': '[Rx(0,pi/4)]','fixup0':'[]','fixup1':'[S(0),H(0),S(0),S(0),S(0)]'}
    ans = ['[Rx(0,pi/4)]','[]', '[S(0),H(0),S(0),S(0),S(0)]']
    #es = "__XML__<nq>1</nq><tc>[CNOT(1,0),H(1)]</tc><ac from='ancilla'/><fc mv='1'>[S(0),H(0),S(0),S(0),S(0)]</fc><fc mv='0'>[]</fc><U>[Rx(0,pi/4)]</U><input>a*|0>+b*|1></input><skipoutput/>"
    #es="__XML__<nq>1</nq><tc>[CNOT(1,0),H(1)]</tc><ac from='ancilla' pat='V\(([0-9])\)' repl='Rx(\\1,pi/4)'/><fc mv='1' from='fixup1'/><fc mv='0' from='fixup0'/><U>[Rx(0,pi/4)]</U><input>a*|0>+b*|1></input><skipoutput/>" 
    #es="__XML__<nq>1</nq><tc>[CNOT(1,0),H(1)]</tc><ac from='ancilla' pat='V(0)' repl='Rx(0,pi/4)'/><fc mv='1' from='fixup1'/><fc mv='0' from='fixup0'/><U>[Rx(0,pi/4)]</U><input>a*|0>+b*|1></input><skipoutput/>" 

    #es="__XML__<nq>1</nq><tc>[CNOT(1,0),H(1)]</tc><ac from='ancilla' pat='V(0)' repl='Rx(0,pi/4)'/><fc mv='1' from='fixup1'/><fc mv='0' from='fixup0'/><U>[Rx(0,pi/4)]</U><input>a*|0>+b*|1></input><skipoutput/>" 
    expect = ''
    options="nq=1;U=[Rx(0,pi/4)];tc=[CNOT(1,0),H(1)];acpat=V(0);acrepl=IdentityGate(0),Rx(0,pi/4),IdentityGate(0);input=a*|0>+b*|1>"
    out = check_teleport(expect, ans, options, just_test=True)
    if "overall_message" in out:
        print(out['overall_message'])
    print(out)
    assert "overall_message" not in out
    ret = check_teleport(expect, ans, options)
    assert(ret['input_list'][0]['ok'])

def test_ct2():
    expect = ''
    ans = ['[H(1),H(2),Toffoli(2,1,0)]',
           '[CZ(1,2),Z(0)]',
           '[CNOT(2,0),X(1)]',
           '[X(2),CNOT(1,0)]',
           ]
    # es = "__XML__<nq>3</nq><tc>[CNOT(2,5),CNOT(1,4),CNOT(3,0),H(3)]</tc><ac from='ancilla'/><fc bit='0' from='fixup0'/><fc bit='1' from='fixup1'/><fc bit='2' from='fixup2'/><fcbybit/><U>[Toffoli(2,1,0)]</U><input>a*|000>+b*|001>+c*|010>+d*|011>+f*|100>+g*|101>+h*|110>+k*|111></input>"
    options="nq=3;U=[Toffoli(2,1,0)];tc=[CNOT(2,5),CNOT(1,4),CNOT(3,0),H(3)];input=a*|000>+b*|001>+c*|010>+d*|011>+f*|100>+g*|101>+h*|110>+k*|111>;fcbybit=1"
    out = check_teleport(expect, ans, options, just_test=True)
    print(out)
    ret = check_teleport(expect, ans, options)
    assert(ret['input_list'][0]['ok'])

#-----------------------------------------------------------------------------
# qcml (quantum circuit measurement language)
# based on the Measurement Calculus

class MeasurementValue(object):
    '''
    Keep track of (boolean) measurement values for a set of qubits.
    Has a string representation, and is hashable, so that it can be used
    as a key in a dict.

    All the data is stored in one attribute: self.mvlist

    '''
    def __init__(self,mv):
        '''
        mv can be a string or a list
        '''
        if type(mv) in (str, str):
            self.mvlist = self.str2mv(mv)
        elif type(mv)==int:
            self.mvlist = ['x']*mv
        else:
            self.mvlist = mv
            
    def __str__(self):
        return self.mv2str()

    __repr__ = __str__
    
    def get_nqubits(self):
        return len(self.mvlist)
    
    nqubits = property(get_nqubits,None,None,"Number of qubits in each measurement value")

    def extend(self,bit):
        '''
        Extend the measurement value by adding another bit.
        Since instances of this must be immutable, we return a new instance
        '''
        return MeasurementValue(self.mvlist + [bit])

    def mv2str(self):
        '''
        measurement values are stored as a string, so that they can be used as a hashable key for the dict.
        measurement values are a set of bits, one for each logical qubit.
        the measurement value list is stored in the same order as the logical qubit set, lqbset.
        the measurement value string is REVERSED, so that the string order matches the qubit label order (RH bit=0)
        '''
        return ''.join([str(x) for x in self.mvlist[::-1]])

    def str2mv(self,mvstr):
        return list(mvstr)[::-1]

    def get_bit(self,lqnum):
        '''
        Return measurement value for logical qubit from mv (list or string), as integer 0 or 1
        '''
        # return int(self.mvlist[self.lqbset.index(lqnum)])
        return int(self.mvlist[lqnum])

    def set_bit(self,lqnum,value):
        '''
        Record measurement value for logical qubit in mv (returns modified instance of self)
        Since instances of this must be immutable, we return a new instance
        '''
        #self.mvlist[self.lqbset.index(lqnum)] = value
        newmvlist = self.mvlist[::]
        newmvlist[lqnum] = value
        return MeasurementValue(newmvlist)

    def set_merged(self):
        '''
        Change all numerical measurement values to 'm', to indicate that the measurement values
        have been merged.  

        Since instances of this must be immutable, we return a new instance
        '''
        newmvlist = [ ('m' if x in [0,1,'0','1'] else x) for x in self.mvlist ]
        return MeasurementValue(newmvlist)

    def extend(self):
        '''
        Extend measurement value by adding a 'x' to the end.  
        Since instances of this must be immutable, we return a new instance
        '''
        newmvlist = self.mvlist[::] + ['x']
        return MeasurementValue(newmvlist)
        
    def __hash__(self):
        return hash(tuple(self.mvlist))
        


class QuantumStateSet(object):
    '''
    Represent quantum state as a dict of possible pure states, each resulting from different measurement outcomes.
    Initially, for no measurement outcomes yet, this is a dict with key = 'x'*nqubits, value = state.

    Provides method for applying unitary operation to state dict.

    Provides method for measuring one qubit, and updating the resulting outcome dict.

    Keeps track of logical qubit labels versus labels used for the reduced post-measurement states.
    The reduced post-measurement states have qubits labeled from the left starting at 0.

    Allows sets of states resulting from different measurement outcomes to be merged, if they are
    the same (ie strongly deterministic).  This simplifies QCML simulations tremendously.

    TODO: make measurement value a class

    Attributes:

     - qubitmap: dict which maps from logical qubit (int) to physical qubit index (int)

    '''
    verbose = True
    msg = []

    def __init__(self,state,nqubits,lqbset=None):
        '''
        optional lqbset = list of integers denoting the logical qubits (not necessarily contiguous or ordered)
        '''
        self.nqubits = nqubits					# number of logical qubits
        self.npqubits = nqubits					# number of physical qubits (decreases after meas)
        self.stateset = { MeasurementValue(nqubits) : state }
        if lqbset==None: lqbset=list(range(nqubits))
        self.lqbset = lqbset[::]				# list of logical qubit labels (make sure to copy it)
        self.qubitmap = dict( list(zip(lqbset,list(range(nqubits)))) )	# map from logical to physical qubit labels

    def __getitem__(self,k):
        for mv in self.stateset:
            if str(mv)==k: return self.stateset[mv]
        raise Exception('[QSS] no entry for measurement value %s' % k)

    def signals(self,mv,signum):
        '''
        if signum == 's%d' then look up corresponding measurement value on qubit %d
        if signum == 0 then return 0
        '''
        if signum==0 or signum=='0': return 0
        m = re.match('s([0-9]+)',signum)
        if not m:
            raise Exception('[QSS]: wrong syntax for signal - should be s# where # is an integer, not "%s"' % signum)
        lqnum = int(m.group(1))	# logical qubit number of the signal
        lqnum = self.lqbset.index(lqnum)	# turn it into an index, for the measurement value lookup
        try:
            sval = mv.get_bit(lqnum)	# signal value is 0 or 1
        except Exception as err:
            raise Exception('[QSS] no signal %s' % signum)
        return sval

    def log(self,s):
        if self.verbose: print(s)
        self.msg.append(s)

    def qapply(self,op):	# op should be a Cop or Mop
        self.do_measure = None
        for mv in self.stateset:	# do conditional rotations on each unraveled state in the set
            try:
                op.qapply(self,mv)
            except Exception as err:
                raise Exception("[QuantumStateSet] failed to apply op=%s (%s) to state %s, on self=%s, traceback=%s" % (op, type(op), mv, self, traceback.format_exc()))

        if not self.do_measure==None:	# do projection measurement afterwards, if requested
            self.log("    --> pre-measurement state = \n%s" % self.__str__())
            self.measure(self.do_measure)
            self.do_measure = None

    def qapply_gate(self, mv, gate):
        self.log("    --> [%s] Applying gate %s" % (mv, gate))
        the_state = self.stateset[mv]
        # self.log("               the_state=%s" % the_state)			# DEBUG
        # self.log("               gate=%s" % represent(gate, nqubits=2))
        ret = qapply(gate*the_state)
        # self.log("               ret=%s" % ret)
        self.stateset[mv] = ret

    def project(self,s,k):			# project state (should be simple, no adds!) s, qubit number k
        if isinstance(s,sympy.Mul):
            qs = s.args[-1]
            coef = s.args[:-1]
        elif isinstance(s,Qubit):
            qs = s
            coef = (1,)
        else:
            raise Exception("[QSS:post_measurement_state] Cannot find qubit in %s (bms=%s)" % (s,bms))
        newlabel = list(qs.label[::])	# copy the label
        mv = newlabel.pop(k)		# remove the qubit which was measured, and make that the measurement value (0 or 1)
        newqs = Qubit(''.join([str(x) for x in newlabel]))	# post-measurement qubits
        news = reduce(sympy.Mul,coef+(newqs,))	# post-measurement state
        return mv, news

    def __str__(self):
        # return str(self.stateset)
        s = ''
        for mv in self.stateset:
            s += '   [%s]: %s\n' % (mv,self.stateset[mv])
        return s

    __repr__ = __str__

    def measure(self,lqnum):
        '''
        Note that lqnum is the LOGICAL qubit number
        The measurement value strings record the LOGICAL qubit measurements, because
        the physical qubits go away after the measurements.
        '''

        pqnum = self.qubitmap[lqnum]

        # abort if the number of states is too large
        nsmax = 8
        if len(self.stateset) >= nsmax:
            raise Exception('[QSS] Sorry, the number of states >= %d: aborting simulation. Try simplifying your program.' % nsmax)

        if pqnum=='M': return		# already measured, don't repeat
        self.log("    --> projecting physical qubit %d (logical qubit %d)" % (pqnum,lqnum))

        newss = {}			# this will become the new stateset
        for oldmv in self.stateset:	# loop over old measurement values & states
            bms = self.stateset[oldmv].expand()
            states = list(bms.args) if isinstance(bms,sympy.Add) else [bms]		# list of qubit states in state
            
            pms = {}		# the post-measurement state is a dict of states for qubit measurement outcomes 0, 1
            for s in states:
                mv, news = self.project(s,self.npqubits-pqnum-1)	# note use of number of PHYSICAL qubits
                if mv in pms: 
                    pms[mv] += news
                else:
                    pms[mv] = news
            lqidx = self.lqbset.index(lqnum)		# turn logical qubit label into index, for mv change
            for mv in pms:
                newmv = oldmv.set_bit(lqidx,mv)		# new measurement value (replaces None with 0 and 1 cases)
                newss[newmv] = pms[mv]

        self.stateset = newss

        # update the qubitmap; keys = logical qubit #, values = physical qubit #
        self.qubitmap[lqnum] = 'M'	# means this qubit was measured
        for k in self.qubitmap:
            if type(self.qubitmap[k])==int and self.qubitmap[k]>pqnum:
                self.qubitmap[k] -= 1	# shift physical index down one, if higher

        self.npqubits -= 1
        self.log("    --> new logical->physical qubit map: %s" % self.qubitmap)

    def evalf(self):
        for mv in self.stateset:
            self.stateset[mv] = sympy.simplify(self.stateset[mv]).evalf(chop=True)

    def subs(self,x,y):
        '''
        subsitute y for x in stateset expressions; run my_sympify on x and y
        '''
        x = my_sympify(x,do_ket=True,do_qubit=True)
        y = my_sympify(y,do_ket=True,do_qubit=True)
        for mv in self.stateset:
            self.stateset[mv] = self.stateset[mv].subs(x,y)
        return self

    def is_strongly_deterministic(self,justflag=False):
        x = None

        if len(self.stateset)==1:
            if justflag: return True
            return {'ok':True}

        zq = Qubit('0'*self.npqubits)

        for mv in self.stateset:
            y = sympy.simplify(self.stateset[mv]).evalf(chop=True)
            if not x:
                x=y
                continue

            if states_equal_up_to_phase(x,y,zq=zq): continue

            if justflag: return False
            return {'ok':False,'msg':'State is not strongly deterministic, meaning the state is not independent of the measurement values'}
        if justflag: return True
        return {'ok':True}

    def merge(self):
        '''
        Merge state set into a single state, if the state set is strongly deterministic
        '''
        if not self.is_strongly_deterministic(justflag=True):
            self.log("    --> can't merge - not strongly deterministic")
            return
        mv = list(self.stateset.keys())[0]	# change to special mv indicating merge
        state = self.stateset[mv]
        self.stateset = { mv.set_merged() : state }
        self.log("    --> merged into one state = %s" % self.stateset)

    def extend(self,lqubit):
        '''
        Extend state by adding a new logical qubit, with label = lqubit.  Does thsi by
        tensor producting |+> to the LHS of each physical qubit in the current stateset.
        '''
        pqubit = self.npqubits	# label for the new physical qubit
        self.npqubits += 1
        pstate = my_sympify('|0>+|1>',do_ket=True,do_qubit=True)

        nss = {}
        for mv in self.stateset:
            nss[mv.extend()] = my_tensor(pstate,self.stateset[mv])

        self.qubitmap[lqubit] = pqubit	# add to the logical -> physical qubit map
        self.lqbset.append(lqubit)	# add to set of logical qubit labels 
        self.stateset = nss		# new state set
        self.log('    --> Extended state to include logical qubit %d (= physical qubit %d)' % (lqubit,pqubit))

    def relabel(self,qmap,state=None):		# relabel states (called to make final outputs correspond to expected order)
        if not state:
            for mv in self.stateset:
                self.stateset[mv] = self.relabel(qmap,self.stateset[mv])
            return self
        state = state.expand()
        logical2physical = self.qubitmap
    
        def remap(pqb):		# pqb is a string
            pqb = list(pqb)[::-1]	# now it is a list
            newpqb = [ pqb[logical2physical[qmap[x]]] for x in range(self.nqubits) ]
            # print "newpqb = ",newpqb
            return ''.join([str(x) for x in newpqb[::-1]])

        def map_one(state):
            def map_qubit(q):
                return Qubit(remap(q.label))
            if isinstance(state,Qubit):
                return map_qubit(q)
            elif isinstance(state,sympy.Mul):
                xa = list(state.args)
                xa = xa[:-1] + [map_qubit(xa[-1])]
                return sympy.Mul(*xa)
            raise Exception('[QCML] failed in relabling qubit state! state=%s' % state)
        if isinstance(state,sympy.Mul):
            return map_one(state)
        if isinstance(state,sympy.Add):
            return sympy.Add(*[map_one(x) for x in state.args])

def test_qss1():
    qss = QuantumStateSet(my_sympify('(|00>+|11>)/sqrt(2)',do_ket=True,do_qubit=True),2)
    return qss

def test_qss2():
    qss = QuantumStateSet(my_sympify('|000>+2*|110>+3*|111>+4*|101>',do_ket=True,do_qubit=True),3)
    return qss

#-----------------------------------------------------------------------------

class QCML(object):
    '''
    Quantum circuit measurement language object.

    Each QCML instance is defined by:

    - input   : list of input logical qubits
    - output  : list of output logical qubits
    - ops     : list of operations (instances of Eop, Mop, and Cop)

    Other attributes:

    - lqbset  : list of all the logical qubits (this is computed from the above three)

    Methods provided:

    - simulate : simulate QCML program, and return the resulting QuantumStateSet
    - remap    : return QCML resulting from mapping logical qubit labels

    Syntax:

    - E(i,j)         = Controlled-Z gate between qubits i and j ("entangling")
    - M(i,alpha)     = measurement of qubit i with angle alpha.
    - M(i,alpha,s,t) = M(i,(-1)^s * alpha + t*pi)
    - X(i,s)         = Pauli X on qubit i if bit s=1
    - Z(i,s)         = Pauli Z on qubit i if bit s=1

    Incidental Rules:

    - [ M(i,alpha) , X(i) ] = [ M(i,-alpha) ]
    - [ M(i,alpha) , Z(i) ] = [ M(i,alpha-pi) ]

    Rewrite Rules:

    - [ X(i,s), E(i,j) ] = [ E(i,j), Z(j,s), X(i,s) ]
    - [ X(j,s), E(i,j) ] = [ E(i,j), Z(i,s), X(j,s) ]
    - [ Z(i,s), E(i,j) ] = [ E(i,j), Z(i,s) ]
    - [ Z(j,s), E(i,j) ] = [ E(i,j), Z(j,s) ]
    - [ X(i,r), M(i,alpha,s,t) ] = [ M(i,alpha,s+r,t) ]
    - [ Z(i,r), M(i,alpha,s,t) ] = [ M(i,alpha,s,r+t) ]

    Constraints:

    - D0: no command depends on an outcome not yet measured
    - D1: no command acts on a qubit already measured
    - D2: no command acts on a qubit not yet prepared, unless it is an input qubit
    - D3: a qubit i is measured if and only if i is not an output

    Example 1: Hadamard

    	input	1
	output	2
	E	1,2
        M	1,0
        X	2,s1

    Example 2: P(alpha)=[[1,0],[0,exp(i*alpha)]] single-quibit gate

    	input	1
        output	3
    	E	1,2
        M	1,-alpha
        X	2,s1
	E	2,3
        M	2,0
        X	3,s2

    Example 3: P(alpha)=[[1,0],[0,exp(i*alpha)]] single-quibit gate using macros

        defmac	J	alpha,x,y	; input=x, output=y
        	E	x,y
                M	x,-alpha
                X	y,sig(x)
	endmac

    	defmac	Had	x,y		; input=x, output=y
                J	0,x,y
	endmac

    	defmac	P	alpha,x,y	; input=x, output=y
		New	1
        	J	alpha,x,1
                H	1,y
	endmac

    '''
    msg = []

    def __init__(self,script):

        if type(script)==dict:
            self.input = script['input']
            self.output = script['output']
            self.ops = script['ops']
            self.check_script()
            return

        if type(script)==QuantumCircuit:	# convert QuantumCircuit to QCML
            return self.qc2qcml(script)

        if type(script)==str: script = str(script)
        if type(script)==str:
            self.parse_script(script)
        else:
            raise Exception('[QCML]: script input must be a string, not %s' % script)

        self.check_script()

    def compute_lqbset(self):
        s = []
        for op in self.ops:
            s += op.qubits
        s = list(set(s))
        s.sort()
        return s

    lqbset = property(compute_lqbset,None,None,'List of logical qubits used in this QCML program')

    def make_script(self):
        s = 'input	%s\n' % ','.join([str(x) for x in self.input])
        s += 'output	%s\n' % ','.join([str(x) for x in self.output])
        s += '\n'.join([op.script() for op in self.ops])
        return s

    script = property(make_script,None,None,'QCML program for this instance')

    def __add__(self,other):
        '''
        Combine two QCML instances into one new one, with cascaded instructions.
        Leaves the inputs as the inputs to the first circuit, and takes the outputs
        as being outputs1 - input2 + outputs2
        '''
        if not isinstance(other,self.__class__):
            raise Exception("[QCML] Can't add non-qcml instance to qcml instance")

        newops = self.ops + other.ops
        newinput = self.input
        newoutput = list((set(self.output)-set(other.input)).union(set(other.output)))

        return self.__class__({'input':newinput,
                               'output':newoutput,
                               'ops':newops})

    class Cop(object):				# correction operator
        gate = GATES_DICT['X']
        def __init__(self,i,s,opstr=''):
            self.opstr = opstr			# for error messages
            self.qubits = [int(i)]
            self.sidx = s

        def remap(self,old2new):		# return same operator, but acting on relabeled qubits
            return self.__class__(old2new[self.qubits[0]],old2new[self.sidx])

        def qapply(self,state,mv):
            '''
            qubitmap = dict translating logical qubit to remaining physical qubit index
            signals = dict giving state of each of the measured qubits so far (the signals)
            '''
            if state.signals(mv,self.sidx):
                pqb = state.qubitmap[self.qubits[0]]
                if pqb=='M':
                    raise Exception('[QCML] Cannot apply gate %s to qubit %s: already measured!' % (self.__str__(),repr(self.qubits)))
                op = self.gate(pqb)
                state.qapply_gate(mv,op)

        def __str__(self):
            return '%s(%d,%s)' % (self.gate.gate_name,self.qubits[0],str(self.sidx))
        __repr__ = __str__

        def script(self):
            return '%s\t%d,%s' % (self.gate.gate_name,self.qubits[0],str(self.sidx))

        def __eq__(self,other):
            if isinstance(other, self.__class__):
                return self.__dict__ == other.__dict__
            return False

    class Xop(Cop):
        gate = GATES_DICT['X']

    class Zop(Cop):
        gate = GATES_DICT['Z']
    
    class Eop(object):	# QCML controlled-Z operator between two qubits

        def __init__(self,i,j,opstr=''):
            self.opstr = opstr			# for error messages
            self.qubits = [int(i),int(j)]

        def remap(self,old2new):		# return same operator, but acting on relabeled qubits
            return self.__class__(old2new[self.qubits[0]],old2new[self.qubits[1]])

        def qapply(self,state,mv):
            pqb1 = state.qubitmap[self.qubits[0]]
            if pqb1=='M':
                raise Exception('[QCML] Cannot apply gate %s to qubit %s: already measured!' % (self.__str__(),self.qubits[0]))
            pqb2 = state.qubitmap[self.qubits[1]]
            if pqb2=='M':
                raise Exception('[QCML] Cannot apply gate %s to qubit %s: already measured!' % (self.__str__(),self.qubits[1]))
            op = GATES_DICT['CZ'](pqb1,pqb2)
            state.qapply_gate(mv,op)
        def __eq__(self,other):
            if isinstance(other, self.__class__):
                return self.__dict__ == other.__dict__
            return False
        def __str__(self):
            return 'E(%d,%s)' % (self.qubits[0],self.qubits[1])
        __repr__ = __str__

        def script(self):
            return 'E\t%d,%d' % (self.qubits[0],self.qubits[1])

    class Mop(object):			# measurement operator
        '''
        Measurement M(i,alpha) is orthogonal projection of qubit i on states
       	(|0>+e^(i*alpha)|1>)/sqrt(2) and (|0>+e^(0i*alpha)|1>)/sqrt(2).
	That is, apply [[1,0],[0,exp(i*alpha)]] first, then Hadamard, then measure
        in the computational basis.
        '''
        def __init__(self,i,alpha,s=0,t=0,opstr=''):
            self.opstr = opstr			# for error messages
            self.qubits = [int(i)]
            self.alpha = my_sympify(alpha,symtab={'alpha':sympy.Symbol('alpha',real=True)})
            self.sidx = s
            self.tidx = t

        def remap(self,old2new):		# return same operator, but acting on relabeled qubits
            def o2n(x):			# for mapping signals
                return 0 if x==0 else old2new(x)
            return self.__class__(old2new[self.qubits[0]],self.alpha,
                                  o2n(self.sidx),o2n(self.tidx))

        def qapply(self,state,mv):
            '''
            qubitmap = dict translating logical qubit to remaining physical qubit index
            signals = dict giving state of each of the measured qubits so far (the signals)
                      the dict keys are such that signals[0] = 0
            '''
            #print("    Applying %s" % self.__str__())
            angle = (-1)**state.signals(mv,self.sidx) * self.alpha + state.signals(mv,self.tidx)*sympy.pi
            qk = state.qubitmap[self.qubits[0]]
            if not type(qk)==int:
               if qk=='M':
                   raise Exception("[QSS]: cannot apply %s: qubit %d has already been measured!" % (self.__str__(),self.qubits[0]))
            hop = GATES_DICT['H'](qk)				# hadamard on qubit qk
            za = Zalpha(qk,angle)				# Zalpha on qubit qk
            # print("[Mop.qapply] applying %s * %s to state=%s" % (hop, za, state))
            # state.qapply_gate(mv, za)			# before measurement state		# DEBUG
            state.qapply_gate(mv, hop*za)			# before measurement state
            # state.qapply_gate(mv, H(qk)*Rz(qk,angle))		# before measurement state
            state.do_measure = self.qubits[0]

        def __str__(self):
            if self.sidx==0 and self.tidx==0:
                return 'M(%d,%s)' % (self.qubits[0],self.alpha)
            else:
                return 'M(%d,%s,%s,%s)' % (self.qubits[0],self.alpha,str(self.sidx),str(self.tidx))
        __repr__ = __str__

        def __eq__(self,other):
            if isinstance(other, self.__class__):
                return self.__dict__ == other.__dict__
            return False

        #def __hash__(self):				# need this for qapply to work in python3
        #    return str(self).__hash__()

        def script(self):
            if self.sidx==0 and self.tidx==0:
                return 'M\t%d,%s' % (self.qubits[0],self.alpha)
            else:
                return 'M\t%d,%s,%s,%s' % (self.qubits[0],self.alpha,str(self.sidx),str(self.tidx))

    def __str__(self):
        return '%s:%s:%s' % (repr(self.input),repr(self.output),str(self.ops))

    __repr__ = __str__

    #def add_to_lqbset(self,lqb):	# add to list of all logical qubits used in the program
    #    lqb = int(lqb)
    #    if not lqb in self.lqbset:
    #        self.lqbset.append(lqb)

    def parse_script(self,sstr):
        '''
        Parse multiline script
        '''
        linenum = 0
        # self.lqbset = []		# list of all logical qubits used in the program
        ops = []
        for k in sstr.split('\n'):
            linenum += 1
            k = k.strip()
            if not k:
                continue
            if k[0]==';':		# line is pure comment
                continue
            opstr = '[line %d] %s' % (linenum,k)
            opargs = {'opstr':opstr}
            if k=='': continue
            m = re.match('\s*(.*?)\s+(.*)',k)
            if not m:
                raise Exception('[QCML]: cannot parse line %s = "%s"' % (linenum,k))
            cmd = m.group(1)
            args = m.group(2)
            if ';' in args:
                (args,junk) = args.split(';')
            args = [x.strip() for x in args.split(',')]
            # print "--> %s, %s" % (cmd,args)
            try:
                if cmd=='input':
                    self.input = [int(x) for x in args]
                elif cmd=='output':
                    self.output = [int(x) for x in args]
                elif cmd=='M':
                    if len(args)==2 or len(args)==4: ops.append(self.Mop(*args, **opargs))
                    # else error
                elif cmd=='X':
                    if len(args)==2: ops.append(self.Xop(*args, **opargs))
                    # self.add_to_lqbset(args[0])
                    # else error
                elif cmd=='Z':
                    if len(args)==2: ops.append(self.Zop(*args, **opargs))
                    # self.add_to_lqbset(args[0])
                    # else error
                elif cmd=='E':
                    if len(args)==2: ops.append(self.Eop(*args, **opargs))
                    # self.add_to_lqbset(args[0])
                    # self.add_to_lqbset(args[1])
                    # else error
                else:
                    raise Exception('[QCML]: cannot parse line %s = "%s"' % (linenum,k))
            except Exception as err:
                raise Exception('[QCML]: cannot parse line %s = "%s"<p>Error = %s' % (linenum,k,err))
        # self.lqbset.sort()	# sort list of logical qubits
        self.ops = ops		# list of QCML operations 

    def __getitem__(self,k):
        return self.ops[k]

    def __eq__(self,other):
        '''
        Compute equality of two QCML programs
        '''
        return self.ops == other.ops

    def compute_nqubits(self):
        return len(self.lqbset)	# length of set of logical qubits

    nqubits = property(compute_nqubits,None,None,'Number of qubits used by QCML script')

    def check_script(self):
        pass

    def simulate(self,verbose=True):
        '''
        Generate arbitrary quantum state for input qubits, and |+> for each of the other qubits.
        '''
        self.state = self.initial_state()
        # self.state = self.initial_state(onlyinputs=False)
        self.state.verbose = verbose

        self.msg = []
        def log(s):
            if verbose: print(s)
            self.msg.append(s)
            
        log("[0] Initial state = %s" % self.state)
        log("    --> map of logical qubits to physical qubits is %s" % (self.state.qubitmap))
        self.nop = 0
        for op in self.ops:
            self.nop += 1
            log("[%d] applying %s" % (self.nop,op))
            self.state.msg = []

            # if op acts on logical qubits which are not yet defined, then define them and extend the physical qubit space too
            for lqb in op.qubits:
                if lqb in self.state.lqbset: continue		# already defined in lqbset of stateset
                # self.lqbset.append(lqb)
                self.state.extend(lqb)	# extend state set
            
            try:
                self.state.qapply(op)
            except Exception as err:
                log('Error %s while simulating operation %s' % (err,op))
                log('Error occurred for input %s' % (op.opstr))
                log("Traceback: %s" % traceback.format_exc())
                return self.state

            if isinstance(op,self.Cop):
                self.state.merge()	# try to merge

            self.msg += self.state.msg
            log("[%d] State after '%s':\n%s" % (self.nop,op,self.state))
            # log("    ==> input qubits: %s" % self.input)

        self.state.merge()	# try to merge

        self.nop += 1
        log("[%d] Done: relabling qubits to correspond with outputs %s (logical2physcal=%s)" % (self.nop,
                                                                                                self.output,
                                                                                                self.state.qubitmap))
        try:
            self.state.relabel(self.output)
        except Exception as err:
            log('Error - failed to remap qubits to correspond to outputs: are the outputs really qubits %s?' % self.output)
            # log("err=%s, traceback=%s" % (str(err), traceback.format_exc())) # DEBUG
            log("err=%s" % (str(err)))
        log("    ==> Final state:\n%s" % (self.state))
        return self.state
    
    def initial_state(self,onlyinputs=True):
        # generate general input state
        instate = 0
        def binstr(nbits,x):
            return bin(x)[2:].rjust(nbits, '0')
        nqin = len(self.input)
        for k in range(2**nqin):
            kbin = binstr(nqin,k)
            instate += Qubit(kbin) * sympy.Symbol('c%s' % kbin,real=True)

        self.instate = instate		# save for later use, eg in comparing with a unitary gate
        #print "instate = ",instate
        
        if onlyinputs:		# only give initial state for input logical qubits
            return QuantumStateSet(instate,nqin,self.input)

        # generate |+> for other qubits
        pstate = my_sympify('|0>+|1>',do_ket=True,do_qubit=True)
        
        otherstate = 1
        for k in range(self.nqubits-nqin):
            otherstate = my_tensor(pstate,otherstate)
        #print "otherstate = ",otherstate

        # re-order the lqbset to put all the inputs last in the list (ie LHS in string labels)
        new_lqbset = []
        for k in self.lqbset:
            if not k in self.input: new_lqbset.append(k)
        self.lqbset = new_lqbset + self.input

        # current order corresponds to in \otimes other (ie input qubit labels on LHS)
        initialstate = my_tensor(instate,otherstate)

        # eg lqubits = [2,3,1] --> pqubits = [0,1,2]
        # let's relabel the pqubits so that they are matched in order with the lqubits.
        # we want lqubit 1 -> pqubit 0, lqubit 2 -> pqubit 1, etc.

        logical2physical = dict(list(zip(self.lqbset,list(range(len(self.lqbset))))))
        physical2logical = dict(list(zip(list(range(len(self.lqbset))),self.lqbset)))

        # to fix this, we want pqubit[lqubit[x]] to become pqubit[x-min]

        lqbsorted = self.lqbset[::]
        lqbsorted.sort()
        def remap(pqb):		# pqb is a string
            pqb = list(pqb)[::-1]	# now it is a list
            newpqb = [ pqb[logical2physical[lqbsorted[x]]] for x in range(self.nqubits) ]
            # print "newpqb = ",newpqb
            return ''.join([str(x) for x in newpqb[::-1]])
        
        def relabel(state,remap):
            state = state.expand()
            def map_one(state):
                def map_qubit(q):
                    return Qubit(remap(q.label))
                if isinstance(state,Qubit):
                    return map_qubit(q)
                elif isinstance(state,sympy.Mul):
                    xa = list(x.args)
                    xa = xa[:-1] + [map_qubit(xa[-1])]
                    return sympy.Mul(*xa)
                raise Exception('[QCML] failed in relabling qubit state! state=%s' % state)
            if isinstance(state,sympy.Mul):
                return map_one(state)
            if isinstance(state,sympy.Add):
                return sympy.Add(*[map_one(x) for x in state.args])

        nistate = relabel(initialstate,remap)
        self.lqbset = lqbsorted

        return QuantumStateSet(nistate,self.nqubits,self.lqbset)

    def remap(self,lqmap):
        '''
        Return QCML resulting from mapping logical qubit labels by lqmap.
        lqmap is list.  The map takes self.lqbset[x] -> lqmap[x] for x in
        range(length(self.lqbset)).  
        '''
        old2new = dict(list(zip(self.lqbset,lqmap)))	# map for logical qubits
        old2new.update(dict(list(zip(['s%d' % x for x in self.lqbset],['s%d' % x for x in lqmap]))))	# for signals

        # print "old2new = ",old2new

        newinput = [ old2new[x] for x in self.input ]
        newoutput = [ old2new[x] for x in self.output ]
        newops = [ op.remap(old2new) for op in self.ops ]

        return self.__class__({'input':newinput,
                               'output':newoutput,
                               'ops':newops})

    def qc2qcml(self,circ):
        '''
        Compile a quantum circuit into a QCML program.
        Only works with circuits having just H, Rz, and CNOT gates.
        '''
    
        output = list(range(1,circ.nqubits+1))	# we'll remap these as we go along
        qubits = ','.join([str(x) for x in output])
        nq = [circ.nqubits+1]	# next new logical qubit number
    
        def qH(g):
            # print "in qH: g=%s" % g
            k = g.label[0]				# which qubit the gate acts upon
            Hprog = QCML('''input 1\n output 2\n E 1,2\n M 1,0 \n X 2,s1''')
            qmap = [output[k],nq[0]]
            print("    --> map %s" % qmap)
            m = Hprog.remap(qmap)	# one qubit cluster
            output[k] = nq[0]			# follow the output along as it changes logical qubit
            nq[0] += 1
            return m
    
        def qRz(g):
            k = g.label[0][0]
            alpha = g.label[2]
            Rzprog = QCML('''input 1 \n output 3 \n E 1,2 \n M 1,-%s \n X 2,s1 \n E 2,3 \n M 2,0 \n X 3,s2''' % alpha)
            qmap = [output[k],nq[0],nq[0]+1]
            print("    --> map %s" % qmap)
            m = Rzprog.remap(qmap)	# three qubit cluster
            output[k] = nq[0]+1			# follow the output along as it changes logical qubit
            nq[0] += 2
            return m
    
        def qCNOT(g):
            (j,k) = g.label				# ctrl, target
            CNprog = QCML('''input 1,2 \n output 1,4 \n E 2,3 \n M 2,0 \n E 1,3 \n E 3,4 \n M 3,0 \n Z 1,s2 \n Z 4,s2 \n X 4,s3''')
            qmap = [output[j],output[k],nq[0],nq[0]+1]
            print("    --> map %s" % qmap)
            m = CNprog.remap(qmap)	# four qubit cluster
            output[k] = nq[0]+1			# follow the output along as it changes logical qubit
            nq[0] += 2
            return m
    
        gate2qcml = {'H': qH,
                     'Rz' : qRz,
                     'CNOT' : qCNOT,
                     }
    
        m = QCML('input %s\n output %s' % (qubits,qubits))
        nop = 0
        for g in circ:
            nop += 1
            print('[%d] adding gate %s' % (nop,g))
            m = m + gate2qcml[g.gate_name](g)
            print('    --> QCML = %s' % m)
                     
        # return m
        self.circuit = circ
        self.input = m.input
        self.output = m.output
        self.ops = m.ops

def test_qcml1():	# hadamard - works
    x = QCML('''
              input 1
    	      output 2
              E 1,2
              M 1,0
              X 2,s1
              ''')
    return x

def test_qcml2():	# Zalpha = H * J(alpha) - works
    x = QCML('''input 1
    	        output 3
                E 1,2
                M 1,-alpha
                X 2,s1
                E 2,3
                M 2,0
                X 3,s2
                ''')
    return x

def test_qcml3():	# J(alpha) - works
    x = QCML('''
              input 1
              output 2
              E 1,2
              M 1,-alpha
              X 2,s1
              ''')
    return x
    # compare with
    # 
    # In [243]: c = qp.QuantumCircuit('[Rz(0,-sympy.Symbol("alpha")),H(0)]',1)
    # 
    # In [244]: c.output(instate=x.instate)
    # Out[244]: 2**(1/2)*c0*exp(I*alpha/2)*|0>/2 + 2**(1/2)*c0*exp(I*alpha/2)*|1>/2 + 2**(1/2)*c1*exp(-I*alpha/2)*|0>/2 - 2**(1/2)*c1*exp(-I*alpha/2)*|1>/2
    # 
    # In [245]: s = x.simulate()
    # Out[245]: 
    # [x0]: 2**(1/2)*c0*exp(I*alpha/2)*|0>/2 + 2**(1/2)*c0*exp(I*alpha/2)*|1>/2 + 2**(1/2)*c1*exp(-I*alpha/2)*|0>/2 - 2**(1/2)*c1*exp(-I*alpha/2)*|1>/2
    # [x1]: 2**(1/2)*c0*exp(I*alpha/2)*|0>/2 + 2**(1/2)*c0*exp(I*alpha/2)*|1>/2 + 2**(1/2)*c1*exp(-I*alpha/2)*|0>/2 - 2**(1/2)*c1*exp(-I*alpha/2)*|1>/2
    #
    # In [249]: c.matrix()
    # Out[249]: 
    # [2**(1/2)*exp(I*alpha/2)/2,  2**(1/2)*exp(-I*alpha/2)/2]
    # [2**(1/2)*exp(I*alpha/2)/2, -2**(1/2)*exp(-I*alpha/2)/2]

    # In [251]: x = qp.test_qcml3()
    # 
    # In [252]: s = x.simulate()
    # --> map of logical qubits to physical qubits is {1: 0, 2: 1}
    # [0] Initial state =     [xx]: c0*|00> + c0*|10> + c1*|01> + c1*|11>
    # 
    # [1] applying E(1,2)
    # --> [xx] Applying gate CPHASE(0,1)
    # [1] State after 'E(1,2)':
    # [xx]: c0*|00> + c0*|10> + c1*|01> - c1*|11>
    # 
    # [2] applying M(1,-alpha)
    # --> [xx] Applying gate H(0)*Zalpha(0,-alpha)
    # --> pre-measurement state = 
    # [xx]: 2**(1/2)*c0*|00>/2 + 2**(1/2)*c0*|01>/2 + 2**(1/2)*c0*|10>/2 + 2**(1/2)*c0*|11>/2 + 2**(1/2)*c1*exp(I*alpha)*|00>/2 - 2**(1/2)*c1*exp(I*alpha)*|01>/2 - 2**(1/2)*c1*exp(I*alpha)*|10>/2 + 2**(1/2)*c1*exp(I*alpha)*|11>/2
    # 
    # --> projecting physical qubit 0 (logical qubit 1)
    # --> new logical->physical qubit map:  {1: 'M', 2: 0}
    # [2] State after 'M(1,-alpha)':
    # [x0]: 2**(1/2)*c0*|0>/2 + 2**(1/2)*c0*|1>/2 + 2**(1/2)*c1*exp(I*alpha)*|0>/2 - 2**(1/2)*c1*exp(I*alpha)*|1>/2
    # [x1]: 2**(1/2)*c0*|0>/2 + 2**(1/2)*c0*|1>/2 - 2**(1/2)*c1*exp(I*alpha)*|0>/2 + 2**(1/2)*c1*exp(I*alpha)*|1>/2
    # 
    # [3] applying X(2,s1)
    # --> [x1] Applying gate X(0)
    # [3] State after 'X(2,s1)':
    # [x0]: 2**(1/2)*c0*|0>/2 + 2**(1/2)*c0*|1>/2 + 2**(1/2)*c1*exp(I*alpha)*|0>/2 - 2**(1/2)*c1*exp(I*alpha)*|1>/2
    # [x1]: 2**(1/2)*c0*|0>/2 + 2**(1/2)*c0*|1>/2 + 2**(1/2)*c1*exp(I*alpha)*|0>/2 - 2**(1/2)*c1*exp(I*alpha)*|1>/2
    # 
    # 
    # In [253]: c = qp.QuantumCircuit('[Zalpha(0,-sympy.Symbol("alpha")),H(0)]',1)
    # 
    # In [254]: c.output(instate=x.instate)
    # Out[254]: 2**(1/2)*c0*|0>/2 + 2**(1/2)*c0*|1>/2 + 2**(1/2)*c1*exp(I*alpha)*|0>/2 - 2**(1/2)*c1*exp(I*alpha)*|1>/2
    # 
    # In [255]: c.matrix()
    # Out[255]: 
    # [2**(1/2)/2,  2**(1/2)*exp(I*alpha)/2]
    # [2**(1/2)/2, -2**(1/2)*exp(I*alpha)/2]

def test_qcml4():	# CNOT - works
    x = QCML('''input 1,2
                output 1,4
                E 3,4
                E 2,3
                E 1,3
                M 2,0
                M 3,0
                Z 1,s2
                Z 4,s2
                X 4,s3
                ''')
    return x

def test_qcml5():	# R_x(alpha) rotation
    x = QCML('''input 1
                output 3
                E 1,2
                E 2,3
                M 1,0
                M 2,-alpha,s1,0
                Z 3,s1
                X 3,s2
                ''')
    return x

def test_qcml6():	# alt R_x(alpha) rotation using Rx(alpha) = J(alpha)*H - works
    x = QCML('''input 1
                output 3
                E 1,2
                M 1,0
                X 2,s1
                E 2,3
                M 2,-alpha
                X 3,s2
                ''')
    return x

def test_qcml7():	# alt R_x(alpha)  - works
    x = QCML('''input 1
                output 3
                E 1,2
                M 1,0
                E 2,3
;                X 2,s1
;                M 2,-alpha,0,0
                M 2,-alpha,s1,0
                Z 3,s1
                X 3,s2
                ''')
    s = x.simulate(verbose=False)
    s.subs('alpha','pi/4').subs('c0',1).subs('c1',0)
    s.merge()
    return x, s

def test_qcml8():	# S = H*J(pi/2)
    x = QCML('''input 1
    	        output 3
                E 1,2
                M 1,-pi/2
                X 2,s1
                E 2,3
                M 2,0
                X 3,s2
                ''')
    s = x.simulate(verbose=False)
    s.merge()
    return x, s

def test_qcml8():	# P(alpha) using addition
    x = test_qcml1()	# H
    y = test_qcml3()	# J
    z = y + x.remap([2,3])	# Zalpha
    return z

def test_qcml9():
    x = QCML(QuantumCircuit('[H(0),CNOT(0,1)]',2))
    return x

def test_qcml10():
    x = QCML(QuantumCircuit('[H(1),CNOT(0,1),H(1)]',2))
    return x

def test_qcml_qft():
    c = QuantumCircuit('[H(1),CSGate(0,1),H(0)]',2)	# QFT
    cs = QuantumCircuit('[exp(I*pi/8)*Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4)]',2)    # controlled-S using CNOT and Rz
    c2 = QuantumCircuit('[H(1),Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4),H(0)]',2)	# QFT
    c3 = QuantumCircuit('[H(1),Rz(1,pi/4),H(0),CZ(1,0),Rx(0,-pi/4),H(0),CZ(1,0),H(0),Rz(0,pi/4),H(0)]',2)	# QFT?
    return c2

def test_qcml11():
    x= QCML(QuantumCircuit('[H(1),Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4),H(0)]',2))
    return x

def test_qcml12():
    x= QCML(QuantumCircuit('[Rz(0,pi/4)]',1))
    return x

def test_qcml13(): # controlled-S
    x= QCML(QuantumCircuit('[Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4)]',2))
    return x

def test_qcml14(): # QFT
    x = QCML('''
input	1,2
output	5,14
E	2,3
M	2,0
X	3,s2
E	3,4
M	3,-pi/4
X	4,s3
E	4,5
M	4,0
X	5,s4
E	1,6
M	1,0
E	5,6
E	6,7
M	6,0
Z	5,s1
Z	7,s1
X	7,s6
E	7,8		; ok
M	7,pi/4
X	8,s7
E	8,9
M	8,0
X	9,s8
E	9,10
M	9,0
E	5,10
E	10,11
M	10,0
Z	5,s9
Z	11,s9
X	11,s10
E	11,12
M	11,-pi/4
X	12,s11
E	12,13
M	12,0
X	13,s12
E	13,14
M	13,0
X	14,s13
    ''')
    return x

#-----------------------------------------------------------------------------
# check qcml program

def check_qcml_unitary(expect, ans, options=None, debug=False):

    if ';' in expect:
        (nqubits,expect) = expect.split(';')
        nqubits = int(nqubits)

    ec = QuantumCircuit(expect,nqubits)

    try:
        if ('[' in ans) or ('(' in ans):
            ans = ans.replace('[', ' ').replace(']', ' ').replace('(', ' ').replace(')', ' ')
        ans = ans.replace('\u2212', '-')
        x = QCML(ans)
    except Exception as err:
        if debug:
            raise
        return {'ok':False,'msg':'<p>Error %s in parsing your input' % err}

    # exclude standard circuits
    toexclude = [ '''input 1\n output 2\n E 1,2\n M 1,0 \n X 2,s1''' ,
                  '''input 1 \n output 2 \n E 1,2 \n M 1,-alpha \n X 2,s1''',
                  '''input 1 \n output 3 \n E 1,2 \n M 1,-alpha \n X 2,s1 \n E 2,3 \n M 2,0 \n X 3,s2''',
                  '''input 1,2 \n output 1,4 \n E 3,4 \n E 2,3 \n E 1,3 \n M 2,0 \n M 3,0 \n Z 1,s2 \n Z 4,s2 \n X 4,s3''',
                  ]
    for te in toexclude:
        if QCML(te)==x:
            return {'ok': False, 'msg':'<p>Sorry, please do not enter a QCML program given as a question in a previous problem'}

    try:
        # s = x.simulate(verbose=True)	# DEBUG
        s = x.simulate(verbose=False)	# DEBUG
    except Exception as err:
        if debug:
            raise
        return {'ok':False,'msg':'<p>Error %s in executing your QCML program' % err}
        
    msg = '<p> Simulation result: <blockquote><font color=green><pre>%s</pre></font></blockquote>' % '<br/>'.join(x.msg)
    ret = s.is_strongly_deterministic()
    if not ret['ok']:
        return {'ok':False,'msg':msg + '<p>The output of your circuit is not independent of the measurement results!'}

    try:
        estate = ec.output(instate=x.instate)
    except Exception as err:
        return {'ok':False,'msg':msg +'<p>Error: your circuit may be specifying the wrong number of inputs (%s)' % err}

    astate = s.stateset[list(s.stateset.keys())[0]]

    print("estate = ",estate)
    print("astate = ",astate)

    zq = Qubit('0'*s.npqubits)
    print("zq = ",zq)
    is_ok = states_equal_up_to_phase(estate,astate,zq=zq)

    # return {'ok':is_ok,'msg':msg,'estate':estate,'astate':astate,'zq':zq}
    return {'ok':is_ok,'msg':msg}


def test_qu0():
    expect = '2;[H(0),CNOT(0,1)]'
    ans = '''
input	1,2
output	3,5
E	1,3
M	1,0
X	3,s1
E	2,4
M	2,0
E	3,4
E	4,5
M	4,0
Z	3,s2
Z	5,s2
X	5,s4
'''
    ret = check_qcml_unitary(expect,ans)
    # assert(str(ret['estate'])=='2**(1/2)*c00*|00>/2 + 2**(1/2)*c00*|11>/2 + 2**(1/2)*c01*|00>/2 - 2**(1/2)*c01*|11>/2 + 2**(1/2)*c10*|01>/2 + 2**(1/2)*c10*|10>/2 - 2**(1/2)*c11*|01>/2 + 2**(1/2)*c11*|10>/2')
    # assert(str(ret['zq'])=='|00>')
    print(ret)
    assert(ret['ok'])
    return ret
    
def test_qu2(): # controlled-S
    expect = '2;[Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4)]'
    ans = '''
input	1,2
output	12,4
E	2,3
M	2,-pi/4
X	3,s2
E	3,4
M	3,0
X	4,s3
E	1,5
M	1,0
E	4,5
E	5,6
M	5,0
Z	4,s1
Z	6,s1
X	6,s5
E	6,7
M	6,pi/4
X	7,s6
E	7,8
M	7,0
X	8,s7
E	8,9
M	8,0
E	4,9
E	9,10
M	9,0
Z	4,s8
Z	10,s8
X	10,s9
E	10,11
M	10,-pi/4
X	11,s10
E	11,12
M	11,0
X	12,s11
'''
    ret = check_qcml_unitary(expect,ans)
    assert(ret['ok']==True)
    assert('Extended state to include logical qubit 3 (= physical qubit 2)' in ret['msg'])
    return ret
    
def test_qu1():	# QFT
    expect = '2;[H(1),Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4),H(0)]'
    ans = '''
input	1,2
output	5,14
E	2,3
M	2,0
X	3,s2
E	3,4
M	3,-pi/4
X	4,s3
E	4,5
M	4,0
X	5,s4
E	1,6
M	1,0
E	5,6
E	6,7
M	6,0
Z	5,s1
Z	7,s1
X	7,s6
E	7,8		; ok
M	7,pi/4
X	8,s7
E	8,9
M	8,0
X	9,s8
E	9,10
M	9,0
E	5,10
E	10,11
M	10,0
Z	5,s9
Z	11,s9
X	11,s10
E	11,12
M	11,-pi/4
X	12,s11
E	12,13
M	12,0
X	13,s12
E	13,14
M	13,0
X	14,s13
'''
    ret = check_qcml_unitary(expect,ans)
    return ret
        
def test_qu3():	# QFT - bookatz
    expect = '2;[H(1),Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4),H(0)]'
    ans = '''
input 1,2
output 12,10
E 3,4
E 2,3
E 1,3
M 2,0
M 3,0
Z 1,s2
Z 4,s2
X 4,s3
E 4,5
M 4,pi/4
X 5,s4
E 5,6
M 5,0
X 6,s5
E 7,8
E 6,7
E 1,7
M 2,0
M 7,0
Z 1,s6
Z 8,s6
X 8,s7
E 8,9
M 8,-pi/4
X 9,s8
E 9,10
M 9,0
X 10,s9
E 1,11
M 1,-pi/4
X 11,s1
E 11,12
M 11,0
X 12,s11
'''
    ret = check_qcml_unitary(expect,ans)
    return ret

def test_qu4():	# bad code test
    expect = '2;[H(1),Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4),H(0)]'
    ans = '''
input 1,2
output 12,10
E 3,4
E 2,3
E 1,3
M 2,0
M 3,0
Z 1,s2
Z 4,s2
X 4,s3

E 4,5
'''
    ret = check_qcml_unitary(expect,ans)
    # ret = QCML(ans)
    return ret


def test_qu6():	# bad code test
    expect = '2;[H(1),Rz(1,pi/4),CNOT(1,0),Rz(0,-pi/4),CNOT(1,0),Rz(0,pi/4),H(0)]'
    ans = '''
input    1
output   3
E        1, 2
M        1, -pi/2
X        2, s1
E        2, 3
M        1, 0
X        3, s2
'''
    ret = check_qcml_unitary(expect,ans)
    #ret = QCML(ans)
    assert(not ret['ok'])
    return ret

def test_qu7():	# S
    expect = "1;[S(0)]"
    ans = ('''input 1
    	        output 3
                E 1,2
                M 1,-pi/2
                X 2,s1
                E 2,3
                M 2,0
                X 3,s2
                ''')
    ret = check_qcml_unitary(expect, ans)
    assert(ret['ok'])
    return ret

def test_qu8():
    expect="1;[S(0)]"
    ans = """input 1
	output 3
	E [1,2]
	M [1,-pi/2]
	X [2,s1] 
	E [2,3]
	M [2,0]
	X [3,s2]"""
    ret = check_qcml_unitary(expect, ans)
    assert(ret['ok'])
    return ret

def test_qu9():
    ans = """input 1 
output 3 
E(1,2)
M(1,\u2212pi/2) 
X(2,s1)
E(2,3) 
M(2,0)
X(3,s2)"""
    expect="1;[S(0)]" 
    ret = check_qcml_unitary(expect, ans)
    print(ret)
    assert(ret['ok'])
    return ret

#-----------------------------------------------------------------------------
# qcml rewrite rule checking

def check_qcml_rewrite_rule(expect, ans, options=None):
    '''
    options may have altanswer
    '''

    if '=' in ans:
        return {'ok': False, 'msg': "Your answer should not have an equal sign ('=') in it."}

    odict = parse_options(options, allow_multiple=True)
    if 'altanswer' in odict:
        eset = [expect]
        eset += odict['altanswer']
        for eone in eset:
            ret = check_qcml_rewrite_rule(eone, ans)
            if ret['ok']: return ret
        return ret
        
    sf = 'MEXZ'
    symtab = dict([ (x,sympy.Function(x)) for x in sf ])
    try:
        exp = my_sympify(str(expect),symtab=symtab)
    except Exception as err:
        raise Exception("Error %s in parsing our expression %s" % (err,expect))
    try:
        ans = str(ans)
    except Exception as err:
        pass
    ans_parsed = my_sympify(ans,symtab=symtab)

    # return {'ok': exp==ans_parsed, 'msg': "ans='%s', ans_parsed=%s" % (ans, ans_parsed)}
    return {'ok': exp==ans_parsed, 'msg': ''}

def test_check_qcml_rewrite_rule1():
    expect="[ E(i,j), Z(j,s), X(i,s) ]" 
    options="altanswer=[ E(i,j), X(i,s), Z(j,s) ]" 
    ans = "[E(i,j),X(i,s), Z(j,s) ]" 
    ret = check_qcml_rewrite_rule(expect, ans, options)
    assert(ret['ok'])

def test_check_qcml_rewrite_rule2():
    expect="[ E(i,j), Z(j,s) ]" 
    ans = "[E(i,j),Z(j,s)]" 
    ret = check_qcml_rewrite_rule(expect, ans)
    assert(ret['ok'])
    return ret

def test_check_qcml_rewrite_rule3():
    expect="[ E(i,j), Z(j,s) ]" 
    ans = "[E(i,j),Z(j,s)]" 
    ret = check_qcml_rewrite_rule(expect, ans)
    assert(ret['ok'])
    return ret

#-----------------------------------------------------------------------------

class BinaryLog(sympy.Function):
    @classmethod
    def eval(cls, x):
        if x.is_Number:
            return sympy.log(x, 2)

    def _eval_is_real(self):
        return self.args[0].is_real

class BinaryEntropy(sympy.Function):
    @classmethod
    def eval(cls, x):
        if x.is_Number:
            if x is sympy.S.Zero:
                return 0
            if x is sympy.S.One:
                return 0
            if x<0:
                return sympy.S.Infinity
            if x>1:
                return sympy.S.Infinity
            return -x * sympy.log(x,2) - (1-x)*sympy.log(1-x, 2)

    def _eval_is_real(self):
        return self.args[0].is_real

def check_vn_entropy(expect, ans, options=None):
    '''
    options may have altanswer
    '''

    odict = parse_options(options, allow_multiple=True)
    if 'altanswer' in odict:
        eset = [expect]
        eset += odict['altanswer']
        for eone in eset:
            ret = check_vn_entropy(eone, ans)
            if ret['ok']: return ret
        return ret

    sf = 'H'
    # symtab = dict([ (x,sympy.Function(x)) for x in sf ])
    symtab = {'H': BinaryEntropy,
              'log': BinaryLog,
              }
    try:
        ans = str(ans)
    except Exception as err:
        pass

    try:
        exp = sympy.sympify(str(expect), locals=symtab)
    except Exception as err:
        raise Exception("Error %s in parsing our expression %s" % (err,expect))
    try:
        ans_formula = sympy.sympify(ans, locals=symtab)
    except Exception as err:
        raise Exception("Error %s in parsing your expression %s" % (err,ans))

    print("expect=%s" % str(expect))
    print("expected=%s" % exp)
    print("submitted ans=%s" % ans)

    sfc = SympyFormulaChecker()
    isok = sfc.sympy_is_formula_equal(exp, ans_formula)

    msg = ''
    # msg = 'ans=%s, ans_formula=%s, expect=%s, exp=%s' % (ans, ans_formula, expect, exp)

    return {'ok': isok, 'msg': msg}

def test_check_vn_entropy1():
    expect="H((1+r)/2)"
    ans = "H((2+r-1)/2)"
    ret = check_vn_entropy(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_vn_entropy1a():
    expect="H((1+r)/2)"
    ans = "H((2+r-1)/2)"
    ret = check_vn_entropy(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_vn_entropy2():
    expect="H(x)"
    ans = "-x*log(x)-(1-x)*log(1-x)"
    ret = check_vn_entropy(expect, ans)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_vn_entropy3():
    expect="H(x)"
    options="altanswer=H((1+sqrt(rx^2+ry^2+rz^2))/2)"
    ans = "-x*log(x)-(1-x)*log(1-x)"
    ret = check_vn_entropy(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_vn_entropy4():
    expect="H(x)"
    options="altanswer=H((1+sqrt(rx^2+ry^2+rz^2))/2)"
    ans = "H((1+sqrt(rx^2+ry^2+rz^2))/2.0)"
    ret = check_vn_entropy(expect, ans, options)
    print(ret['msg'])
    assert(ret['ok'])

def test_check_vn_entropy5():
    expect="H((1+r)/2)"
    options="altanswer=H((1+sqrt(rx^2+ry^2+rz^2))/2)"
    ans = "H((1+r)/2.0000001)"
    # ans = "H((1+sqrt(rx^2+ry^2+rz^2))/2.0001)"
    ret = check_vn_entropy(expect, ans, options)
    print(ret['msg'])
    sys.stdout.flush()
    assert(ret['ok'])

#-----------------------------------------------------------------------------

def check_tetra_holevo(expect, ans, options=None):
    # POVM (actual answer)
    p = {}
    p[0] = my_sympify('1.0*|1>',do_ket=True)
    p[1] = my_sympify('(sqrt(2)               *|0>+|1>)/sqrt(3)',do_ket=True)
    p[2] = my_sympify('(sqrt(2)*exp(-2*i*pi/3)*|0>+|1>)/sqrt(3)',do_ket=True)
    p[3] = my_sympify('(sqrt(2)*exp(-4*i*pi/3)*|0>+|1>)/sqrt(3)',do_ket=True)

    # parse the answers given
    def getans(k):
        try:
            x = my_sympify(str(ans[k]), do_ket=True)
        except Exception as err:
            msg = '<p>Error %s<p>Cannot parse your answer "%s"' % (err,ans[k])
            raise Exception(msg)
        return x

    for k in range(0,3):
        if not ans[k].strip():
            return {'ok':False,'msg':'Cannot check this response until all parts are entered'}
        try:
            p[k+1] = getans(k)
        except Exception as err:
            is_ok = False
            return {'overall_message': str(err), 'input_list': [{'ok': is_ok} for k in range(len(ans))]}

    msg = '<html>'
    msg += '<p>Your states parsed as:\n'
    for k in range(1,4):
        msg += '<br/> phi%d = %s' % (k+1,to_latex(p[k]))
    msg += '</p>'

    # signal states
    s = {}
    s[0] = my_sympify('1.0 * |0>',do_ket=True)
    s[1] = my_sympify('(sqrt(2)*              |1>-|0>)/sqrt(3)',do_ket=True)
    s[2] = my_sympify('(sqrt(2)*exp(2*i*pi/3)*|1>-|0>)/sqrt(3)',do_ket=True)
    s[3] = my_sympify('(sqrt(2)*exp(4*i*pi/3)*|1>-|0>)/sqrt(3)',do_ket=True)

    # see if POVM is valid: should sum to identity (when divided by 2)
    try:
        psum = sympy.Add( * [ (qapply(x*Dagger(x))/2).evalf(chop=True) for x in list(p.values()) ] )
        zket = my_sympify('1.0*|0>',do_ket=True)
        oket = my_sympify('1.0*|1>',do_ket=True)
        psumdiff = (psum - qapply(zket*Dagger(zket)+oket*Dagger(oket))).evalf(chop=True)
        psumdiff = my_chop(psumdiff,thresh=1e-7)
    except Exception as err:
        msg += '<p>Error %s in checking if your states give a valid POVM</p>' % err
        is_ok = False
        return {'overall_message': msg, 'input_list': [{'ok': is_ok} for k in range(len(ans))]}
        # else: return {'ok':False,'msg':''}

    qbasis = [my_sympify(x ,do_ket=True) for x in ["1.0 * |0>", "1.0 * |1>"]]
    def matelem(j,k):
        return sympy.Add( *[ qapply(Dagger(qbasis[j])*x * Dagger(x) * qbasis[k]) for x in list(p.values()) ] ) / 2

    if not psumdiff==0:
        if 1:
            pmatrix = [ matelem(j,k) for (j,k) in [(0,0), (0,1), (1,0), (1,1)] ]
            print("not valid POVM? pmatrix=%s" % pmatrix)
            if (Matrix(pmatrix)-Matrix([1,0,0,1])).norm() < 0.001:
                psumdiff = 0

    if not psumdiff==0:
        msg += '<p>Error: your states are not a valid POVM</p><p>Their products sum to give %s</p>' % to_latex(psum)
        msg += "</html>"
        is_ok = False

        return {'overall_message': msg, 'input_list': [{'ok': is_ok} for k in range(len(ans))]}
        # else: return {'ok':False,'msg':''}

    # compute joint PDF: x = signal sent, y = measurement result
    # also compute marginals
    xypdf = {}
    xpdf = dict([(x,0) for x in range(4)])
    ypdf = dict([(x,0) for x in range(4)])

    try:
        for x in range(4):
            ygx_pdf = {}
            ysum = 0
            for y in range(4):
                mp = qapply(Dagger(p[y])*s[x])
                ygx_pdf[y] = (mp * sympy.conjugate(mp)/2).evalf(chop=True)/4	# div by 4 for X pdf
                ypdf[y] += ygx_pdf[y]
                ysum += ygx_pdf[y]
            xypdf[x] = ygx_pdf
            xpdf[x] = ysum

    except Exception as err:
        msg += '<p>Error %s in computing the joint PDF</p>' % err
        msg += "</html>"
        is_ok = False
        return {'overall_message': msg, 'input_list': [{'ok': is_ok} for k in range(len(ans))]}

    msg += '<p>Joint PDF: p(x,y):<ul>\n'
    for x in range(4):
        for y in range(4):
            msg += '<li>p(x=%d,y=%d) = %s</li>\n' % (x,y,xypdf[x][y])
    msg += '</ul>\n</p>\n'

    # compute entropies
    def hshan(pdf):
        return sum( [ (0 if x==0 else (-x*sympy.log(x,2)).evalf()) for x in list(pdf.values()) ] )

    hx = hshan(xpdf)
    hy = hshan(ypdf)
    hxy = sum( [ hshan(xypdf[x]) for x in xypdf ] )

    try:
        msg += "<p>Joint and marginal entropies:</p>\n"
        msg += "<p>H(X) = %f</p>\n" % hx
        msg += "<p>H(Y) = %f</p>\n" % hy
        msg += "<p>H(X,Y) = %f</p>\n" % hxy
    except Exception as err:
        print("oops, failed with error %s" % str(err))
        print("hx=%s" % hx)
        print("hy=%s" % hy)
        print("hyx=%s" % hxy)
        print("msg=%s" % msg)
        raise

    # compute mutual information

    Ixy = hx + hy - hxy
    msg += "<p>Mutual information: I(X;Y) = H(X)+H(Y)-H(X,Y) = %f</p>\n" % Ixy

    # see if reaches bound
    is_ok = abs(Ixy-sympy.log(4.0/3,2).evalf())<0.001

    # return
    msg += "</html>"
    return {'overall_message': msg, 'input_list': [{'ok': is_ok} for k in range(len(ans))]}

def test_check_tetra_holevo1():
    expect=""
    ans = "(sqrt(2)*exp(-  i*pi/3)*|0>+|1>)/sqrt(3)","(sqrt(2)*exp(-  i*pi  )*|0>+|1>)/sqrt(3)","(sqrt(2)*exp(-5*i*pi/3)*|0>+|1>)/sqrt(3)"
    ret = check_tetra_holevo(expect, ans)
    msg = ret['overall_message']
    print(msg)
    xml = etree.fromstring(msg)
    assert(not ret['input_list'][0]['ok'])
    return ret

def test_check_tetra_holevo2():
    expect=""
    ans ="(sqrt(2)*|0>+|1>)/sqrt(3)","(sqrt(2)*exp(-2*i*pi/3)*|0>+|1>)/sqrt(3)","(sqrt(2)*exp(-4*i*pi/3)*|0>+|1>)/sqrt(3)"
    ret = check_tetra_holevo(expect, ans)
    msg = ret['overall_message']
    print(msg)
    xml = etree.fromstring(msg)
    assert(ret['input_list'][0]['ok'])
    return ret

def test_check_tetra_holevo3():
    expect=""
    ans ="|0>","(|0>+|1>)/sqrt(2)","(|0>-|1>)/sqrt(2)"
    ret = check_tetra_holevo(expect, ans)
    msg = ret['overall_message']
    print(msg)
    xml = etree.fromstring(msg)
    assert(not ret['input_list'][0]['ok'])
    return ret

#-----------------------------------------------------------------------------

def define_qpython4_globals(env):
    check_functions = [
        check_qcircuit_output,
        check_qcircuit_compare,
        check_qcircuit_compare_output,
        check_ptrace,
        check_ptrace_2qubit,
        check_quantum_state_ket,
        check_quantum_state_varket,
        check_stabilizer_state,
        check_state_orthogonality,
        check_stabilizer_state_pair,
        check_stabilizer_generators,
        check_stabilizer_equality,
        check_stabilizer_one_normalizer,
        check_stabilizer_bad_clifford,
        check_graph_state_stabilizer_given_amat,
        check_graph_state_stabilizer,
        check_graph_isomorphism_amat,
        check_stabilizer_equality_and_minimal,
        check_stabilizer_code_bad_error,
        check_stabilizer_equality_and_code_error,
        check_stabilizer_normalizer,
        check_clifford_group_equivalence,
        check_qubit_coord,
        check_clifford_circuit_eq,
        check_clifford_paulis,
        check_teleport,
        check_qcml_unitary,
        check_qcml_rewrite_rule,
        check_vn_entropy,
        check_tetra_holevo,
    ]
    for cfn in check_functions:
        env[cfn.__name__] = cfn

#-----------------------------------------------------------------------------

if __name__=="__main__":
    # test_ct1_ac()
    # test_teleport7()
    # test_ct1()
    # test_ct2()
    # test_qu8()
    test_qu2()
    # test_qu0()
    
