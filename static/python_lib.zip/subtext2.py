import re
import math
import random
import inspect
import unicodedata
from functools import wraps
from datetime import datetime


class Subtext(object):
    
    VERSION_PREFIX = '\u200b\u200b'  # Format version identifier; bump as needed
    
    # These characters do not show up as text on a page, in the address bar, or in emails,
    # but *do* show up by their HTML escape codes in Chrome's dev tools
    HIDDEN_CHARACTERS = (
        '\u200b',  # Zero-width space
        '\u200c',  # Zero-width non-joiner
        '\u200d',  # Zero-width joiner
       )
    
    POSSIBLE_INSERTION_POINTS = (
        # Ideally, insert between a non-space and a non-alphanumeric:
        r'(?<=\S)(?=[^a-zA-Z0-9])|(?<=[^a-zA-Z0-9])(?=\S)',
    
        # Failing that, insert between two non-space characters
        r'(?<=\S)(?=\S)',

        # Failing that, insert at comma
        r'(?=,)',
    
        # Failing that, insert right before the end of the string
        r'(?=$)',
       )
    

    def __init__(self, anonymous_student_id = None, debug=False, num_bits=32, 
                 insertion_points=POSSIBLE_INSERTION_POINTS,
                 sanitize_allow_lists=True):
        self.anonymous_student_id = anonymous_student_id
        self.debug = debug
        self.num_bits = num_bits
        self.insertion_points = insertion_points
        self.sanitize_allow_lists = sanitize_allow_lists

    def encode_character_string(self, value, characters, length=None):
        result = ''
        base = len(characters)
    
        exponent = int(math.log(value, base)) if value != 0 else 0
    
        # Deal with occasional numerical precision issues
        if int(value / base**exponent) >= base:
            exponent += 1
    
        # Pad answer to requested length
        if length:
            exponent = max(exponent, length - 1)
    
        while exponent >= 0:
            factor = int(value / base**exponent)
            result += characters[factor]
            value -= factor * base**exponent
            exponent -= 1
    
        return result
    
    
    def create_subtext(self):
        '''
        Generate and return subtext label based on anonymous_student_id, datetime, and num_bits
        '''
        now = datetime.utcnow()
        time_hash = 60 * now.minute + now.second
        time_subtext = self.encode_character_string(value=time_hash, characters=self.HIDDEN_CHARACTERS, length=8)
    
        id_leading_chars = self.anonymous_student_id[:int(self.num_bits / 4)]
        id_number = int(id_leading_chars, 16)  # Parse as hex
        id_subtext = self.encode_character_string(value=id_number, characters=self.HIDDEN_CHARACTERS)
    
        return self.VERSION_PREFIX + time_subtext + id_subtext
    
    
    def answer(self, raw_answer):
        try:
            text = str(raw_answer)
    
            # Identify an insertion index for the subtext string
            insertion_index = None
            for regex in self.insertion_points:
                match = re.search(regex, text)
                if match:
                    insertion_index = match.start()
                    break
    
            if not insertion_index:
                # Note: error text is only displayed in the staff view, so we can include sensistive info
                raise ValueError('SUBTEXT: No suitable insertion points were found in answer: "{}"'.format(raw_answer))
    
            # If it wasn't specified by the caller, try to find the caller's anonymous student ID
            if not self.anonymous_student_id:
                for stack_level in inspect.stack():
                    frame = stack_level[0]
                    if 'anonymous_student_id' in frame.f_globals:
                        self.anonymous_student_id = frame.f_globals['anonymous_student_id']
        
                if not self.anonymous_student_id:
                    # This happens every time we check because anonymous_student_id isn't defined then;
                    # since it's so common, just return the raw answer here instead of erroring
                    # TODO: actively detect when we're running as a grader instead?
                    return raw_answer
        
                # Allow answer() to work in studio with a dummy 'student' id
                if self.anonymous_student_id == 'student':
                    self.anonymous_student_id = '0' * 32
    
            # Create and insert the subtext string
            subtext = self.create_subtext()
            return text[:insertion_index] + subtext + text[insertion_index:]
    
        except:
            if self.debug:
                # If we're in debug mode, re-raise the exception to alert the instructor
                raise
            else:
                # If we're not in debug mode, just bail out and return the unmodified value
                return raw_answer  # Bail out
    
    
    def sanitize(self, value):
        if isinstance(value, list):  # edX answers can be lists; sanitize all items in this case
            if self.sanitize_allow_lists:
                return [self.sanitize(item) for item in value]
            else:
                value = str(value[0])	# if we don't allow lists, only take the first element
    
        if isinstance(value, str):  # Only do string substitution on strings
            for char in set(value):
                category = unicodedata.category(str(char))
                if category == 'Cc' or category == 'Cf':
                    value = value.replace(char, '')
    
        return value
    
    
    def grader(self, *args, **kwargs):
        def decorator(func):
            @wraps(func)
            def wrapped(expect, ans, **wkwargs):
                expect = self.sanitize(expect, *args, **kwargs)
                ans = self.sanitize(ans, *args, **kwargs)
                return func(expect, ans, **wkwargs)
            return wrapped
    
        if len(args) == 1 and callable(args[0]):
            # We were called as a decorator; i.e., @grader
            func = args[0]
            args = ()
            return decorator(func)
        else:
            # We were called as a decorator factory; i.e., @grader(...)
            return decorator

def test_subtext1():
    # test if answer gets subtext hidden characters
    st = Subtext(anonymous_student_id="41BCD", debug=True)
    xstr = "hello world"
    x = st.answer(xstr)
    print(("x='%s', xstr='%s', len(x)=%d" % (x, xstr, len(x))))
    assert(len(x)-len(xstr) > 10)


def test_subtext2():
    # test if global anonymous_student_id is found
    global anonymous_student_id
    anonymous_student_id = "098143ABCD"
    st = Subtext(debug=True)
    xstr = "hello world"
    x = st.answer(xstr)
    print(("x='%s', xstr='%s', len(x)=%d" % (x, xstr, len(x))))
    assert(len(x)-len(xstr) > 10)
    del globals()["anonymous_student_id"]

def test_subtext2a():
    # test if global anonymous_student_id is not found
    st = Subtext(debug=True)
    xstr = "hello world"
    x = st.answer(xstr)
    print(("x='%s', xstr='%s', len(x)=%d" % (x, xstr, len(x))))
    assert(len(x)==len(xstr))	# when no anonymous ID is available

def test_subtext3():
    st = Subtext(anonymous_student_id="41BCD",debug=True)
    xstr = "123"
    x = st.answer(xstr)
    print("x='%s', xstr='%s', len(x)=%d" % (x, xstr, len(x)))
    assert(len(x)-len(xstr) > 10)
    
    def gtest(expect, ans):
        try:
            ok = float(expect)==float(ans)
            msg = ""
        except Exception as err:
            msg = "oops, error %s" % str(err)
            ok = False
        return {'ok': ok, 'msg': msg}
    
    @st.grader
    def gtest_subtext(expect, ans):
        return gtest(expect, ans)
        
    ret = gtest_subtext("123", "123")
    assert ret['ok']

    ans_copied = x
    ret = gtest_subtext("123", ans_copied)
    assert ret['ok']

    ret = gtest_subtext(ans_copied, ans_copied)
    assert ret['ok']

            
def test_subtext4():
    st = Subtext(anonymous_student_id="41BCD", sanitize_allow_lists=False)
    xstr = "[II,YI]"
    x = st.answer(xstr)
    print("x='%s', xstr='%s', len(x)=%d" % (x, xstr, len(x)))
    assert(len(x)-len(xstr) > 10)
    
    def gtest2(expect, ans):
        try:
            ok = (expect=="[II,YI]")
            msg = ""
        except Exception as err:
            msg = "oops, error %s" % str(err)
            ok = False
        return {'ok': ok, 'msg': msg}
    
    @st.grader
    def gtest_subtext(expect, ans):
        return gtest2(expect, ans)
        
    ans_copied = x
    ret = gtest_subtext(ans_copied, "[II,YI]")
    assert ret['ok']

    ret = gtest_subtext([ans_copied], ans_copied)
    assert ret['ok']

            
